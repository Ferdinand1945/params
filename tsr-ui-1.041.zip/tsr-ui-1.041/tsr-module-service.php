<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Service | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-MODULES/tsr-service/_tsr-service-ie8.css">
        <![endif]-->



</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Service</span>
                    </span>
               
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="">
            <div class="tsr-container">
                

<!-- - - - HTML Code - - - -->
    <div class="tsr-row" style="margin:50px auto;">

                       
                            <a href="#" class="tsr-module-service">

                                 <figure class="tsr-service-icon ts-icon-teliasonera">

                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>
                                   
                                 </figure>

                                <div class="tsr-service-content">

                                    <header class="tsr-service-header">TSbrand header</header>
     
                                    <p class="tsr-service-desc"> Lorem ipsum dolor
                                        Amet sit dolor
                                        Dolor ipsum sit </p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                           

                                </div>

                            </a>
     
                            <a href="#" class="tsr-module-service">

                                 <figure class="tsr-service-icon ts-icon-play">

                                   
                                   
                                 </figure>

                                <div class="tsr-service-content">

                                    <header class="tsr-service-header">Play +</header>
     
                                    <p class="tsr-service-desc"> Lorem ipsum dolor
                                        Amet sit dolor
                                        Dolor ipsum sit </p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                   

                                </div>

                            </a>   

     

    </div><!-- // tsr row -->

  
             




  
                </div><!-- // .row END -->

            </div><!-- // container -->
        </section><!-- // row - DARK SECTION END -->

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Service</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Product module used in <a href="tsr-section-productAndService-listing.php" >service listing</a> and <a href="tsr-section-carousel-listing.php" >carousel listing</a>.<br/>
Two tactical elements are allowed, ribbon and ribbon-usp.


<ol>
  <li>tsr-tactical-ribbon (green)</li>
  <li>tsr-tactical-ribbon-usp (green)</li>
 
</ol>


                    <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                          <li><a href="tsr-components-tacticalElements.php">tsr-tacticalElements</a></li>
                        </ul>
                    </article>    

                    <article class="col-5 desc">

<a href="tsr----STANDALONE-ZIP/tsr-module-service.zip" class="tsr-btn tsr-btn-100">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"><a href="#" class="tsr-module-service">

     <figure class="tsr-service-icon ts-icon-play">

        <figure class="tsr-tactical-ribbon"><span>New</span></figure>
        <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>  
       
     </figure>

    <div class="tsr-service-content">

        <header class="tsr-service-header">...</header>

        <p class="tsr-service-desc">
        ...
        </p>
        
        <p class="tsr-service-price">
        ...
        </p>
       

    </div>

</a> </code></pre>

 </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



 

<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  

  
</body>
</html>