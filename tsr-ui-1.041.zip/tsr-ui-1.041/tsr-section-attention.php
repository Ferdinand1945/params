<!doctype html>

 <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

        <title>Attention| TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-attention/_tsr-attention-ie8.css">
        <![endif]-->        

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navigation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
                <span>Attention</span>
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ******************** ALERTS ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row" style="margin-top:50px;">

<!-- Green - Default -->

  <article class="tsr-section-attention" >
    <div class="tsr-container">
        <figure class="ts-icon-info"></figure>
        <a href="#" class="tsr-attention-text"><strong>Information</strong> <span>Lorem ipsum dolor amet set imnes consecuteur baden il magna</span><span class="tsr-attention-readMore">Read more</span></a>
        <a href="#" class="tsr-attention-close ts-icon-delete"></a>
    </div>
  </article>


<!-- Orange -->

  <article class="tsr-section-attention tsr-primaryAlert">
    <div class="tsr-container">
        <figure class="ts-icon-alert"></figure>
        <a href="#" class="tsr-attention-text"><strong>Primary alert</strong> <span>Lorem ipsum dolor amet set imnes consecuteur</span><span class="tsr-attention-readMore">Lue lisää</span></a>
        <a href="#" class="tsr-attention-close ts-icon-delete"></a>
    </div>
  </article>


<!-- Blue -->

  <article class="tsr-section-attention tsr-secondaryAlert tsr-large" >
    <div class="tsr-container">
        <figure class="ts-icon-broadband"></figure>
        <a href="#" class="tsr-attention-text"><strong>Secondary alert long strong header</strong> <span>Lorem ipsum dolor il magna amet set imnes consecuteur</span><span class="tsr-attention-readMore">Read much more</span></a>
    </div>
  </article>


<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Attention</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section. The link name "Read more" can be dynamic in length, jQuery is handling the length for proper design at all breakpoints. <br/>

<ol>
  <li>Information (Green)</li>
  <li>Primary alert (Orange)</li>
  <li>Secondary alert (Blue)</li>
  <li>Large</li>    
</ol>

<ul>
  <li>Green color is default.</li>
  <li>Colours changes via class addition. </li>
  <li>Icons can be chosen from the icons library and added to figure tag.</li>    
</ul>

<span class="demo-header-2"><span>Dependencies</span></span>
                        
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">

     <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
     <a href="tsr----STANDALONE-ZIP/tsr-section-attention.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"><article class="tsr-section-attention tsr-secondaryAlert" >
    <div class="tsr-container">
        
      <figure class="ts-icon-broadband"></figure>
        
      <a href="#" class="tsr-attention-text">
        <strong>Header</strong>
        <span>Meassage</span>
        <span class="tsr-attention-readMore">Link name</span>
      </a>

      <a href="#" class="tsr-attention-close ts-icon-delete"></a>

    </div>
</article></code></pre>

<pre style="margin:4px 0;"><code data-language="html"><article class="... tsr-secondaryAlert" > ... </article>
<article class="... tsr-primaryAlert" > ... </article>

<article class="... ... tsr-large" > ... </article></code></pre>

<pre><code data-language="html"> ...
  <figure class="ts-icon-XXX"></figure>
 ...</code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->
  
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 
  <?php include '__php-includes/footer-js.php'; ?>

  <!-- TSR-Attention -->
  <script src="tsr-SECTIONS/tsr-attention/tsr-attention.js"></script>


  

  
</body>
</html>