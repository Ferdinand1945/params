                <nav class="col-full navigation">
                   
 <a href="#" class=" mobile ts-icon-menu"></a>

                    <menu>
                        <li><a href="index.php">Startpage</a></li> 
                        <li><a href="tsr--frontend-guide.php">Frontend guide</a></li>
                        <li><a href="tsr--style-guide.php">Style guide</a></li>
                        <li><a href="#">Components</a>
                            <menu>
                                <li><a href="tsr-components-typography.php">Typography</a></li>
                                <li><a href="tsr-components-icons.php">Icons</a></li>
                                <li><a href="tsr-components-tacticalElements.php">Tactical elements</a></li>
                                <li><a href="tsr-components-buttonsAndLinks.php">Buttons &amp; Links</a></li>
                                <li><a href="tsr-components-pagination.php">Pagination </a></li>
                                <li><a href="tsr-components-forms.php">Forms</a></li>
                                <li><a href="tsr-components-grid.php">Grid</a></li>
                                <li><a href="tsr-components-favicon.php">Favicon</a></li>
                            </menu>  
                        </li>
                        <li><a href="#">Modules</a>
                            <menu>
                                <li><a href="tsr-module-table.php">Table</a></li>
                                <li><a href="tsr-module-product.php">Product</a></li>
                                <li><a href="tsr-module-service.php">Service</a></li>
                                <li><a href="tsr-module-filter.php">Filter</a></li>
                                <li><a href="tsr-module-placeholder.php">Placeholder</a></li>
                            </menu>  
                        </li>
                        <li><a href="#">Sections</a>
                            <menu>
                                <li><a href="tsr-section-attention.php">Attention</a></li>
                                <li><a href="tsr-section-carousel-listing.php">Carousel listing</a></li>
                                <li><a href="tsr-section-communication-primary.php">Communication primary</a></li>
                                <li><a href="tsr-section-communication-secondary.php">Communication secondary</a></li>
                                <li><a href="tsr-section-dividers.php">Dividers</a></li>
                                <li><a href="tsr-section-footer.php">Footer</a></li>
                                <li><a href="tsr-section-header.php">Header</a></li>
                                <li><a href="tsr-section-productAndService-listing.php">Product &amp; Service listing</a></li>
                                <li><a href="tsr-section-promotion.php">Promotion</a></li>
                                <li><a href="tsr-section-support.php">Support</a></li>
                                <li><a href="tsr-template.php">(Dev Template)</a></li>
                            </menu>  
                        </li>
                        <li><a href="#">Layouts</a>
                            <menu>
                                <li><a href="tsr-layout-startpage.php" target="_blank">Start page</a></li>
                            </menu> 
                        </li>
                    </menu>  
                </nav>