   <!-- Rainbow include, code snippets -->
  <script src="tsr---DOCS/scripts/rainbow/rainbow.js"></script>
  <script src="tsr---DOCS/scripts/rainbow/language/generic.js"></script>
  <script src="tsr---DOCS/scripts/rainbow/language/html.js"></script>
  <script src="tsr---DOCS/scripts/rainbow/language/css.js"></script>
  <script src="tsr---DOCS/scripts/rainbow/language/javascript.js"></script>

  <!-- jQuery include (Version due to plugins and IE) -->
  <script src="tsr--CORE/tsr-js/libs/jquery-1.8.2.min.js"></script>
  

  <!-- Plugins -->
  <script src="tsr--CORE/tsr-js/plugins/jquery.debouncing.js"></script>

  <!-- TSR Docmentation utilities -->
  <script src="tsr---DOCS/scripts/u-main.js"></script>