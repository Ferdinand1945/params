<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Template | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


<!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-SECTIONS/tsr--template/_tsr-template-ie8.css">
<![endif]-->


</head>


<body class="tsr-grid tsr-typo">




<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Favicon</span>
                    </span>
               
        </section><!-- // row  END -->





<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Favicion</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

                        According to todays best pratcice. <br/>
                        Will support a very wide range of devices with minimum amount of icons. 
<br/><br/>
    

                        <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>The favicon icons</li>  
                        </ul>

                    </article>    

                    <article class="col-5 desc">

                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-favicon.zip" class="tsr-btn tsr-btn-100 tsr-btn-large mt8">Download ZIP</a>

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">





<pre><code data-language="html"><head>

    ... 

    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="favicon-144.png">   

    ...
    
    <link rel="icon"                                            href="favicon.png">
    <link rel="apple-touch-icon"                                href="favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76"      href="favicon-76.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120"    href="favicon-120.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152"    href="favicon-152.png">

    <!--[if IE]><link rel="shortcut icon" href="favicon.ico"><![endif]-->
    
    ...

</head></code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr--template/tsr-template.js"></script>

  
</body>
</html>