	

/////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
TSR - FORMS VALIDATION
*/ 

/////////////////////////////////////////////////////////////////////////////////////////////////////////


;(function(document,$) {

    window.tsrFormsValidation = window.tsrFormsValidation || {};

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////// TSR - Init
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    tsrFormsValidation.tsrInit = function() {
         // Validation
         tsrFormsValidation.tsrValidateDemo();
         tsrFormsValidation.tsrValidateFocusBlurMsg();
    };

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////// TSR - Validate
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    tsrFormsValidation.tsrValidateDemo = function () {

		$("#tsr-demo-validate-form-poc").validate({

///////// Demo rules

 			rules: 
	        {
	          firstname: 
	          {
	            minlength: 3
	          },
	          lastname: 
	          {
	            minlength: 6
	          },
	          mobilenumber: 
	          {
	            number: true,
	            rangelength:[10,20]
	          },
	          username:
	          {
	            maxlength: 6
	          },
	          password:
	          {
	            minlength: 8
	          },
	          confirm_password:
	          {
				minlength: 5,
				equalTo: "#password"
	          },
	          email: 
	          {
	            email:true
	          },
	          message: 
	          {
	            rangelength:[10,20]
	          }
	        },

///////// Needed for TSR styling

	        ignore: [],  // <-- allows for validation of hidden fields -> NEEDED FOR TSR!
			success: function(label, element) {
			   element = $(element);

			   	if (element.is( "select" )  ) {
			   		
			   		element.parent().removeClass('invalid');
			   		element.parent().find('label.error').remove();
			   	
			   	} else if (element.is( "textarea" )) {
			   	 	
			   	 	element.parent().removeClass('invalid');
			   		element.parent().find('label.error').remove();

			   	 } else if (element.is( "input:radio" )) {
			   	 	
			   		element.parent().parent().find(".tsr-radio").removeClass('invalid');
	               	element.parent().parent().find('label.error').remove();

				} else if (element.is( "input:checkbox" )) {
				 	
			   		element.parent().removeClass('invalid');
	               	element.parent().find('label.error').remove();

				 } else {
				 	
			   		element.parent().removeClass('invalid');
			   		element.parent().find('label.error').remove();
	           
				 }

			},

	        errorPlacement: function(error, element) {

			   	 if (element.is( "select" )  ) {
					
					element.parent().addClass('invalid');
	               	element.parent().append(error);
			
				 } else if (element.is( "textarea" )) {
				 	
				 	element.parent().addClass('invalid');
	               	element.after(error);

	             } else if (element.is( "input:radio" )) {
	             	
	     			element.parent().parent().find(".tsr-radio").addClass('invalid');
	               	element.parent().parent().append(error);

				 } else if (element.is( "input:checkbox" )) {
				 	
	           		element.parent().addClass('invalid');
	               	element.parent().append(error);

				 } else {
				 	
				    element.parent().addClass('invalid');
	               	element.after(error);

				 }
            },

///////// Demo submit

            submitHandler: function(form) {
			    	 alert('Submit');
			}

		});	

    };

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////// TSR - Validate Focus meassage
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    tsrFormsValidation.tsrValidateFocusBlurMsg = function () {

    	  $('.tsr-forms input[type=text], .tsr-forms input[type=password], .tsr-forms textarea').focus(function() {
    		
		    var el = $(this);
		    var desc = el.attr('data-desc');
		   
		    if(desc != undefined){
		   
			    if(el.hasClass('-has-msg') && el.hasClass('error')){
			    	el.parent().find('.tsr-focus-msg').css('opacity','1');
			    } else if (el.hasClass('-has-msg') && !el.hasClass('error')){
			    	el.parent().find('.tsr-focus-msg').css('opacity','1');
			    } else {
			    	el.addClass('-has-msg').parent().append('<label class="tsr-focus-msg">' + desc +'</label>').css('opacity','1');
			    } 
		    }

		  });


 	  	  $('.tsr-forms input[type=text], .tsr-forms input[type=password], .tsr-forms textarea').blur(function() {

			    var el = $(this);
			    var desc = el.attr('data-desc');
			
			    if(desc != undefined){
			    	if(el.hasClass('-has-msg')){
			    		el.parent().find('.tsr-focus-msg').css('opacity','.3');
			    	} 
			    }

		  }); 

    };

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////////////
////// Ready
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    $(document).on('ready', function(){

        tsrFormsValidation.tsrInit();
      
    });


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

})(document,jQuery);

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////// END
/////////////////////////////////////////////////////////////////////////////////////////////////////////

