<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Footer| TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


<!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-footer/_tsr-footer-ie8.css">
<![endif]-->



</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Footer</span>
                    </span>
               
        </section><!-- // row  END -->


<!-- ************************************************ -->
<!-- ******************** BASE ********************** -->
<!-- ************************************************ -->

        <section class="tsr-row" style="margin-top:50px;">
            
                

<!-- - - - HTML - - - --> 


        <section class="tsr-section-footer">
            


                <!-- Links -->

                <div class="tsr-footer-links">
                    <div class="tsr-container">
                    
                        <menu class="tsr-nav-top-level tsr-extra-links">
                               <li>
                                    <header>Useful Services & Links</header>
                                        <menu class="tsr-nav-second-level">
                                            <li><a href="#">Extra 1</a></li>
                                            <li><a href="#">Extra 2</a></li>
                                            <li><a href="#">Extra 3</a></li>
                                            <li><a href="#">Extra 4</a></li>
                                            <li><a href="#">Extra 5</a></li>
                                        </menu>
                                </li>          
                        </menu><!-- // tsr-extra-links -->


                        <menu class="tsr-nav-top-level">

                            <li>
                                <a href="#">Mobile phones</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Mobile phones landing page</a></li>
                                        <li><a href="#">Mobile phones</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                        <li><a href="#">Product &amp; Accessories</a></li>
                                        <li><a href="#">Services</a></li> 
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Tablets</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Tablets phones landing page</a></li>
                                        <li><a href="#">Tablets</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                        <li><a href="#">Product &amp; Accessories</a></li>
                                        <li><a href="#">Services</a></li> 
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Broadband</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Broadband landing page</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                    </menu>
                            </li>

                            <li>
                                <a href="#">TV</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Channels</a></li>
                                        <li><a href="#">Packages</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Support</a>
                            </li>

                        </menu><!-- // tsr-nav-top-level  -->

                             
                    </div>       
                </div><!-- //tsr-footer-links -->


                <!-- SM -->

                <div class="tsr-footer-sm">
                    <div class="tsr-container">

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-facebook"></figure>
                            
                            <p>
                            <strong>TSbrand on Facebook</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-youtube"></figure>
                            
                            <p>
                            <strong>TSbrand on YouTube</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-twitter"></figure>
                            
                            <p>
                            <strong>TSbrand on Twitter</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-google"></figure>
                            
                            <p>
                            <strong>TSbrand on Google +</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                    </div>  
                </div><!-- //tsr-footer-sm -->

                <!-- Copyright -->

                <div class="tsr-footer-copyright">
                    <div class="tsr-container">
                        &copy; TSbrand 
                    </div>
                </div>

                <a href="#to-top" class="tsr-btn-toTop">Back to top</a>

  

                
        </section><!-- // tsr-section END -->  

</section><!-- // row END --> 


<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Footer</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Fullt width section. Extra links are to the left and mirror top navigation to the right.  First three items form the top navigation will get jQuery equal heights. The css handels 2-4 social media links.

<ul>
  <li>2-4 social media links</li>
</ul>

 <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>
                        <span class="demo-header-3" style="padding:0; margin-bottom:-6px;"><span  style="padding:0;">Enquire.js</span></span>
                        <ul>

                          <li>tsr--CORE/tsr-js/libs/enquire.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.addListener.js</li>
                        </ul>


                    </article>    

                    <article class="col-5 desc">


<a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
     <a href="tsr----STANDALONE-ZIP/tsr-section-footer.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-footer">
            
    <!-- Links -->

    <div class="tsr-footer-links">
        <div class="tsr-container">
        
            <menu class="tsr-nav-top-level tsr-extra-links">
                   <li>
                        <header>Useful Services & Links</header>
                            <menu class="tsr-nav-second-level">
                                <li><a href="#">...</a></li>
                                ...
                            </menu>
                    </li>          
            </menu><!-- // tsr-extra-links -->

            <menu class="tsr-nav-top-level">

                <li>
                    <a href="#">Mobile phones</a>
                        <menu class="tsr-nav-second-level">
                            <li><a href="#">...</a></li>
                            ...
                        </menu>
                </li>

                ...

            </menu><!-- // tsr-nav-top-level  -->

                 
        </div>       
    </div><!-- //tsr-footer-links -->


    <!-- SM -->

    <div class="tsr-footer-sm">
        <div class="tsr-container">

            <a href="#" class="tsr-footer-sm-link">
                <figure class="tsr-footer-icon-facebook"></figure>
                
                <p>
                <strong>TSbrand on Facebook</strong>
                <small>Usp ...</small>
                </p>

            </a>

            ...

        </div>  
    </div><!-- //tsr-footer-sm -->

    <!-- Copyright -->

    <div class="tsr-footer-copyright">
        <div class="tsr-container">
            &copy; TSbrand 
        </div>
    </div>

    <a href="#to-top" class="tsr-btn-toTop">Back to top</a>

</section>
            </code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->



          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr-footer/tsr-footer.js"></script>

  
</body>
</html>