<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Product | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

<!--[if lte IE 9]>
            
<link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
<link rel="stylesheet" href="tsr-MODULES/tsr-product/_tsr-product-ie8.css">            

<![endif]-->


</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Product</span>
                    </span>
               
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="">
            <div class="tsr-container">
                

<!-- - - - HTML Code - - - -->
    <div class="tsr-row" style="margin:50px auto;">

                       
                            <a href="#" class="tsr-module-product">

                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-1.png" />
                                 </figure>

                                <div class="tsr-product-content">
                                    
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>

                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor
                                        Amet sit dolor
                                        Dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>

                                </div>

                            </a>
     
                            <a href="#" class="tsr-module-product">

                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>

                                <div class="tsr-product-content">
                                 
                                    <header class="tsr-product-header">Apple</header>
            
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>

                                </div>

                            </a> 

                            <a href="#" class="tsr-module-product">

                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-1.png" />
                                 </figure>

                                <div class="tsr-product-content">
                                    
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>

                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor
                                        Amet sit dolor
                                        Dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>

                                </div>

                            </a>          

                                <a href="#" class="tsr-module-product tsr-product-other">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-other-1.png">
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-ribbon tsr-text-small"><span>Popular</span></figure>
                                    <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-1 tsr-first"><span>HD</span></figure>  
                                    
                                    <header class="tsr-product-header" style="height: 27px;">HBO GO</header>
                                    <p class="tsr-product-desc" style="height: 42px;"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price" style="height: 21px;">Price fr. 37 $/month </p>

                                </div>
                            </a>

    </div><!-- // tsr row -->

  
 
  

            </div><!-- // container -->
        </section><!-- // row - DARK SECTION END -->

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Product</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Product module. used in  <a href="tsr-section-productAndService-listing.php" >product listing</a> and <a href="tsr-section-carousel-listing.php" >carousel listing</a>.<br/>
Three tactical elements are allowed, square or round, do not mix them.
Follow image size and ratio se psd in brandzone.
the class ".tsr-other" should be added if product is other than standing image.

<ol>
  <li>tsr-tactical-ribbon (green)</li>
  <li>tsr-tactical-flash tsr-first (blue)</li>
  <li>tsr-tactical-flash tsr-second (purple)</li>    
</ol>

<ol>
  <li>tsr-product-other</li>
   
</ol>


                    <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                          <li><a href="tsr-components-tacticalElements.php">tsr-tacticalElements</a></li>
                        </ul>
                    </article>    

                    <article class="col-5 desc">

<a href="tsr----STANDALONE-ZIP/tsr-module-product.zip" class="tsr-btn tsr-btn-100">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"> <!-- Full -->

<a href="#" class="tsr-module-product">

    <figure class="tsr-product-image">
        &lt;img src="..." />
    </figure>

    <div class="tsr-product-content">
                                    
        <figure class="tsr-tactical-ribbon">...</figure>
        <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"> ...</figure>  
        <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second">...</figure>

        <header class="tsr-product-header">...</header>
        
        <ul class="tsr-product-colors">
            <li style="background:#e2e2e2"></li>
            ...
        </ul>
        
        <p class="tsr-product-desc"> 
            ... 
        </p>
        <p class="tsr-product-price">
            ...
        </p>
        <p class="tsr-product-small-print">
            ...
        </p>

    </div>

</a></code></pre>

<pre style="margin-top:5px;"><code data-language="html"><!-- Minimal -->

<a href="#" class="tsr-module-product">

    <figure class="tsr-product-image">
        &lt;img src="..." />
    </figure>

    <div class="tsr-product-content">
                                    
        <header class="tsr-product-header">...</header>
        
            <p class="tsr-product-price">
                ...
            </p>
            <p class="tsr-product-small-print">
                ...
            </p>

    </div>

</a></code></pre>


<pre style="margin-top:5px;"><code data-language="html"><!-- Other -->

<a href="#" class="tsr-module-product tsr-product-other">

 <figure class="tsr-product-image">
    &lt;img src="...">
 </figure>

    <div class="tsr-product-content">  
                                     
        <figure class="tsr-tactical-ribbon tsr-text-small"><span>...</span></figure>
        <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>..</span></figure>  
        
        <header class="tsr-product-header" style="height: 27px;">...</header>

        <p class="tsr-product-desc">
            ...
        </p>
        <p class="tsr-product-price">
            ...
        </p>

    </div>

</a></code></pre>


                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



 

<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  

  
</body>
</html>