<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Tactical elements | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-tacticalElements/_tsr-tacticalElements-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>
                
            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                <span>
                    <span>Tactical elements</span>
                </span>
                
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ***************** SPEACH BUBBLE **************** -->
<!-- ************************************************ -->

        <section class="pb44 show-docs">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">

                    <div class="col-full">
                        <span class="demo-header-1"><span>SPEECH BUBBLE</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

<p>The speech bubble elements need individual positioning in the module or section where they are used. </p>
                   
                 <div class="col-full mb44">
                    <a href="tsr----STANDALONE-ZIP/tsr-component-tacticalElements.zip" class="tsr-btn">Download ZIP</a>
                </div> 


                    </article>    

<!-- - - - HTML Code - - - --> 

                    <div class="col-3">
                       
                        <figure class="tsr-tactical-speach-bubble">
                            <header class="tsr-header">The quick brown</header>
                            Jumps over the lazy dog, jump the lazy dog lorem ipsum.
                            Jumps over the lazy dog, jump the lazy dog lorem ipsum.
                        </figure>

                    </div>

                    <div class="col-3">
                       
                        <figure class="tsr-tactical-speach-bubble">
                            <header class="tsr-header">The quick brown</header>Jumps over the lazy dog, jump.
                        </figure>

                    </div>

                    <div class="col-6">
                       
                        <figure class="tsr-tactical-speach-bubble">
                            <header class="tsr-header">From the right</header>Jumps over the lazy dog, jump the lazy dog lorem ipsum.
                        </figure>

                    </div>
                    


                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><figure class="tsr-tactical-speach-bubble">
    <header class="tsr-header">
        The quick brown
    </header>
        Jumps over the lazy dog, jump</br>
        the lazy dog lorem ipsum
</figure></code></pre>

                    </article> 

                </div><!-- // .row END -->

<!-- - - - Sub Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-2"><span>COLOURS &amp; DIRECTIONS</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

The speach bubble elements comes in three colours. 
Green by default. Blue, purple, pink and orange by class addition. <br />
Direction change is also possible by class addition.

                    </article>    

<!-- - - - HTML Code - - - --> 


                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure> 

                    </div>

                    <div class="col-1">
                       

                        <figure class="tsr-tactical-speach-bubble ">
                            <header class="tsr-header"></header>
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble tsr-color-blue direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble tsr-color-blue">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>



                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble tsr-color-purple direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    <div class="col-1">

                        <figure class="tsr-tactical-speach-bubble tsr-color-purple">
                            <header class="tsr-header"></header>
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>



                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble tsr-color-pink direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    <div class="col-1">

                        <figure class="tsr-tactical-speach-bubble tsr-color-pink">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>


                    
                    <div class="col-1">
                       
                        <figure class="tsr-tactical-speach-bubble tsr-color-orange direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    <div class="col-1">

                        <figure class="tsr-tactical-speach-bubble tsr-color-orange">
                            <header class="tsr-header"></header>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </figure>

                    </div>

                    

                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><figure class="... tsr-color-blue">    ... </figure>
<figure class="... tsr-color-purpule"> ... </figure>
<figure class="... tsr-color-pink">    ... </figure>
<figure class="... tsr-color-orange">  ... </figure>

<figure class="... ... direction-right"> ... </figure>

<figure class="tsr-tactical-speach-bubble tsr-color-orange direction-right"> ... </figure></code></pre>

                    </article> 


                </div><!-- // .row END -->

            </div><!-- // container -->
        </section><!-- // row - SECTION END -->


<!-- ************************************************ -->
<!-- **************** PRODUCT WRAP ****************** -->
<!-- ************************************************ -->

        <section class="dark pb44 show-docs">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>PRODUCT WRAP</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

The product wrap elements need individual positioning in the module or section where they are used. Arrow is added by class addition.<br />
The height of this element is fixed due to technical restrictions. 



                    </article>    

<!-- - - - HTML Code - - - --> 

                    <div class="col-6">
        
                        <figure class="tsr-tactical-product-wrap direction-right" style="float:right">
                            <header class="tsr-header">The quick brown</header><span class="tsr-text">Jumps over the lazy dog, jump</br>the lazy dog lorem ipsum</span>
                        </figure>    

                    </div>

                    <div class="col-3">

                        <figure class="tsr-tactical-product-wrap">
                            <header class="tsr-header">The quick brown</header><span class="tsr-text">Jumps over the lazy dog, jump</br>the lazy dog lorem ipsum</span>
                        </figure>

                    </div>

                    <div class="col-6">

                        <figure class="tsr-tactical-product-wrap arrow direction-right" style="float:right">
                            <header class="tsr-header">The quick brown</header><span class="tsr-text">Jumps over the lazy dog, jump</br>the lazy dog lorem ipsum</span>
                        </figure>

                    </div>

                    <div class="col-6">

                        <figure class="tsr-tactical-product-wrap arrow">
                            <header class="tsr-header">The quick brown</header><span class="tsr-text">Jumps over the lazy dog, jump</br>the lazy dog lorem ipsum</span>
                        </figure>

                    </div>
                    


                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><figure class="tsr-tactical-product-wrap arrow direction-right">
    <header class="tsr-header">The quick brown</header>
    Jumps over the lazy dog, jump</br>
    the lazy dog lorem ipsum
</figure></code></pre>

                    </article> 

                </div><!-- // .row END -->

<!-- - - - Sub Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-2"><span>COLOURS &amp; DIRECTIONS</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">
The product wrap elements come in three colours.
Green by default. Blue, purple, pink and orange by class addition. <br />
Direction change is also possible by class addition.

                    </article>    

<!-- - - - HTML Code - - - --> 


                    <div class="col-1 ">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-blue direction-right ie8-hide">
                            <header class="tsr-header"></header>
                           &nbsp;
                        </figure>


                    </div>

                    <div class="col-2">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-blue  arrow">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>

                    </div>

   
                    <div class="col-1">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-purple direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>


                    </div>

                    <div class="col-2">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-purple  arrow ie8-hide">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>

                    </div>



                    <div class="col-1">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-pink direction-right ie8-hide">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>


                    </div>

                    <div class="col-2">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-pink  arrow">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>

                    </div>


                    <div class="col-1">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-orange direction-right">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>


                    </div>

                    <div class="col-2">
                       
                        <figure class="tsr-tactical-product-wrap tsr-color-orange  arrow ie8-hide">
                            <header class="tsr-header"></header>
                            &nbsp;
                        </figure>

                    </div>



                    

                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><figure class="... tsr-color-blue">    ... </figure>
<figure class="... tsr-color-purpule"> ... </figure>
<figure class="... tsr-color-pink">    ... </figure>
<figure class="... tsr-color-orange">  ... </figure>

<figure class="... ... direction-right"> ... </figure>

<figure class="tsr-tactical-product-wrap tsr-color-orange direction-right arrow"> ... </figure></code></pre>

                    </article> 


                </div><!-- // .row END -->

            </div><!-- // container -->
        </section><!-- // row - SECTION END -->


<!-- ************************************************ -->
<!-- ********************* FLASH ******************** -->
<!-- ************************************************ -->

        <section class="pb44 show-docs">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">
  


<!-- - - - - - - - - - - - - - - -  -->
<!-- - - - HTML Code  FLASHES - - - --> 
<!-- - - - - - - - - - - - - - - -  -->


       
                                <span class="demo-header-1"><span>FLASH SQUARE</span></span>
                  

        <!-- - - - TEXT  description - - - --> 

                            <div class="tsr-row">

                                <article class="col-5 pull-1 desc">

                                    Tactical elements can be used in any module or section. <br />
                                    Tactical elements need individual positioning in that module or section where they are used. 

                                </article>    


                                <article class="col-5 pull-1  desc">

                                    Square Tactical elements comes in three colours. <br />
                                    Green by default. Blue and purple by class addition.


                                </article> 

                        </div><!-- // .row END -->


         <!-- - - - HTML - - - --> 
                       
                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-flash-usp-1"><span>4G</span></figure>
                        </div>

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-flash-usp-2"><span>HD<small>Voice</small></span></figure>
                        </div>  

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-flash-price-2"><span>30%<small>Off</small></span></figure>
                        </div>

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-flash-price-3"><span><small>From</small>30€<small>/month</small></span></figure>
                        </div>

                        <div class="col-1 pull-1">
                           <figure class="tsr-tactical-flash tsr-flash-tech-2"><span>A6<small>Chip</small></span></figure>
                        </div>


                        <div class="col-1">
                            <figure class="tsr-tactical-flash"><span>&nbsp;</span></figure>
                        </div>

                        <div class="col-1">        
                            <figure class="tsr-tactical-flash tsr-color-blue"><span>&nbsp;</span></figure>
                        </div>

                        <div class="col-1 tsr-color-purple">               
                            <figure class="tsr-tactical-flash tsr-color-purple"><span>&nbsp;</span></figure>
                        </div>


        <!-- - - - Snippet - - - --> 

                            <div class="tsr-row">

                                <article class="col-6 snippet mt20">

<pre><code data-language="html"><figure class="tsr-tactical-flash ...">
    <span>4G</span>
</figure>

<figure class="... tsr-flash-usp-1">  ...</figure>
<figure class="... tsr-flash-usp-2">  ...</figure>
<figure class="... tsr-flash-price-2">...</figure>
<figure class="... tsr-flash-price-3">...</figure>
<figure class="... tsr-flash-tech-2"> ...</figure></code></pre>

                                </article> 

                                <article class="col-6  snippet mt20">

<pre><code data-language="html"><figure class="tsr-tactical-flash ...">...</figure>

<figure class="...   tsr-color-blue">  ...</figure>    
<figure class="...   tsr-color-purple">...</figure></code></pre>

                                </article> 

                            </div><!-- // .row END -->


                    </div><!-- // col-full -->



<!-- - - - - - - - - - - - - - - - - - -  -->
<!-- - - - HTML Code  FLASHES ROUND - - - --> 
<!-- - - - - - - - - - - - - - - - - - -  -->



                    <div class="col-full" style="margin-top:40px;">

                            
                                <span class="demo-header-1"><span>FLASH ROUND</span></span>
                       

        <!-- - - - TEXT  description - - - --> 

                            <div class="tsr-row">

                                <article class="col-5 pull-1 desc">

                                    Round tactical elements are based on the same code as the above square ones. <br />
                                    To make them round just add the class "tsr-tactical-round". <br />
                                    Round tactical elements need individual positioning in that module or section where they are used. 

                                </article>    


                                <article class="col-5 pull-1  desc">

                                    Square Tactical elements come in three colours. <br />
                                    Green by default. Blue and purple by class addition.


                                </article> 

                        </div><!-- // .row END -->

         <!-- - - - HTML - - - --> 
                       
                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-1"><span>4G</span></figure>
                        </div>

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-2"><span>HD<small>Voice</small></span></figure>
                        </div>  

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-price-2"><span>30%<small>Off</small></span></figure>
                        </div>

                        <div class="col-1">
                           <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-price-3"><span><small>From</small>30€<small>/month</small></span></figure>
                        </div>

                        <div class="col-1 pull-1">
                           <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-tech-2"><span>A6<small>Chip</small></span></figure>
                        </div>


                        <div class="col-1">
                            <figure class="tsr-tactical-flash tsr-tactical-round"><span>&nbsp;</span></figure>
                        </div>

                        <div class="col-1">        
                            <figure class="tsr-tactical-flash tsr-tactical-round tsr-color-blue"><span>&nbsp;</span></figure>
                        </div>

                        <div class="col-1 tsr-color-purple">               
                            <figure class="tsr-tactical-flash tsr-tactical-round tsr-color-purple"><span>&nbsp;</span></figure>
                        </div>


        <!-- - - - Snippet - - - --> 

                            <div class="tsr-row">

                                <article class="col-6 snippet mt20">

<pre><code data-language="html"><figure class="tsr-tactical-flash tsr-tactical-round ...">
    <span>4G</span>
</figure>

<figure class="... tsr-flash-usp-1">  ...</figure>
<figure class="... tsr-flash-usp-2">  ...</figure>
<figure class="... tsr-flash-price-2">...</figure>
<figure class="... tsr-flash-price-3">...</figure>
<figure class="... tsr-flash-tech-2"> ...</figure></code></pre>

                                </article> 

                                <article class="col-6  snippet mt20">

<pre><code data-language="html"><figure class="tsr-tactical-flash ...">...</figure>

<figure class="...   tsr-color-blue">  ...</figure>    
<figure class="...   tsr-color-purple">...</figure></code></pre>

                                </article> 


                            </div><!-- // .row END -->


                    </div><!-- // col-full -->


<!-- - - - - - - - - - - - - - - -  -->
<!-- - - - HTML Code  Ribbons - - - --> 
<!-- - - - - - - - - - - - - - - -  -->

                    <div class="col-6">


                            <div class="col-full">
                                <span class="demo-header-1"><span>Ribbons</span></span>
                            </div>

        <!-- - - - TEXT  description - - - --> 

                            <article class="col-full desc">

        Ribbons will automatically take their position in a wrapperwith the css attribute "position:relative".<br />
        Ribbin ".tsr-tactical-ribbon-usp", the small one needs individual positioning in that module or section where they are used.
        The Ribbin come in three text-sizes. <br />
        Large by default. Medium and small size by class addition.   

                            </article>  

                        
                        <div class="col-2">
                          <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                        </div>
                        
                        <div class="col-2">
                          <figure class="tsr-tactical-ribbon tsr-text-medium"><span>Sale</span></figure>
                        </div>

                        <div class="col-2 pull-1">
                          <figure class="tsr-tactical-ribbon tsr-text-small"><span>Popular</span></figure>
                        </div>

                        <div class="col-3">
                          <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>
                        </div>


                            <div class="tsr-row">

                                <article class="col-full snippet mt20">

<pre><code data-language="html"><figure class="tsr-tactical-ribbon ..."><span>New</span></figure>

<figure class="... tsr-text-medium"><span>...</span></figure>
<figure class="... tsr-text-small"><span> ...</span></figure>


<figure class="tsr-tactical-ribbon-usp">4G<span></span></figure></code></pre>

                                </article> 

                            </div><!-- // .row END -->


                    </div><!-- // col-half -->



                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 




            </div><!-- // container -->
        </section><!-- // row - SECTION END -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  
  
</body>
</html>