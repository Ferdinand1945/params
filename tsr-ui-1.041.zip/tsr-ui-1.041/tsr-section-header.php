<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Header| TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


        <!--[if lte IE 9]>
                    <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
                    <link rel="stylesheet" href="tsr-SECTIONS/tsr-header/_tsr-header-ie8.css">
        <![endif]-->


</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Header</span>
                    </span>
               
        </section><!-- // row  END -->


<!-- ************************************************ -->
<!-- ******************** BASE ********************** -->
<!-- ************************************************ -->

        <section class="tsr-row" style="margin-top:80px;">
            

<!-- - - - HTML * START *  - - --> 


        <section class="tsr-section-header">
            

<!-- - - GLOBAL - - -->
        
            <div class="tsr-header-global">
               <div class="tsr-container"> 
                        
                        <nav class="tsr-global-left">
                            <menu>
                                <li><a href="#">Private</a></li>
                                <li><a href="#">Business</a></li>
                                <li class="is-choosen"><a href="#">TSbrand B2B</a></li>
                                <li class="tsr-btn-arrow-mobile"></li>
                            </menu>
                        </nav>
                        
                        <a href="#" class="tsr-btn-close"></a>

                        <nav class="tsr-global-right">
                            <menu>
                                <li class="tsr-extra"><a href="#">Lorum ipsum</a></li>
                                <li class="tsr-extra"><a href="#">Refill prepaid card</a></li>
                                <li class="tsr-extra"><a href="#">Contact us</a></li>
                            </menu>
                        </nav>

                    </div>        
                </div>
            </div><!-- tsr-header-global END -->   

        

<!-- - - MAIN - - -->  

            <section class="tsr-header-main">
                <div class="tsr-container"> 
                
                <!-- LOGO -->  
                    <figure class="tsr-header-logo">
                        <img src="tsr-SECTIONS/tsr-header/logo-brand.png" />
                    </figure>


                        <!-- - - Top mobile + Search - - -->
                        <div class="tsr-header-mobileAndExtras">
                           <div class="tsr-container"> 
                                
                                    <nav>
                                        <menu>
                                            <li class="tsr-tab-cart" ><a href="#" data-header-tab="cart"><i class="tsr-tactical">3</i></a></li>
                                            <li class="tsr-tab-login"><a href="#" data-header-tab="login"></a></li>
                                            <li class="tsr-tab-search"><a href="#" data-header-tab="search"></a></li>
                                            <li class="tsr-tab-menu" ><a href="#" data-header-tab="menu"></a></li>
                                        </menu>
                                    </nav>
                  
                            </div>
                        </div><!-- tsr-header-mobileAndExtras END -->   

                
<!-- NAVIGATION -->  
                
                    <nav class="tsr-main-nav">
                        <menu class="tsr-nav-top-level">
                            <li><a href="#">Mobile phones</a>
                                <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Mobile phones landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-iphone.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Mobile phones</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Product &amp; Accessories</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Services</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                        </menu>
                                    </li>
                                     
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Tablets</a>
                                <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Tablets landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Tablets</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Product &amp; Accessories</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Services</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     
                                    <li><a href="#">Header</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     
                                    <li><a href="#">Header</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Broadband</a>
                                 <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Broadband landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Broadband</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>
                                            <li><a href="#">Lorum 7</a></li>
                                            <li><a href="#">Lorum 8</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>
                                            <li><a href="#">Lorum 7</a></li>
                                        </menu>
                                    </li>
                                    
                                     
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">TV</a>
                                 <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>TV landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>TV</header>
                                                <p>Consecuteur baden scrillum </p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Lorum</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>

                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                          
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                          
                                        </menu>
                                    </li> 
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Support</a>
                                                         
                            </li>
                           
                        </menu>
        
                    </nav>

<!-- Search -->  

                    <article class="tsr-header-search tsr-forms">

                        <input type="text" value="Search">
                        <input type="button" name="form-button" value="Search" class="tsr-btn">

                        <a href="#" class="tsr-btn-close" data-parent="search"></a>

                    </article><!-- tsr-header-search END -->    


<!-- Login -->  

                    <article class="tsr-header-login tsr-forms">

                        <input type="text" value="User">
                        <input type="password" value="Password">
                        <input type="button" name="form-button" value="Login" class="tsr-btn">

                        <a href="#" class="tsr-btn-close" data-parent="login"></a>

                    </article><!-- tsr-header-login END -->   

<!-- Cart-->  

                    <article class="tsr-header-cart tsr-forms">

                        <p class="tsr-text">
                            Content of Shopping Cart is Displayed Here
                        </p>
                            
                        <a href="#" class="tsr-btn-close" data-parent="cart"></a>

                    </article><!-- tsr-header-cart END -->  


                </div><!-- tsr-container END -->
            </section><!-- tsr-header-main END -->   


        </section><!-- // tsr-section-header END -->  


<!-- - - - HTML * END *  - - --> 


</section><!-- // row END --> 


<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Header</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section divided in two, "Global" and "Main". A lot of responsive magic i happening here both in CSS and JS.
One important thing is that no menus/code need to be duplicated, JS is handling all that.  <br /> <br />
Recommend you to download the zip file and check the code there especially the JS file.  <br /> <br />
 
 <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>
                        <span class="demo-header-3" style="padding:0; margin-bottom:-6px;"><span  style="padding:0;">Enquire.js</span></span>
                        <ul>

                          <li>tsr--CORE/tsr-js/libs/enquire.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.addListener.js</li>
                        </ul>


                    </article>    

                    <article class="col-5 desc">


<a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
     <a href="tsr----STANDALONE-ZIP/tsr-section-header.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 

                    </article> 

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html">// Section wrapper

<section class="tsr-section-header">

    <div class="tsr-header-global"> ... </div>                     // Global, see below   

    <div class="tsr-header-main"> ... </div>                       // Main, see below   

</section>

</code></pre>




<pre style="margin:4px 0;"><code data-language="html">// Global

<div class="tsr-header-global">
    <div class="tsr-container"> 
                        
        <nav class="tsr-global-left">
            <menu>
                <li><a href="#">...</a></li>
                ...
                <li class="is-choosen"><a href="#">...</a></li>     // Active/ Choosen page
                <li class="tsr-btn-arrow-mobile"></li>              // Mandatory for mobile navigation
            </menu>
        </nav>
        
        <a href="#" class="tsr-btn-close"></a>                      // Button for mobile, close global nav

        <nav class="tsr-global-right">
            <menu>
                <li class="tsr-extra"><a href="#">...</a></li>
                ...
            </menu>
        </nav>

    </div>        
   
</div>

</code></pre>


<pre><code data-language="html">// Main

<div class="tsr-header-main">
    <div class="tsr-container">   

        <figure class="tsr-header-logo"> ... </figure>              // Logo

        <div class="tsr-header-mobileAndExtras">                    // Top mobile nav + Search 
           <div class="tsr-container"> 
                
                    <nav>
                        <menu>
                            ...                                     // Check source
                        </menu>
                    </nav>
  
            </div>
        </div>


<!-- NAVIGATION -->  
                
        <nav class="tsr-main-nav">

            <menu class="tsr-nav-top-level">
                <li><a href="#">Top level</a>

                    <menu class="tsr-nav-second-level">
                        <li>
                            <a href="#"><span>Header landing</span>
                                <article class="tsr-landing">
                                    <figure>
                                        &lt;img src="..." />
                                    </figure>
                                    <header>...</header>
                                    <p>...</p>
                                </article> 
                            </a>
                        </li>
                        <li><a href="#">Second level</a>
                            <menu class="tsr-nav-third-level">
                                <li><a href="#">Third level</a></li>
                                ... 
                            </menu>
                        </li>

                        <li>
                        ...
                        </li>
    
                        <li class="tsr-btn-close">
                            <a href="#"></a>
                        </li>
                    </menu>

                </li>
            </menu>

        </nav>


    </div>
</div>

</code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->



          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr-header/tsr-header.js"></script>

  
</body>
</html>