<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Template | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


<!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-SECTIONS/tsr--template/_tsr-template-ie8.css">
<![endif]-->


</head>


<body class="tsr-grid tsr-typo">


<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Template</span>
                    </span>
               
        </section><!-- // row  END -->


<!-- ************************************************ -->
<!-- ******************** BASE ********************** -->
<!-- ************************************************ -->

        <section class="tsr-row" style="margin-top:50px;">
            
                

<!-- - - - HTML - - - --> 


        <section class="tsr-section-template">
            
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Section template</span>
                                        Full width
                                </header>   
                            </div>
                        </article>
                   
        </section><!-- // tsr-section END -->  



        <section class="tsr-section-template">
            <div class="tsr-container">

<!--
                <div class="tsr-row">
                    <div class="col-4"></div>
                    <div class="col-4"></div>
                    <div class="col-4"></div>
                </div>    
-->    


                    <div class="col-half">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Module in grid</span>
                                        Half width
                                </header>   
                            </div>
                        </article>
                    </div>    
                   
                    <div class="col-half">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Module in grid</span>
                                        Half width
                                </header>   
                            </div>
                        </article>
                    </div>  

            </div><!-- // tsr-container END -->
        </section><!-- // tsr-section END -->  


</section><!-- // row END --> 


<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Template</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

                        Lorum ipsum... 

                        <ol>
                          <li>Lorum</li>
                          <li>Lorum</li>
                          <li>Lorum</li>  
                        </ol>

                        <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">

                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-section-template.zip" class="tsr-btn tsr-btn-100 tsr-btn-large mt8">Download ZIP</a>

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-template">...</section>
<section class="tsr-section-template tsr-secondary">...</section></code></pre>

<pre style="margin:4px 0;"><code data-language="html"><a href="#" class="tsr-module-template ts-icon-calendar">
    <header>TStemplate news</header>
    <p>Text</p>
</a></code></pre>


<pre><code data-language="html"><section class="... tsr-secondary">
    ...    
        <a href="#" class="tsr-module-template ts-icon-calendar">
            <header>TStemplate news</header>
        </a>
    ...
</section></code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr--template/tsr-template.js"></script>

  
</body>
</html>