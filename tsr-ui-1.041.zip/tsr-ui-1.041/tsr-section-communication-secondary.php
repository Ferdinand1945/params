<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Communication area secondary | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-communication-secondary/_tsr-communication-secondary-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Communication area secondary</span>
                    </span>
               
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="tsr-row">
            
                

<!-- - - - HTML Code - - - -->

    <div class="tsr-row" style="margin:50px auto;">



        <section class="tsr-section-communication-secondary">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-1.jpg" />
                        </figure>
                        <header>The All New iPhone 5s - Changes everything again</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-2.jpg" />
                        </figure>
                        <header>Mixed campaign, offers, news   and product pushes</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-3.jpg" />
                        </figure>
                        <header>Short</header>
                        <p>Little text...</p>
                    </a>                 

               </div><!-- // container -->
         </section><!-- tsr-section-communication-secondary" END -->  






    </div><!-- // .row END -->
  

         
  



<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Communication area secondary</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section. Height is dynamic, jQuery is handling the height of "header" and "p" for proper design at all breakpoints. <br/>




<span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                          <li><a href="tsr-components-tacticalElements.php">tsr-tacticalElements</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">

                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-section-communication-secondary.zip" class="tsr-btn tsr-btn-100 tsr-btn-large mt8">Download ZIP</a>

                    </article> 

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html">
// Section

<section class="tsr-section-communication-secondary">
...
</section>


// Module

<a href="#" class="tsr-module-communication-secondary">
    
    <figure>
        &lt;img src="..." />
    </figure>
    
    <header>...</header>
    
    <p>...</p>

</a>

</code></pre>



                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->



          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  
    <!-- TSR-Attention -->
  <script src="tsr-SECTIONS/tsr-communication-secondary/tsr-communication-secondary.js"></script>

  
</body>
</html>