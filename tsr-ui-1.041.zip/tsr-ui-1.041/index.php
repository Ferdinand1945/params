<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Code library | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->  

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>


<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>TeliaSonera code library </span>
                    </span>
               
        </section><!-- // row  END -->



<!-- ************************************************ -->
<!-- ********************* COLORS  ****************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">



        <div class="tsr-row">

                <div class="column col-12" style="padding:40px 0 20px">
                        <img src="tsr---DOCS/images/Telia-Sonera.png" />
                </div>

                <div class="column col-6">
                    This is a code library for building responsive web design pages within the TeliaSonera group.
                    It's not a stand alone tool but needs to be used in parallel with the design guidelines on <a href=" http://brandzone.teliasonera.com/brandbook/teliasonera/homepage/detail?lang=en&r=20b2448e35cd588&pid=12223" target="_blank">TeliaSonera brandzone</a>.
                    <br/><br/>
                    <strong>Internet explorer 7</strong> users need to download a modern browser like <a href="https://www.google.com/intl/en/chrome/browser/" target="_blank">Chrome</a> or <a href="http://www.mozilla.org/en-US/firefox/new/" target="_blank">Firefox</a> to view and use this library. 
                </div>

                <div class="column col-6">

                    <a href="#" class="tsr-btn tsr-btn-100 tsr-btn-large">DOWNLOAD TSR-UI -> Full package (zip)</a>
                    
                </div>


<!-- - - - Color palette - - - --> 

             
              
                </div><!-- // .col-6  -->

        </div><!-- // .row END -->
 




            </div><!-- // container -->
        </section><!-- // row  SECTION END -->

        <section class="tsr-rowpb44">
            <div class="tsr-container">



        <div class="tsr-row">


            <div class="column col-12">
                <span class="demo-header-1"><span>CHANGELOG</span></span>
            </div>


                <div class="column col-4" style="padding-top:10px">
                        <ul class="changelog">
                           <li>
                            <figure>
                                <span class="date">14</span>
                                <span class="month">NOV</span>
                               
                            </figure>
                            <div><strong>2014, Release 1.04</strong> Link addition with color and state change, effected almost full library. Form validation added. Favicon added.   
                        
              <br /><br />
                            <strong>NEW ADDITIONS</strong> 
                            <i>Components:</i>
                            <ul>
                                <li>FAVICON</li>
                                <li>FORM -> VALIDATION</li>
                            </ul>
                            
              <br /><br />
                            <strong>UPDATES</strong>
                            <span style="color:red; font-size:12px; display:block; padding: 5px 0;">! UPDATE -> Default link state underline adjustment. "text-decoration:none" for all links in below components, modules and sections. </span>
                           
                            <i>Components:</i>
                            <ul>
                                <li>BUTTONS &amp; LINKS</li>
                                <li>PAGINATION</li>
                            </ul>

                            <i>Modules:</i>
                            <ul>
                                <li>PRODUCT</li>
                                <li>SERVICE</li>
                                <li>FILTER</li>
                            </ul>

                            <i>Section:</i>
                            <ul>
                                <li>ATTENTION</li>
                                <li>COMMUNICATION AREA SECONDARY</li>
                                <li>FOOTER</li>
                                <li>HEADER</li>
                                <li>PROMOTION</li>
                                <li>SUPPORT</li>
                            </ul>

                                </div>


                            </li>

                        </ul>  
      

                </div>

                <div class="column col-4" style="padding-top:10px">
                  
                    
                    <ul class="changelog">
                        <li>
                            <figure>
                                <span class="date">10</span>
                                <span class="month">JAN</span>
                               
                            </figure>
                            <div><strong>2014, Release 1.0</strong> First package with snippets and zip files for all core components, modules, sections and the startpage layout.   
                        
                            <br /><br />
                            <i>Components:</i>
                            <ul>
                                <li>TYPOGRAPHY</li>
                                <li>ICONS</li>
                                <li>TACTICAL ELEMENTS</li>
                                <li>BUTTONS & LINKS</li>
                                <li>PAGINATION</li>
                                <li>FORMS</li>
                                <li>GRID</li>
                            </ul>
                                <br />
                                <i>Modules:</i>
                                                   <ul>
                                <li>TABLE</li>
                                <li>PRODUCT</li>
                                <li>SERVICE</li>
                                <li>FILTER</li>
                                <li>PLACEHOLDER</li>
                            </ul>
                                <br />
                                <i>Sections:</i>
                                <ul>
                                <li>ATTENTION</li>
                                <li>COMMUNICATION PRIMARY</li>
                                <li>COMMUNICATION SECONDARY</li>
                                <li>DIVIDERS</li>
                                <li>FOOTER</li>
                                <li>HEADER</li>
                                <li>PRODUCT & SERVICE LISTING</li>
                                <li>PROMOTION</li>
                                <li>SUPPORT </li>
                            </ul>   
                            <br />
                                  <i>Layouts:</i>
                                <ul>
                                <li>STARTPAGE</li>
                               
                            </ul>    
                                </div>
                            </li>


                        </ul>  
                      









                </div>

                <div class="column col-4" style="padding-top:10px">
                        <ul class="changelog">
                           <li>
                            <figure>
                                <span class="date">20</span>
                                <span class="month">DEC</span>
                               
                            </figure>
                            <div><strong>2013, Pre-release 0.6</strong> Sneak peak of the code. One zip file delivered to brandzone to view work in progress, not for production.   
                        
                            <br /> 
                            
                                </div>


                            </li>

                        </ul>  
      

                </div>


<!-- - - - Color palette - - - --> 

             
              
                </div><!-- // .col-6  -->

        </div><!-- // .row END -->
 





                


            </div><!-- // container -->
        </section><!-- // row  SECTION END -->






          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  

  
</body>
</html>