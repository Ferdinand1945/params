<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Test links | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>


<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>TeliaSonera links for testing </span>
                    </span>
               
        </section><!-- // row  END -->



<!-- ************************************************ -->
<!-- ********************* COLORS  ****************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">



        <div class="tsr-row">

                <div class="column col-6" style="padding-top:40px">
                  
                    <span class="demo-header-1"><span>BROWSERS</span></span>
                    <ul>
                        <li><strong>IE10/9</strong> </li>
                        <li><strong>IE8</strong>  (CSS gracefull degradation for graphical elements, rounded corners etc)</li>
                        <li><strong>Chrome</strong>  (Latest, PC &amp; MAC)</li>
                        <li><strong>Firefox</strong>  (Latest, PC &map; MAC)</li>
                        <li><strong>Safari</strong>  (Latest MAC)</li>
                    </ul>  
                    <span class="demo-header-1"><span>DEVICES</span></span>
                    <ul>
                        <li><strong>Android -></strong> latest + one version back, 2 different devices  (native browser)</li>
                        <li><strong>Android tablet -></strong> latest, 1devices  (native browser)</li>
                        <li><strong>iOs -></strong> latest + one version back, 2 different devices  (native browser)</li>
                        <li><strong>iOs tablet (iPad) -></strong> latest + one version back, 2 different devices  (native browser)</li>
                        <li><strong>Windows mobile -></strong> latest (native browser)</li>
                    </ul>    
                </div>

                <div class="column col-6"  style="padding-top:40px">

                    <span class="demo-header-1"><span>&nbsp;</span></span>
                    <a href="tsr-layout-startpage.php" class="tsr-btn tsr-btn-100 tsr-btn-large">Startpage</a>
                    <a href="tsr----STANDALONE-ZIP/tsr-section-attention/tsr-section-attention.html" class="tsr-btn tsr-btn-100 mt12 ">Attention</a>
                    <a href="tsr----STANDALONE-ZIP/tsr-section-carousel-listing/tsr-carousel-listing.html" class="tsr-btn tsr-btn-100 mt12 ">Carousel listing</a>
                    <a href="tsr----STANDALONE-ZIP/tsr-section-productAndService-listing/tsr-section-productAndService-listing.html" class="tsr-btn tsr-btn-100 mt12 ">Product and service listing</a>
                    <a href="tsr----STANDALONE-ZIP/tsr-module-table/tsr-module-table.html" class="tsr-btn tsr-btn-100 mt12 ">Table</a>
                    <a href="tsr----STANDALONE-ZIP//tsr-module-filter/tsr-module-filter.html" class="tsr-btn tsr-btn-100 mt12 ">Filter</a>
      

                </div>


<!-- - - - Color palette - - - --> 

             
              
                </div><!-- // .col-6  -->

        </div><!-- // .row END -->
 





                


            </div><!-- // container -->
        </section><!-- // row  SECTION END -->








          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  

  
</body>
</html>