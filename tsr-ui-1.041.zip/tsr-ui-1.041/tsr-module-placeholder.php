<!doctype html>

    <?php include '__php-includes/html-conditional.php'; ?>

<head>

    <?php include '__php-includes/head-meta.php'; ?>

  <title>Placeholder | TeliaSonera</title>
   
    <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navigation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

            <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
                <span>Placeholder</span>
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="show-docs pb44">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>Placeholder</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

Module mainly used for development and demos. 

                    </article>    

<!-- - - - HTML Code - - - --> 

                    <div class="col-6">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>...</span>
                                        ...
                                </header>   
                            </div>
                        </article>
                    </div>

                                        <article class="col-half snippet">

<pre><code data-language="html"><article class="tsr-module tsr-module-placeholder">
    <div>
        <header>
            <span>Placeholder</span>
                col-6
        </header>   
    </div>
</article></code></pre>

                    </article> 

                   
                </div><!-- // .row END -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



<!-- ************************************************ -->
<!-- ***************** GRID CONTEXT ***************** -->
<!-- ************************************************ -->

        <section class="dark pb44">
            <div class="tsr-container">
                
<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>In grid context</span></span>
                    </div>

<!-- - - - TEXT  description - - - -->    

<!-- - - - HTML Code - - - --> 

                    <div class="col-6">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Placeholder</span>
                                        col-6
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Placeholder</span>
                                        col-3
                                </header>   
                            </div>
                        </article>
                    </div>
                    
                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Placeholder</span>
                                        col-2
                                </header>   
                            </div>
                        </article>
                    </div>  
                    <div class="col-1">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>PH</span>
                                        col-1
                                </header>   
                            </div>
                        </article>
                    </div>      

                    <div class="col-4">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Placeholder</span>
                                        col-4
                                </header>   
                            </div>
                        </article>
                    </div>              


                    <div class="col-8">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>Placeholder</span>
                                        col-8
                                </header>   
                            </div>
                        </article>
                    </div>  
                   
                </div><!-- // .row END -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->


<!-- ************************************************ -->
<!-- ********************* SIZE ********************* -->
<!-- ************************************************ -->

        <section class="show-docs pb44">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>Sizes</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

To change default size of the module add the size class "size-xxx".

                    </article>    

<!-- - - - HTML Code - - - --> 

                     <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder size-xlarge">
                            <div>
                                <header>
                                    <span>.size-xlarge</span>
                                        size
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder size-large">
                            <div>
                                <header>
                                    <span>.size-large</span>
                                        size
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Default</span>
                                        size
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>.size-small</span>
                                        size
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder size-xsmall">
                            <div>
                                <header>
                                    <span>.size-xsmall</span>
                                </header>   
                            </div>
                        </article>
                    </div>



                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><article class=" ... size-xlarge"> ... </article>
<article class=" ... size-large">  ... </article>
<article class=" ... size-small">  ... </article>
<article class=" ... size-xsmall"> ... </article>
</code></pre>

                    </article> 

                </div><!-- // .row END -->

            </div><!-- // container -->
        </section><!-- // row - SECTION END -->

<!-- ************************************************ -->
<!-- ******************** COLORS ******************** -->
<!-- ************************************************ -->

        <section class="show-docs dark pb44">
            <div class="tsr-container">

<!-- - - - Header - - - --> 
                <div class="tsr-row">

                    <div class="col-full">
                        <span class="demo-header-1"><span>Colors</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">
To change default color of the module add the color class "color-xxx".
                    </article>    

<!-- - - - HTML Code - - - --> 

                     <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Default</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-white">
                            <div>
                                <header>
                                    <span>.color-white</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-black">
                            <div>
                                <header>
                                    <span>.color-black</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-clay-t">
                            <div>
                                <header>
                                    <span>.color-clay-t</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-clay-c">
                            <div>
                                <header>
                                    <span>.color-clay-c</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder color-clay-h">
                            <div>
                                <header>
                                    <span>.color-clay-h</span>
                                        color
                                </header>   
                            </div>
                        </article>
                    </div>



                </div><!-- // .row END -->

<!-- - - - Snippet - - - --> 

                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><article class=" ... color-white">  ... </article>
<article class=" ... color-black">  ... </article>
<article class=" ... color-clay-t"> ... </article>
<article class=" ... color-clay-c"> ... </article>
<article class=" ... color-clay-h"> ... </article>
</code></pre>

                    </article> 

                </div><!-- // .row END -->

            </div><!-- // container -->
        </section><!-- // row - SECTION END -->

       
    </section><!-- // utility-styles -->




          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 

    <?php include '__php-includes/footer-js.php'; ?>
 


  
</body>
</html>