<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Support | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-support/_tsr-support-ie8.css">
        <![endif]-->


</head>


<body class="tsr-grid tsr-typo">


<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

<?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>


<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Support</span>
                    </span>
               
        </section>


<!-- ************************************************ -->
<!-- ******************* SUPPORT ******************** -->
<!-- ************************************************ -->

            
            <div class="tsr-row" style="margin:50px auto;">

                <section class="tsr-section-support">
                    <div class="tsr-container">

                            <a href="#" class="tsr-module-support ts-icon-calendar">
                                <header>TSbrand News</header>
                                <p>Lorem ipsum dolor amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il magna</p>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-broadband">
                                <header>Network status</header>
                                <p>Ipsum dolor amet set basteur baden scrillum. Consecuteur baden scrillum dolor amet set il </p>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-settings">
                                <header>Troubleshooting &amp; FAQ</header>
                                <p>Dolor amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il magna</p>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-support">
                                <header>Contact us</header>
                                <p>Amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il</p>
                            </a>                  

                       </div><!-- // tsr-container -->
                 </section><!-- tsr-section-support" END -->  


                <section class="tsr-section-support tsr-secondary mt20">
                    <div class="tsr-container">

                            <a href="#" class="tsr-module-support ts-icon-calendar">
                                <header>TSbrand News</header>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-broadband">
                                <header>Network status</header>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-settings">
                                <header>Troubleshooting &amp; FAQ</header>
                            </a>  

                            <a href="#" class="tsr-module-support ts-icon-support">
                                <header>Contact us</header>
                            </a>                  

                       </div><!-- // tsr-container -->
                 </section><!-- tsr-section-support" END -->  

            </div><!-- // tsr-row END -->
  

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                
<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Support</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

                        Full width section. Height is dynamic, jQuery is handling the height of "header" and "p" for proper design at all breakpoints. jQuery is counting modules in section and adding class to wrapper accordingly. Styling is done for 2-4 modules. <br/>

                        <ol>
                          <li>Primary is default</li>
                          <li>Secondary via class addition to wrapper, section tag "tsr-section-support"</li>
                          <li>Icons can be choosen from the icons library and added to "a" tag.</li>  
                        </ol>

                        <span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">
                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-section-support.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 
                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-support">...</section>
<section class="tsr-section-support tsr-secondary">...</section></code></pre>

<pre style="margin:4px 0;"><code data-language="html"><a href="#" class="tsr-module-support ts-icon-calendar">
    <header>TSbrand News</header>
    <p>Text</p>
</a></code></pre>


<pre><code data-language="html"><section class="... tsr-secondary">
    ...    
        <a href="#" class="tsr-module-support ts-icon-calendar">
            <header>TSbrand News</header>
        </a>
    ...
</section></code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // tsr-container -->
        </section><!-- // tsr-row  -->



<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  
  <script src="tsr-SECTIONS/tsr-support/tsr-support.js"></script>

  
</body>
</html>