<!doctype html>

       <?php include '__php-includes/html-conditional.php'; ?> 

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Frontend guide | TeliaSonera</title>
    
        <?php include '__php-includes/head-css-js.php'; ?>

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navgation - - - -->   

       <section class="utility-navigation">
            <div class="tsr-container">                

               <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Frontend guide</span>
                    </span>
               
        </section><!-- // row  END -->


<!-- ************************************************ -->
<!-- **************** BROWSER SUPPORT *************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">



                <div class="column col-12"><span class="demo-header-1"><span>TSR</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

TSR is the shorthand prefix used throughout the project. TSR stands for <strong>TeliaSonera Responsive</strong>. A prefix was needed to scope the code so it will be as independent as possible. One goal has been to have the ability to use these components, modules and sections individually with your already existing code if you don't want to use the full framework and setup.
                </div> 
                <div class="column col-12"><span class="demo-header-2"><span>Quick TSR prefix exampels</span></span></div>
                <article class="col-4 snippet">

<pre><code data-language="html">// HTML

&lt;figure class="tsr-tactical-speach-bubble">
...
&lt;/figure>

&lt;section class="tsr-section-support">
...
&lt;/section>

&lt;a href="#" class="tsr-module-service">
...
&lt;/a></code></pre>



                </article> 
                <article class="col-4 snippet">

<pre><code data-language="html">// CSS

.tsr-color-purple{
...
}

.tsr-grid{
...
}

.tsr-section-attention{
...
}</code></pre>



                </article> 
                                <article class="col-4 snippet">

<pre><code data-language="html">// JS

window.tsrTemplate = window.tsrTemplate || {};

tsrTemplate.tsrInit = function() {
                
    tsrTemplate.tsrEqualHeights();
     
};</code></pre>



                </article> 


                 <div class="col-6">
                   
                    
                </div>
            </div> <!-- // .container END -->
        </section><!-- // .row END -->

<!-- ************************************************ -->
<!-- **************** BROWSER SUPPORT *************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs dark pb44">
            <div class="tsr-container">



                <div class="column col-full"><span class="demo-header-1"><span>Browser support</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">
Browsers were chosen according to statistics, input from all the TeliaSonera global markets, scope and development time.
                </div> 

<!-- - - - Color palette - - - --> 

                 <div class="col-7">
                    <span class="demo-header-3"><span>Desktop</span></span>
                        
                    <ul class="list-items">    
                        <li class="item">
                            <figure class="icon u-icon-IE"></figure>
                            <span class="version">v.8-10</span>
                            <span class="os">
                                    <span class="u-icon-checkmark">&nbsp;PC</span>
                                    <span class="u-icon-checkmark-2">&nbsp;MAC</span>
                            </span>
                        </li>
                        <li class="item">
                            <figure class="icon u-icon-chrome"></figure>
                            <span class="version">v.31</span>
                            <span class="os">
                                    <span class="u-icon-checkmark">&nbsp;PC</span>
                                    <span class="u-icon-checkmark">&nbsp;MAC</span>
                            </span>
                        </li>
                        <li class="item">
                            <figure class="icon u-icon-safari"></figure>
                            <span class="version">v.7 </span>
                            <span class="os">
                                    <span class="u-icon-checkmark-2">&nbsp;PC</span>
                                    <span class="u-icon-checkmark">&nbsp;MAC</span>
                            </span>                            
                        </li>
                        <li class="item">
                            <figure class="icon u-icon-firefox"></figure>
                            <span class="version">v.26</span>
                            <span class="os">
                                    <span class="u-icon-checkmark">&nbsp;PC</span>
                                    <span class="u-icon-checkmark">&nbsp;MAC</span>
                            </span>                            
                        </li>
                        <li class="item na">
                            <figure class="icon u-icon-opera"></figure>
                            <span class="version">N/A</span>
                        
                            <span class="os">
                                    <span class="u-icon-checkmark-2">&nbsp;PC</span>
                                    <span class="u-icon-checkmark-2">&nbsp;MAC</span>
                            </span>
                        </li>                        
                    </ul>
                    
                </div>
                <div class="col-5">
                    <span class="demo-header-3"><span>Mobile</span></span>
                    
                    
                    <ul class="list-items">    
                        <li class="item">
                            <figure class="icon u-icon-apple"></figure>
                            <span class="version">iOs 6/7</span>
                        </li>
                        <li class="item">
                            <figure class="icon u-icon-android"></figure>
                            <span class="version">3/4</span>
                        </li>
                        <li class="item ">
                            <figure class="icon u-icon-windows"></figure>
                            <span class="version">v.10</span>
                        </li>
                    </ul>
                    
                </div>
            </div> <!-- // .container END -->
        </section><!-- // .row END -->


<!-- ************************************************ -->
<!-- ****************** RWD SOLUTION **************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">

  


                <div class="column col-full"><span class="demo-header-1"><span>RWD Solution - Mobile first</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

The grid is developed to support the user experience in all screen sizes and support design work, making placement decisions easier and more consistent. It is based on a traditional 960 px grid system with 12 columns and optimized to be responsive in both larger and smaller screens. The responsive range is from 240 px up to 1920 px.<br />
According to requirements the code base is done with a mobile-first approach to quality assure the mobile experience and to assure the possibility for file/code separation for load performance starting from the smallest screen up.
              </div> 

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Content width</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

For more details and reading about the grid, content widths and breakpoint se <a href="http://brandzone.teliasonera.com/brandbook/teliasonera/homepage/detail?lang=en&r=000782b68eb0d64&pid=12383">TeliaSonera brandzone</a>. 
                         
                </article> 

                <div class="col-full browser-list">
                    <div>

                    <ul class="list-items">    
                        <li class="item">
                            <figure class="icon u-icon-mobile"></figure>
                            <span class="info">320px</span>
                            <span class="co">
                                    <span>1 col / 100%</span>
                            </span>
                        </li>
                        <li class="item rotate">
                            <figure class="icon u-icon-mobile-2"></figure>
                            <span class="info">460px</span>
                            <span class="co">
                                    <span>2 col / 50 - 100%</span>
                            </span>

                        </li>
                       <li class="item">
                            <figure class="icon u-icon-tablet"></figure>
                            <span class="info">748px</span>
                            <span class="co">
                                    <span>12 col</span>
                            </span>

                        </li>

                        <li class="item rotate">
                            <figure class="icon u-icon-tablet"></figure>
                            <span class="info">940px</span>
                            <span class="co">
                                    <span>12 col</span>
                            </span>
                        </li>





                        <li class="item large ">
                            <figure class="icon u-icon-screen"></figure>
                            <span class="info">1176px</span>
                                                        <span class="co">
                                    <span>12 col</span>
                            </span>
                        </li>

                        <li class="item larger ">
                            <figure class="icon u-icon-tv"></figure>
                            <span class="info">1390px</span>
                                                        <span class="co">
                                    <span>12 col</span>
                            </span>
                        </li>

                    </ul>

                    </div>
                </div>
<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Breakpoints Mobile-first</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Visulazation of the used media-quieries.                         
                </article> 

                <div class="col-full">

                    <ul class="list-items media">    


                        <li class="item w30 primary">
                            <figure class="icon u-icon-code"></figure>
                            <span class="size">Mobile-first Core CSS</span>
                            
                           
                        </li>

                        <li class="item w40 primary">
                            <figure class="icon u-icon-mobile"></figure>
                            <span class="size">XSmall - Primary</span>
                            <span class="break">min-width 320px</span>
                        </li>

                        <li class="item w50">
                            <figure class="icon u-icon-mobile rotate"></figure>
                            <span class="size">Small</span>
                            <span class="break">min-width 480px</span>
                            
                        </li>

                        <li class="item w60">
                            <figure class="icon u-icon-tablet"></figure>
                            <span class="size">Medium</span>
                            <span class="break">min-width 768px</span>
               
                        </li>

                        <li class="item w70">
                            <figure class="icon u-icon-tablet rotate"></figure>
                            <span class="size">Large A</span>
                            <span class="break">min-width 941px</span>
                           
                        </li>

                        <li class="item w80">
                            <figure class="icon u-icon-tablet rotate"></figure>
                            <span class="size">Large B</span>
                            <span class="break">min-width 1441px</span>
                          
                        </li>  

                        <li class="item w90">
                            <figure class="icon u-icon-tablet rotate"></figure>
                            <span class="size">Large C</span>
                            <span class="break">min-width 1920px</span>
                           
                        </li> 


           
                    </ul>

                </div>

            </div> <!-- // .container END -->
        </section><!-- // .row END -->


<!-- ************************************************ -->
<!-- ***************** FILE STRUCTURE *************** -->
<!-- ************************************************ -->

        <section class="tsr-row  show-docs pb44 dark">
            <div class="tsr-container">



      

                <div class="column col-full"><span class="demo-header-1"><span>File structure</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-6 pull-1 desc">


<ul>
    <li><strong>tsr-ui</strong>
        <ul>
            <li><strong>tsr----STANDALONE-ZIP</strong> (containing all zip packages)</li>
            <li><strong>tsr---DOCS</strong> (Documentation, only for this snippets library)</li>
            <li><strong>tsr--CORE</strong> (Common code and resources)</li>
            <li><strong>tsr-COMPONENTS</strong> (All components)</li>
            <li><strong>tsr-MODULES</strong> (All modules)</li>
            <li><strong>tsr-SECTIONS</strong> (All sections)</li>
        </ul>
    </li>
</ul>

                </div> 

                <div class="col-5 desc">

<br /><i> <strong>The file structure is done with maintenace and scalable further development in mind.</strong></i> 

                </div> 

                <div class="col-full">
                    <span class="demo-header-2"><span>tsr--CORE</span></span>
                </div>
                 <div class="col-6 pull-1 desc">
                <ul>
                    <li><strong>tsr-ui</strong>
                        <ul>
                          
                            <li><strong>tsr--CORE</strong>

                                <ul>
                                    <li><strong>__dev-tsr-sass</strong></li>
                                    <li><strong>tsr-fonts</strong></li>
                                    <li><strong>tsr-js</strong>
                                        <ul>
                                            <li><strong>libs</strong></li>
                                            <li><strong>plugins</strong></li>
                                            <li><strong>polyfills</strong></li>
                                        </ul>
                                    </li>
                                </ul>

                            </li>
                        
                        </ul>
                    </li>
                </ul>

                </div> 

                <div class="col-5 desc">

<br /><i>The <strong>core</strong> folder contains all incommon code and resources.<br />
<br /><strong>"dev-tsr-sass"</strong> folder contains the normalize, variables and mixin files for SASS development. <br/>
<strong>"tsr-fonts"</strong> contains the TelaSonera custom font and json file for customisation.<br />
<strong>"tsr-js"</strong> contains all JS libs, plugins and polyfills</i> 

                </div> 



 <div class="col-full">
                    <span class="demo-header-2"><span>tsr-COMPONENT/ MODULES/ SECTIONS</span></span>
                </div>
                 <div class="col-6 pull-1 desc">
                <ul>
                    <li><strong>tsr-ui</strong>
                        <ul>
                          
                            <li><strong>tsr--COMPONENT/ MODULES/ SECTION</strong>

                                <ul>
                                    <li><strong>_tsr-nameHere</strong></li>
                                    <li><strong>...</strong></li>
                                    <li><strong>_tsr-grid</strong></li>
                                    <li><strong>_tsr-icons</strong></li>
                                    <li><strong>...</strong></li>
                                </ul>

                            </li>
                        
                        </ul>
                    </li>
                </ul>

                </div> 

                <div class="col-5 desc">

<br /><i>The <strong>COMPONENT/MODULES/SECTIONS</strong> is structured in a nice and easy way.<br /></i> 

                </div> 

<!-- - - - Snippets- - - --> 


            </div> <!-- // .container END -->
        </section><!-- // .row END -->



<!-- ************************************************ -->
<!-- ********************** MAKE ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">

      

                <div class="column col-full"><span class="demo-header-1"><span>Make a new component/ module or section</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

 <strong>tsr-SECTION</strong> has a folder template for further development. The idea is keep all the files for each component / module and section in the same folder for easy maintenance. The template folder files are ready made patterns for sass and js development. 

                </div> 

<!-- - - - files - - - --> 

                 <div class="col-6 pull-1 desc">
                    
                    <ul>
                        <li><strong>tsr-SECTION</strong>
                            <ul>
                              
                                <li><strong>tsr--template</strong>

                                    <ul>
                                        <li><strong>_tsr-template-ie8.scss</strong></li>
                                        <li><strong>_tsr-template.scss</strong></li>
                                        <li><strong>tsr-template.js</strong></li>
                                    </ul>

                                </li>
                            
                            </ul>
                        </li>
                    </ul>

                </div> 

                <div class="col-5 desc">

<br /><i>How to:</i>
                                    
                        <ol>
                                        <li><strong>Copy folder -></strong> tsr--template</li>
                                        <li><strong>Paste folder -></strong> in component / modules or sections</li>
                                        <li><strong>Re-name folder accodingly</strong></li>
                                        <li><strong>Re-name SASS and JS files accordingly</strong></li>
                                        <li><strong>Open SASS file -></strong> Change name in file variable for module or section, remove the other</li>
                                        <li><strong>Open SASS-ie8 file -></strong> Re-link @import and change name</li>
                                        <li><strong>Open JS file -></strong> Change name of object in all places. "tsrTemplate" to "tsrNewName"</li>
                                        <li><strong>Open tsr--CORE/tsr-core.scss -></strong> @import link in the file accordingly</li>
                                        <li><strong>Make sure sass is compiling -></strong> Start developing</li>
                        </ol> 

                </div> 



            </div> <!-- // .container END -->
        </section><!-- // .row END -->

<!-- ************************************************ -->
<!-- ********************** HTML ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark show-docs pb44">
            <div class="tsr-container">
      

                <div class="column col-full"><span class="demo-header-1"><span>HTML</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

                    HTML 5 is used in the whole project.

                </div> 

                                                <article class="col-12 snippet">

<pre><code data-language="html">&lt;!doctype html>

<menu></menu>, <section></section>, <article></article> etc.</code></pre>



                </article> 

<!-- - - - Color palette - - - --> 

                <div class="col-10">
                    
                </div>
                <div class="col-6">
                    
                </div>

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Conditional comments</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-12 desc">

This i used to identify no-js and legacy IE.
                         
                </article> 

                                                <article class="col-12 snippet">

<pre><code data-language="html"><!--[if lt IE 7 ]> <html lang="en" class="no-js ie ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js    ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html class="no-js " lang="en"> <!--<![endif]--></code></pre>



                </article> 


<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Meta</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

These meta tags is remondeded to be mandatory.
                         
                </article> 

                                                <article class="col-12 snippet">

<pre><code data-language="html">  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=8, IE=9, IE=10">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1"></code></pre>



                </article> 


            </div> <!-- // .container END -->
        </section><!-- // .row END -->

 <!-- ************************************************ -->
<!-- ********************** IE ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">
      

                <div class="column col-full"><span class="demo-header-1"><span>LEGACY Internet explorer (8)</span></span></div>



<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>HTML 5</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Modrnizr.js (html5shiv) is adding HTML 5 support to IE8.
                         
                </article> 

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>JS</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

If enquire.js is used then matchMedia need to be loaded for IE8.
                         
                </article> 


                <div class="col-full">
                    <span class="demo-header-2"><span>SASS/CSS</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Conditional classes can be used to target IE (.ie7,.ie8,.ie9).<br />
In sass you have specal mixin that only will render for ie, use if needed.<br />
In sass you have specal mixin handels the media query support and renders a file without them. You choose the width (media query) you want to server to ie8 in the ie8 SASS file.<br />

                </article>

 <article class="col-6 snippet">

<pre><code data-language="html">////// MIXIN OLD-IE + IE8 CLASS,

    @include old-ie {
    
        .ie8 &{

         }
    
    } </code></pre>

                </article> 


 <article class="col-6 snippet">

<pre><code data-language="html">////// THE IE-8 SASS FILE 

$old-ie: true;
$fix-mqs: 768px;

@import '_tsr-template.scss';</code></pre>



                </article> 


            </div> <!-- // .container END -->
        </section><!-- // .row END -->

<!-- ************************************************ -->
<!-- ********************** SASS ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark show-docs pb44 ">
            <div class="tsr-container">
      

                <div class="column col-full"><span class="demo-header-1"><span>SASS</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

                    <strong>tsr-SECTION</strong> have template for further development. The idea is keep all the files for each component / module and section in the same folder for easy maintenance. 

                </div> 

<!-- - - - Color palette - - - --> 

                 <div class="col-10">
                    
                </div>
                <div class="col-6">
                    
                </div>

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Compiling</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

tsr-core.scss and all component/module and section .scss files should rendner to the same folder as the .scss file is located in. 
                          <ul>
                          
                            <li><strong>tsr--CORE</strong>

                                <ul>
                                    <li><strong>_tsr-core.css</strong></li>
                                    <li><strong>_tsr-core.scss</strong></li>
                                </ul>

                            </li>

                            <li><strong>tsr-template</strong>

                                <ul>
                                    <li><strong>_tsr-template-ie8.css</strong></li>
                                    <li><strong>_tsr-template-ie8.scss</strong></li>
                                    <li><strong>_tsr-template.css</strong></li>
                                    <li><strong>_tsr-template.scss</strong></li>
                                </ul>

                            </li>
                        
                        </ul>
                </article> 

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Variables</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

All variables is in this file:
                   <ul>
                            <li><strong>tsr--CORE</strong>
                                <ul>
                                    <li><strong>_dev-tsr-sass</strong>
                                        <ul>
                                            <li><strong>_variables.scss</strong></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> 
                    </ul>                               
                </article> 

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Mixins</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">


All mixins is in this file:
                   <ul>
                            <li><strong>tsr--CORE</strong>
                                <ul>
                                    <li><strong>_dev-tsr-sass</strong>
                                        <ul>
                                            <li><strong>_mixins.scss</strong></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li> 
                    </ul>                         
                </article> 


            </div> <!-- // .container END -->
        </section><!-- // .row END -->




<!-- ************************************************ -->
<!-- ******************* JAVASCRIPT ***************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">

      

                <div class="column col-full"><span class="demo-header-1"><span>Javascript</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

Javascript has a few dependencies for optimal reponsive js workflow, se below.
                </div> 

<!-- - - - Color palette - - - --> 

            
                <div class="col-6">
                    

                <!-- - - - File- - - --> 

                        <div class="col-full">
                            <span class="demo-header-2"><span>Modernizr.js</span></span>
                        </div>


                        <article class="col-full desc">

        Is used to detect touch/ no-touch + css3 support. And shiv to give legacy IE HTML5 support. Recommend do download a custom version for your needs. 
                                 
                        </article> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Enquire.js</span></span>
                </div>

                <article class="col-full desc">

Is used for matching media-queries in JS and to add functions according to screen size.
                </article> 


                </div>



                <div class="col-6">
                          
                        <div class="col-full">
                            <span class="demo-header-2"><span>jquery.debouncing.js</span></span>
                        </div>

                        <article class="col-full desc">
        Performance optimised resize event. 
                        </article> 

                        <div class="col-full">
                            <span class="demo-header-2"><span>matchMedia</span></span>
                        </div>

                        <article class="col-full desc">
        Needed for legacy IE to work with enquire.js.
                        </article> 

                </div>



<!-- - - - Header 2 - Sub section- - - --> 





            </div> <!-- // .container END -->
        </section><!-- // .row END -->



<!-- ************************************************ -->
<!-- ******************* JAVASCRIPT ***************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark show-docs pb44">
            <div class="tsr-container">

      

                <div class="column col-full"><span class="demo-header-1"><span>tsr-template.js</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">
in template folder you have this file. A pattern setup for fast and easy development.
Change the tsrTemplate name according to new name and adjust the functionality according to your needs. 
                </div> 

<!-- - - - Color palette - - - --> 




<article class="col-12 snippet">

<pre><code data-language="html">/*
TSR - TEMPLATE
*/ 


;(function(document,$) {


    window.tsrTemplate = window.tsrTemplate || {};


////// TSR - Init

    tsrTemplate.tsrInit = function() {
       
         // Initial function to load on ready or load

         tsrTemplate.tsrFunction();
         
    };


////// TSR - Function

    tsrTemplate.tsrFunction = function () {

        ...

    };


////// Object + Enquire.js
    
     tsrTemplate.tsrObject =  {

            objectInit: function() {
                  
                    // enquire.js
                    enquire.register("screen and (min-width:768px)", {
              
                            setup : function() {

                             ...  
                            
                            },
                            match : function() {
                            
                             ...

                            },
                            unmatch : function() {

                             ...

                            }

                    }, true); 


            }, // objectInit

     }; // tsrTemplate.tsrObject END


////// Load

    $(window).on('load', function(){
      
    });


////// Ready

    $(document).on('ready', function(){

        tsrTemplate.tsrInit();
      
    });


////// Scroll

    $(document).on('scroll', function(){
            
    });


////// Resize

    $(window).smartresize(function(){
        
    });


})(document,jQuery);
</code></pre>



                </article> 




<!-- - - - Header 2 - Sub section- - - --> 











            </div> <!-- // .container END -->
        </section><!-- // .row END -->


<!-- ************************************************ -->
<!-- **************** DIVIDER SECTION *************** -->
<!-- ************************************************ -->

        <section class="tsr-row inverted hide">
            <div class="tsr-container">              

                <div class="column col-full">
                    <span class="demo-header-1"><span>Doc templates below:</span></span>
                </div>

            </div><!-- // container -->
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ****************** NEW SECTION ***************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark hide">
            <div class="tsr-container">

                <ul class="nav-section">
                    
                    <li class="docs u-icon-code"></li>
                </ul> 

                <div class="col-full">
                    <span class="demo-header-1"><span>Header 1</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.  

                </article>    

<!-- - - - HTML Code - - - --> 

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-primary</span></span>
                        <a href="#" class="bth-primary">Primary</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-secondary</span></span>
                        <a href="#" class="bth-secondary">Secondary</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#">Link</a></code>
<code data-language="html"><a href="#" class="link-arrow">Link arrow</a></code>
<code data-language="html"><a href="#" class="link-arrow-left">Link arrow left</a></code></pre>

                </article> 

            </div><!-- // container -->
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ****************** NEW SECTION ***************** -->
<!-- ************************************************ -->

        <section class="tsr-row hide">
            <div class="tsr-container">

                <ul class="nav-section">
                    
                    <li class="docs u-icon-code"></li>
                </ul> 

                <div class="col-full">
                    <span class="demo-header-1"><span>Header 1 </span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.    

                </article>    

<!-- - - - HTML Code - - - --> 

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-primary</span></span>
                        <a href="#" class="bth-primary">Primary</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-secondary</span></span>
                        <a href="#" class="bth-secondary">Secondary</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#">Link</a></code>
<code data-language="html"><a href="#" class="link-arrow">Link arrow</a></code>
<code data-language="html"><a href="#" class="link-arrow-left">Link arrow left</a></code></pre>

                </article>

<!-- - - - Header 2 - Sub section- - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Header 2</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                         
                </article>                 

<!-- - - - HTML Code - - - --> 

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-primary</span></span>
                        <a href="#" class="bth-primary">Primary</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>.bth-secondary</span></span>
                        <a href="#" class="bth-secondary">Secondary</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">
                        
<pre><code data-language="html"><a href="#">Link</a></code>
<code data-language="html"><a href="#" class="link-arrow">Link arrow</a></code>
<code data-language="html"><a href="#" class="link-arrow-left">Link arrow left</a></code></pre>
                        
                </article>

            </div><!-- // container -->
        </section><!-- // row  -->

       
    </section><!-- // utility-styles -->




          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
   <?php include '__php-includes/footer-js.php'; ?>


  
</body>
</html>
