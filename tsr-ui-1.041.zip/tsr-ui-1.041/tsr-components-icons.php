<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Icons | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>


<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span >
                        <span>Icons</span>
                    </span>
               
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ********************* ICONS ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">

                <ul class="nav-section">
                    
                    <li class="acc acc-1" data-color-theme="acc-1" ></li>
                    <li class="acc acc-2" data-color-theme="acc-2"></li>
                    <li class="acc acc-3" data-color-theme="acc-3"></li>
                    <li class="acc acc-4" data-color-theme="acc-4"></li>
                    <li class="acc acc-5" data-color-theme="acc-5" ></li>
                    <li class="acc acc-6" data-color-theme="acc-6"></li>
                    <li class="acc acc-7" data-color-theme="acc-7"></li>
                    <li class="acc acc-8" data-color-theme="acc-8"></li>

                </ul> 

        <div class="tsr-row">

                <div class="column col-full"><span class="demo-header-1"><span>Icons - All</span></span></div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">

                    This icon font contains all TeliaSoneras icons. We recommend you to download a custom icon font for your needs. See instructions below. 
   
                </div> 

<!-- - - - Snippet - - - --> 

        <div class="tsr-row">
            


            <div class="col-half">

<span class="demo-header-2"><span>Optimized font files</span></span>

                <ol>
                    <li>Download zip -> unzip</li>
                    <li>Locate json file</li>
                    <li>Go to -> http://icomoon.io/app/</li>
                    <li>Left icon menu -> Click "New project"</li>
                    <li>Click "Import icons" -> Upload the json file</li>
                    <li>Choose only the icons you want to use</li>
                    <li>Bottom of page -> click "Font"</li>
                    <li>Bottom of page -> click "Download"</li>
                </ol>  

            <a href="tsr----STANDALONE-ZIP/tsr-icons-fonts.zip" class="tsr-btn mt20 ">Download ZIP</a> 
            </div>


            <div class="col-half">

<article class="col-full snippet">

<pre><code data-language="html"><figure class="... ts-icon-play"></figure></code></pre>

                </article>
 
                <article class="col-full snippet">

<pre><code data-language="css">[class*="ts-icon-"]:before {
    font-family: 'ts-icons-all';
    speak: none;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    display:inline-block;
    margin-right:0.35em;
    
    // Better Font Rendering
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.ts-icon-play:before {
    content: "\e62b";
}</code></pre>

                </article>

            </div>

                

            </div> <!-- // .row END -->

<!-- - - - Icon demo- - - --> 
<div class="col-full icon-presentation">



            <span class="demo-header-1"><span>Glyphs</span></span>
                    
                  <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-zoomout"></span><span class="mls">zoomout</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-zoom"></span><span class="mls">zoom</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-xls"></span><span class="mls">xls</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-writeemail"></span><span class="mls">writeemail</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-wireless"></span><span class="mls">wireless</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-weather"></span><span class="mls">weather</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-voiceswitch"></span><span class="mls">voiceswitch</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-videocontent"></span><span class="mls">videocontent</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-vcard2"></span><span class="mls">vcard2</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-vcard"></span><span class="mls">vcard</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-upload"></span><span class="mls">upload</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-travelabroad"></span><span class="mls">travelabroad</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-trashfull"></span><span class="mls">trashfull</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-trashempty"></span><span class="mls">trashempty</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-time"></span><span class="mls">time</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-tags"></span><span class="mls">tags</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-sync"></span><span class="mls">sync</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-switch"></span><span class="mls">switch</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-support"></span><span class="mls">support</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-subscription"></span><span class="mls">subscription</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-stream"></span><span class="mls">stream</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-stop"></span><span class="mls">stop</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-statistics"></span><span class="mls">statistics</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-spellcheck"></span><span class="mls">spellcheck</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-sort"></span><span class="mls">sort</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-sms"></span><span class="mls">sms</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-skipforward"></span><span class="mls">skipforward</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-skipbackward"></span><span class="mls">skipbackward</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-shuffle"></span><span class="mls">shuffle</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-settings"></span><span class="mls">settings</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-security"></span><span class="mls">security</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-search"></span><span class="mls">search</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-save"></span><span class="mls">save</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-rss"></span><span class="mls">rss</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-renamefolder"></span><span class="mls">renamefolder</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-register"></span><span class="mls">register</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-radio"></span><span class="mls">radio</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-rack"></span><span class="mls">rack</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-print"></span><span class="mls">print</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-premisessmall"></span><span class="mls">premisessmall</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-premiseslarge"></span><span class="mls">premiseslarge</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-premisesdatacenter"></span><span class="mls">premisesdatacenter</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-ppt"></span><span class="mls">ppt</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-play"></span><span class="mls">play</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-phone"></span><span class="mls">phone</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-pdf"></span><span class="mls">pdf</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-pause"></span><span class="mls">pause</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-parentalguide"></span><span class="mls">parentalguide</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-newgroup"></span><span class="mls">newgroup</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-newfolder"></span><span class="mls">newfolder</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-newcontact"></span><span class="mls">newcontact</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-newadressbook"></span><span class="mls">newadressbook</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-myaccount"></span><span class="mls">myaccount</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-music"></span><span class="mls">music</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-movefolder"></span><span class="mls">movefolder</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-more"></span><span class="mls">more</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-mobile"></span><span class="mls">mobile</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-menu"></span><span class="mls">menu</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-map"></span><span class="mls">map</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-login"></span><span class="mls">login</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-listen"></span><span class="mls">listen</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-link"></span><span class="mls">link</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-like"></span><span class="mls">like</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-internet"></span><span class="mls">internet</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-home"></span><span class="mls">home</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-help"></span><span class="mls">help</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-games"></span><span class="mls">games</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-folderopen"></span><span class="mls">folderopen</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-folder"></span><span class="mls">folder</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-favourits"></span><span class="mls">favourits</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-entertainment"></span><span class="mls">entertainment</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-enduserdevice"></span><span class="mls">enduserdevice</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-enduser"></span><span class="mls">enduser</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-email"></span><span class="mls">email</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-edit"></span><span class="mls">edit</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-edgerouter"></span><span class="mls">edgerouter</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-download"></span><span class="mls">download</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-docs"></span><span class="mls">docs</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-dislike"></span><span class="mls">dislike</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-digitaltv"></span><span class="mls">digitaltv</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-delete"></span><span class="mls">delete</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-defaultimage"></span><span class="mls">defaultimage</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-default"></span><span class="mls">default</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-cpe"></span><span class="mls">cpe</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-costcontrol2"></span><span class="mls">costcontrol2</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-costcontrol"></span><span class="mls">costcontrol</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-corerouter"></span><span class="mls">corerouter</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-copyfolder"></span><span class="mls">copyfolder</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-content"></span><span class="mls">content</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-contact"></span><span class="mls">contact</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-cloud"></span><span class="mls">cloud</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-chat"></span><span class="mls">chat</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-camera"></span><span class="mls">camera</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-calendar"></span><span class="mls">calendar</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-buy"></span><span class="mls">buy</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-broadband"></span><span class="mls">broadband</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-ball"></span><span class="mls">ball</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-attach"></span><span class="mls">attach</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-alert"></span><span class="mls">alert</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-adressbook"></span><span class="mls">adressbook</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-add"></span><span class="mls">add</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-info"></span><span class="mls">info</span>
            </div>
            
            <div class="fs0 bshadow0 clearfix noLiga-true">
                
                
            </div>
        </div>


        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-twitter"></span><span class="mls">twitter</span>
            </div>
    
        </div>


        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-facebook"></span><span class="mls">facebook</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-youtube"></span><span class="mls">youtube</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-google-plus"></span><span class="mls">google-plus</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-thick"></span><span class="mls">thick</span>
            </div>

        </div>
        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-comment"></span><span class="mls">comment</span>
            </div>

        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-teliasonera"></span><span class="mls">teliasonera</span>
            </div>

        </div>


        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-circle"></span><span class="mls">circle</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-square-tilted"></span><span class="mls">square-tilted</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-arrow-left"></span><span class="mls">arrow-left</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-arrow-right"></span><span class="mls">arrow-right</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-arrow-down"></span><span class="mls">arrow-down</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-arrow-up"></span><span class="mls">arrow-up</span>
            </div>
        </div>

        <div class="glyph fs1">
            <div class="clearfix bshadow0 pbs">
                <span class="ts-icon-breadcrumb-arrow"></span><span class="mls">breadcrumb-arrow</span>
            </div>
        </div>

    </div> <!-- // .icon-presentation END -->



        </div><!-- // .row END -->




            </div><!-- // container -->
        </section><!-- // row  -->


          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->

        <?php include '__php-includes/footer-js.php'; ?>
  
  
</body>
</html>