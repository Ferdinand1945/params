<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Primary communication area | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

<!--[if lte IE 9]>
    <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-communication-primary/_tsr-communication-primary-ie8.css">                      
<![endif]-->




</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

<?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Primary communication area</span>
                    </span>
               
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="" style="margin:50px auto;">
            

<!-- - - - HTML Code - - - -->


        <section class="tsr-section-communictaion-primary" style="margin-top:50px">
          
                <div class="tsr-slides">


                     <a href="#" class="tsr-slide-1">
                        
                        <div class="tsr-tactical-container">
                            <figure class="tsr-tactical-speach-bubble tsr-color-pink">
                                <header class="tsr-header">
                                    Channel package?
                                </header>
                                    Jumps over the lazy dog, jump<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>

                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>A Channel for Everyone</header>
                                <span>The quick brown fox jumps over the lazy dog</span>
                            </div>

                        </div>

                    </a>
                    

                    <a href="#" class="tsr-slide-2">

                        <div class="tsr-tactical-container">
                            <figure class="tsr-tactical-product-wrap tsr-color-orange">
                                <header class="tsr-header">
                                    Super Deal, iPhone 5s!
                                </header>
                                    Jumps over the lazy dog<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>

                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>Lorum</header>
                                <span>The quick brown fox jumps over the </span>
                            </div>

                        </div>
                    </a>


                    <a href="#" class="tsr-slide-3">
                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>The quick brown</header>
                                <span>The quick brown fox jumps over the lazy </span>
                            </div>

                        </div>
                    </a>


                     <a href="#" class="tsr-slide-4">

<div class="tsr-tactical-container">
                            <figure class="tsr-tactical-speach-bubble direction-right">
                                <header class="tsr-header">
                                    Free Colored Cover!
                                </header>
                                    Jumps over the lazy dog, jump<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>

                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>Lorum ipsum</header>
                                <span>Lorum ipsum</span>
                            </div>

                        </div>
                    </a>    


                 </div>
           
        </section>




      




<!-- - - - HTML Code - - - -->

      


      
        </section><!-- // row - DARK SECTION END -->

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Primary communication area</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section image slider. The slider a plugin (GPL Licensed).For more documentation please visit the links below.
All tactical elements must be manually placed with css per slide and per breakpoint. 


<ul>
  <li>http://www.woothemes.com/flexslider/</li>
</ul>
                        <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                          <li><a href="tsr-components-tacticalElements.php">tsr-tacticalElements</a></li>
                        </ul>


                    </article>    

                    <article class="col-5 desc">

                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-section-communication-primary.zip" class="tsr-btn tsr-btn-100 tsr-btn-large mt8">Download ZIP</a>

                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-communictaion-primary">
          
    <div class="tsr-slides">

        <a href="#" class="tsr-slide-1">
            
            <div class="tsr-tactical-container">
                <figure class="tsr-tactical-speach-bubble tsr-color-pink">
                    <header class="tsr-header">
                        ...
                    </header>
                        ...
            </div>

            <div class="tsr-container">

                <div class="tsr-tactical-textPanel">
                    <header>...</header>
                    <span>...</span>
                </div>

            </div>

        </a>

    </div>
           
</section></code></pre>




                </article> <!-- // snippet -->


            </div><!-- // container -->
        </section><!-- // row - SECTION END -->




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr-communication-primary/jquery.flexslider.js"></script>
    <script src="tsr-SECTIONS/tsr-communication-primary/tsr-communication-primary.js"></script>
   
  
</body>
</html>