<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Table | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-MODULES/tsr-table/_tsr-mediaTable-ie8.css">         
        <![endif]-->



</head>


<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Table</span>
                    </span>
               
        </section><!-- // row  -->



<!-- ************************************************ -->
<!-- ******************** TABLES ******************** -->
<!-- ************************************************ -->

<section class="tsr-section-mediaTable" style="margin-top:40px;">


<!-- - - - The table - - - --> 
 
        <div class="tsr-container" >

            <header class="tsr-module-mediaTable-header tsr-color-purple" >
               
                    <span>
                        Table header
                    </span>    
   
            </header><!-- // tsr-section END -->

              <!-- Example Data Table -->
              <table class="tsr-module-mediaTable">
                <thead>
                  <tr>
                    <th class="essential persist">Subscription Name</th>
                    <th class="optional">Tariff/Min</th>
                    <th class="optional">SMS</th>
                    <th class="optional">Data/MB</th>
                    <th class="optional">4G/3G</th>
                    <th class="essential">Annual</th>
                    <th class="essential">Total</th>
                    <th class="essential">Purchase</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Subscription 1500 X-Small</td>
                    <td class="yes">1500 min incl</td>
                    <td class="yes">1500 sms incl</td>
                    <td class="yes">15 GB incl</td>
                    <td class="yes">4G</td>
                    <td class="yes">19€/Month</td>
                    <td class="yes"><span class="total">229€</span></td>
                    <td class="yes"><a href="#" class="tsr-btn tsr-btn-secondary">Purchase</a></td>
                  </tr>
                  <tr>
                    <td>Subscription 6000 Large</td>
                    <td class="yes">6000 min incl</td>
                    <td class="yes">6000 sms incl</td>
                    <td class="yes"><span class="free">Free data</span></td>
                    <td class="yes">3G/4G</td>
                    <td class="yes">49€/Month</td>
                    <td class="yes"><span class="total">639€</span></td>
                    <td class="yes"><a href="#" class="tsr-btn tsr-btn-secondary">Purchase</a></td>
                  </tr>
                  <tr>
                    <td>TSbrand Flat Cost 300</td>
                    <td class="yes">1000 min incl</td>
                    <td class="yes">0.49/SMS</td>
                    <td class="yes">Max 0.5/Day*</td>
                    <td class="yes">4G 4€/Month</td>
                    <td class="yes"><span class="free">Free</span></td>
                    <td class="yes"><span class="total">229€</span></td>
                    <td class="yes">N/A **</td>
                  </tr>
                </tbody>
              </table>

        </div><!-- // tsr-container END -->

<!-- - - - The footer * ** ***  - - - --> 

        <footer class="tsr-module-mediaTable-footer">
            <div class="tsr-container">
                <i class="tsr-star-1">Condition one lorem ipsum dolor amet set imnes consecuteur.</i>
                <i class="tsr-star-2">Condition one lorem ipsum dolor amet set.</i>
                <i class="tsr-star-3">Condition one lorem ipsum dolor amet set imnes <br /> consecuteur amet set imnes consecuteur</i>   
            </div><!-- // tsr-container END -->
        </footer><!-- // tsr-section END -->

</section><!-- // tsr-section END -->




 <br />
 <br />
 <br />         
 <br />

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Table</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section or module inside a section. Works as both. 
The responsiveness is handled by a plugin (MIT Licensed). <br/>
The responsive part kicks in when the window width is below 768px.<br/>
For more documentation please visit the links below.<br/>

<ul>
  <li>http://www.consulenza-web.com/2012/01/mediatable-jquery-plugin/</li>
  <li>http://consulenza-web.com/jquery/MediaTable/</li>
  <li>https://github.com/thepeg/MediaTable</li>    
</ul>

The header has has two options light or dark.

<ul>
  <li>Header background white is default</li>
  <li>Header background purple = .tsr-color-purple</li>
</ul>

<span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>
                    </article>    

                    <article class="col-5 desc">
                        <a href="tsr----STANDALONE-ZIP/tsr-module-table.zip" class="tsr-btn tsr-btn-100">Download ZIP</a>
                    </article>    

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-mediaTable">

    <!-- - - - ADD HERE -> The header - - - -->

    <!-- - - - ADD HERE -> The table - - - -->

    <!-- - - - ADD HERE -> The footer - - - -->

</section></code></pre>



<pre style="margin:4px 0 0;"><code data-language="html"><!-- - - - The header- - - -->

    <header class="tsr-module-mediaTable-header" >
        <div class="tsr-container">
            <span>
                Table header
            </span>    
        </div>
    </header>

<!-- Or purpule -->

    <header class="... tsr-color-purple" >
        ...
    </header></code></pre>

<pre style="margin:4px 0 0;"><code data-language="html"><!-- - - - The table - - - -->
 
        <div class="tsr-container" >

              <table class="tsr-module-mediaTable">
                <thead>
                  <tr>
                    <th class="essential persist">...</th>
                    <th class="optional">...</th>
                    <th class="essential">...</th>
                   
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>...</td>
                    <td>...</td>
                    <td>...</td>
                    
                  </tr>
                  
                </tbody>
              </table>

        </div>
     </code></pre>

<pre style="margin:4px 0;"><code data-language="html"><!-- - - - The footer * ** ***  - - - --> 

    <footer class="tsr-module-mediaTable-footer">
        <div class="tsr-container">
            <i class="tsr-star-1">...</i>
            <i class="tsr-star-2">...</i>
            <i class="tsr-star-3">...</i>   
        </div>
    </footer></code></pre>


                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->


<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>

    <script src="tsr-MODULES/tsr-table/tsr-mediaTable.min.js"></script>

    <script type="text/javascript">
    $(document).ready(function(){
      
      $('.tsr-section-mediaTable .tsr-module-mediaTable').mediaTable({menuTitle:"Choose table data"});
      
    });
    </script>

  
  
</body>
</html>