<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Typography | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

        <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Typography</span>
                    </span>
               
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ******************** FONTS ********************* -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs pb44">
            <div class="tsr-container">


                <div class="column col-full">
                    <span class="demo-header-1"><span>Fonts</span></span>
                </div>



<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">
                    <p>We are using Helvetica Neue as first with normal fallback all th way to sans-serif. No @fontface font download to save bandwidth for performance.
                    </p>    
                    <span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>"tsr-typo", This class need to be added to parent or body</li>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>  
                        </ul>


                    
                </div>    
                 <div class="col-full mb44">
                    <a href="tsr----STANDALONE-ZIP/tsr-component-typography.zip" class="tsr-btn">Download ZIP</a>
                </div> 

<!-- - - - HTML Code - - - --> 

                <div class="col-half">

                    <span class="demo-header-2"><span>Helvetica Neue</span></span>
                    <span class="demo-header-3"><span>$font-1</span></span>
                   
                    <div class="special-font font-1">
                        <span class="uppercase">Uppercase  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="">Normal  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="italic">Italic  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="bold">Bold  Abcdefghijklmnopqrstuvxzyåäö</span>
                    </div>

                </div><!-- // .col-half  -->




                <div class="col-half font-2 hide">

                    <span class="demo-header-2"><span>Arial</span></span>
                    <span class="demo-header-3"><span>$font-2</span></span>

                    <div class="special-font font-2">
                        <span class="uppercase">Uppercase  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="">Normal  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="italic">Italic  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="bold">Bold  Abcdefghijklmnopqrstuvxzyåäö</span>
                    </div> 

                </div><!-- // .col-half  -->



<!-- - - - Snippet - - - --> 

                    <div class="col-half snippet">

<pre><code data-language="css">{
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
}</code></pre>

                    </div> 

            </div><!-- // container -->
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ****************** TYPOGRAPHY ****************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44 show-docs">
            <div class="tsr-container">



                <div class="column col-full">
                    <span class="demo-header-1"><span>Typography</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <div class="col-full desc">


                </div>    

<!-- - - - HTML Code - - - --> 


                <div class="col-half">

                   <span class="demo-header-2"><span>Headings</span></span>

                    <span class="demo-header-3"><span>&lt;H&gt;</span></span>
                   
                        <h1>Heading 1</h1>
                        <h2>Heading 2</h2>
                        <h3>Heading 3</h3>
                        <h4>Heading 4</h4>
                        <h5>Heading 5</h5>
                        <h6>Heading 6</h6>


                    <span class="demo-header-3"><span>&lt;ul&gt; LIST</span></span>
                    <ul>
                        <li>This is a list item in an unordered list</li>
                        <li>An unordered list is a list in which the sequence of items is not important. Sometimes, an unordered list is a bulleted list. And this is a long list item in an unordered list that can wrap onto a new line. </li>
                        <li>
                            Lists can be nested inside of each other
                            <ul>
                                <li>This is a nested list item</li>
                                <li>This is another nested list item in an unordered list</li>
                            </ul>
                        </li>
                        <li>This is the last list item</li>
                    </ul>  
                    <span class="demo-header-3"><span>&lt;ol&gt; LIST</span></span>
                    <ol>
                        <li>This is a list item in an ordered list</li>
                        <li>An ordered list is a list in which the sequence of items is important. An ordered list does not necessarily contain sequence characters.</li>
                        <li>
                            Lists can be nested inside of each other
                            <ol>
                                <li>This is a nested list item</li>
                                <li>This is another nested list item in an ordered list</li>
                            </ol>
                        </li>
                        <li>This is the last list item</li>
                    </ol>
                    <span class="demo-header-3"><span>&lt;dl&gt; LIST</span></span> 
                    <dl>
                        <dt>Definition List</dt>
                        <dd>A number of connected items or names written or printed consecutively, typically one below the other.</dd>
                        <dt>This is a term.</dt>
                        <dd>This is the definition of that term, which both live in a <code>dl</code>.</dd>
                        <dt>Here is another term.</dt>
                        <dd>And it gets a definition too, which is this line.</dd>
                        <dt>Here is term that shares a definition with the term below.</dt>
                        <dd>And it gets a definition too, which is this line.</dd>
                    </dl>    


                </div><!-- // .col-half  -->

                <div class="col-half">

                    <span class="demo-header-2"><span>Text</span></span>
                    <span class="demo-header-3"><span>&lt;P&gt; Preamble</span></span>

                    
                        <p class="preamble">Paragraf, setting about it  as methodically as men might smoke out a wasps' nest, the Martians spread this strange stifling vapour over the Londonward country. The horns of the crescent slowly moved apart.</p>

                    <span class="demo-header-3"><span>&lt;P&gt; Paragraf</span></span>

                    
                        <p>Paragraf, setting <strong>strong</strong> about  it as methodically as men <b>b element</b> might smoke out a <i>i element</i> wasps nest, the Martians spread this strange stifling vapour over the Londonward country. The horns of the crescent slowly moved apart, until at last they <u>u&nbsp;element</u> formed a line <a href="#">link in text</a> from Hanwell to Coombe and Malden. All night through <abbr title="HyperText Markup Language">HTML</abbr> their destructive tubes <s>advanced</s>.</p>


                        <span class="demo-header-3"><span>&lt;P&gt; WYSIWYG</span></span>
                        
    <p><a href="#">This is a text link</a></p>

    <p><strong>Strong is used to indicate strong importance</strong></p>

    <p><em>This text has added emphasis</em></p>

    <p>The <b>b element</b> is stylistically different text from normal text, without any special importance</p>

    <p>The <i>i element</i> is text that is set off from the normal text</p>

    <p>The <u>u element</u> is text with an unarticulated, though explicitly rendered, non-textual annotation</p>

    <p><del>This text is deleted</del> and <ins>This text is inserted</ins></p>

    <p><s>This text has a strikethrough</s></p>

    <p>Superscript<sup>®</sup></p>

    <p>Subscript for things like H<sub>2</sub>O</p>

    <p><small>This small text is small for for fine print, etc.</small></p>

    <p>Abbreviation: <abbr title="HyperText Markup Language">HTML</abbr></p>

    <p>Keybord input: <kbd>Cmd</kbd></p>

    <p><q cite="https://developer.mozilla.org/en-US/docs/HTML/Element/q">This text is a short inline quotation</q></p>

    <p><cite>This is a citation</cite>

    </p><p>The <dfn>dfn element</dfn> indicates a definition.</p>

    <p>The <mark>mark element</mark> indicates a highlight</p>

    <p><code>This is what inline code looks like.</code></p>

    <p><samp>This is sample output from a computer program</samp></p>

    <p>The <var>variarble element</var>, such as <var>x</var> = <var>y</var></p>



<span class="demo-header-3"><span>&lt;blockquote&gt; block quotation</span></span>

    <blockquote>
    A block quotation (also known as a long quotation or extract) is a quotation in a written document, that is set off from the main text as a paragraph, or block of text, and typically distinguished visually using indentation and a different typeface or smaller size quotation.
</blockquote>

                </div><!-- // .col-half  -->
      

            </div><!-- // container -->
        </section><!-- // row  -->






          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  
  
</body>
</html>