<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Style guide | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>


        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr--CORE/tsr-all-ie8.css">
        <![endif]-->


</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>


<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Style guide</span>
                    </span>
               
        </section><!-- // row  END -->



<!-- ************************************************ -->
<!-- ********************* COLORS  ****************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">

                <ul class="nav-section">  
                    <li class="docs u-icon-code"></li>
                </ul> 

        <div class="tsr-row">

                <div class="column col-full"><span class="demo-header-1"><span>Colours</span></span></div>


<!-- - - - Color palette - - - --> 

                 <div class="col-half">
                    <span class="demo-header-3"><span>Primary colours</span></span>
                    
                    <ul class="colors">
                        <li class="p1"><span>$purple-c</span></li>
                         <li class="p1"><span class="l">$purple-h</span><span>$purple-c</span><span class="d">$purple-t</span></li>
                        
                    </ul>

                    <span class="demo-header-3"><span>Light core base colour</span></span>
                    
                    <ul class="colors">
                        <li class="l1"><span>$white</span></li>
                        <li class="l2"><span>$clay-c</span></li>
                        <li class="l3"><span>$lightgray-c</span></li>
                    </ul>                     

                    <span class="demo-header-3"><span>Dark core base colour</span></span>
                    
                    <ul class="colors">
                        <li class="d1"><span>$black</span></li>
                        <li class="d2"><span>$darkpurple-c</span></li>
                        <li class="d3"><span>$darkgrey-c</span></li>
                    </ul> 

                    <span class="demo-header-3"><span>Interaction colours</span></span>
                    
                    <ul class="colors">
                        <li class="i1"><span>$link</span></li>
                        <li class="i2"><span>$link-hover</span></li>
                        <li class="i3"><span>$link-click</span></li>
                    </ul>

                </div><!-- // .col-half  -->

                <div class="col-half">
                    
                    <span class="demo-header-3"><span>Greyscale</span></span>
                    
                    <ul class="colors">
                        <li class="g1"><span class="l">$lightgrey-h</span><span>$lightgrey-c</span><span class="d">$lightgrey-t</span></li>
                        <li class="g2"><span class="l">$clay-h</span><span>$clay-c</span><span class="d">$clay-t</span></li>
                        <li class="g3"><span class="l">$darkgrey-h</span><span>$darkgrey-c</span><span class="d">$darkgrey-t</span></li>
                    </ul> 

                    <span class="demo-header-3"><span>Accent colours</span></span>

                     <ul class="colors">
                        <li class="a1"><span class="l">$yellow-h</span><span>$yellow-c</span><span class="d">$yellow-t</span></li>
                        <li class="a2"><span class="l">$orange-h</span><span>$orange-c</span><span class="d">$orange-t</span></li>
                        <li class="a3"><span class="l">$green-h</span><span>$green-c</span><span class="d">$green-t</span></li>
                        <li class="a4"><span class="l">$blue-h</span><span>$blue-c</span><span class="d">$blue-t</span></li>
                        <li class="a5"><span class="l">$turquoise-h</span><span>$turquoise-c</span><span class="d">$turquoise-t</span></li>
                        <li class="a6"><span class="l">$pink-h</span><span>$pink-c</span><span class="d">$pink-t</span></li>
                    </ul>
              
                </div><!-- // .col-half  -->

        </div><!-- // .row END -->
 
                


            </div><!-- // container -->
        </section><!-- // row  SECTION END -->

<!-- ************************************************ -->
<!-- ******************** FONTS ********************* -->
<!-- ************************************************ -->

        <section class="tsr-row pb44">
            <div class="tsr-container">



                <div class="column col-full">
                    <span class="demo-header-1"><span><a href="tsr-components-typography.php" >Typography<span class="u-icon-arrow-right"></span></a></span></span>
                </div>

  

<!-- - - - HTML Code - - - --> 
<div class="tsr-row">
                <div class="col-half">

                    <span class="demo-header-2"><span>Helvetica Neue</span></span>
                    <span class="demo-header-3"><span>$font-1</span></span>
                   
                    <div class="special-font font-1">
                        <span class="uppercase">Uppercase  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="">Normal  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="italic">Italic  Abcdefghijklmnopqrstuvxzyåäö</span>
                        <span class="bold">Bold  Abcdefghijklmnopqrstuvxzyåäö</span>
                    </div>

                </div><!-- // .col-half  -->

                <div class="col-half">

                    <span class="demo-header-2"><span>Text</span></span>
                     <span class="demo-header-3"><span>&lt;P&gt; Paragraf</span></span>
                    
                        <p>Paragraf, setting <strong>strong</strong> about  it as methodically as men <b>b element</b> might smoke out a <i>i element</i> wasps nest, the Martians spread this strange stifling vapour over the Londonward country. The horns of the crescent slowly moved apart, until at last they <u>u&nbsp;element</u> formed a line <a href="#">link in text</a> from Hanwell to Coombe and Malden. All night through <abbr title="HyperText Markup Language">HTML</abbr> their destructive tubes <s>advanced</s>.</p>


                </div><!-- // .col-half  -->


            </div>

   

            </div><!-- // container -->
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ******************** Buttons ******************* -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">



                <div class="col-full">
                    <span class="demo-header-1"><span><a href="tsr-components-buttonsAndLinks.php" >Buttons &amp; Links<span class="u-icon-arrow-right"></span></a></span></span>
                </div>

  

<!-- - - - HTML Code - - - --> 

                <div class="col-3">
                        <span class="demo-header-3"><span>.tsr-btn</span></span>
                        <a href="#" class="tsr-btn">Normal</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-disabled</span></span>
                        <a href="#" class="tsr-btn tsr-btn-disabled">Disabled</a>
                </div>

                <div class="col-6">
                        <span class="demo-header-3"><span>... .tsr-btn-100</span></span>
                        <a href="#" class="tsr-btn tsr-btn-100">Version 100%</a>
                </div>


                <div class="col-full">
                    <span class="demo-header-2"><span>Colors</span></span>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-purple</span></span>
                        <a href="#" class="tsr-btn tsr-btn-purple tsr-btn-100">Purple</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-pink</span></span>
                        <a href="#" class="tsr-btn tsr-btn-pink tsr-btn-100">Pink</a>
                </div>


                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-blue</span></span>
                        <a href="#" class="tsr-btn tsr-btn-blue tsr-btn-100">Blue</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-orange</span></span>
                        <a href="#" class="tsr-btn tsr-btn-orange tsr-btn-100">Orange</a>
                </div>



            </div><!-- // container -->
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ******************** Pagination ******************* -->
<!-- ************************************************ -->

        <section class="tsr-row pb44">
            <div class="tsr-container">



                <div class="col-full">
                    <span class="demo-header-1"><span><a href="tsr-components-pagination.php" >Pagination<span class="u-icon-arrow-right"></span></a></span></span>
                </div>

  

<!-- - - - HTML Code - - - --> 

                <div class="col-12">
                        <span class="demo-header-3"><span>.tsr-pagination</span></span>
                        <div class="tsr-pagination">
    <div class="tsr-center">
        <a href="#" class="tsr-dir-first">First</a>
        <a href="#" class="tsr-dir-previous">Previus</a>
        <a href="#">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#" class="tsr-active">4</a>
        <a href="#">5</a>
        <a href="#">6</a>
        <a href="#">7</a>
        <a href="#" class="tsr-elipsis">...</a>
        <a href="#">19</a>
        <a href="#" class="tsr-dir-next">Next</a>
        <a href="#" class="tsr-dir-last">Last</a>
    </div>
</div>
                </div>




            </div><!-- // container -->
        </section><!-- // row  -->




<!-- ************************************************ -->
<!-- ********************* ICONS ******************** -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">

                <ul class="nav-section">
                    
                    <li class="acc acc-1" data-color-theme="acc-1" ></li>
                    <li class="acc acc-2" data-color-theme="acc-2"></li>
                    <li class="acc acc-3" data-color-theme="acc-3"></li>
                    <li class="acc acc-4" data-color-theme="acc-4"></li>
                    <li class="acc acc-5" data-color-theme="acc-5" ></li>
                    <li class="acc acc-6" data-color-theme="acc-6"></li>
                    <li class="acc acc-7" data-color-theme="acc-7"></li>
                    <li class="acc acc-8" data-color-theme="acc-8"></li>


                </ul> 

        <div class="tsr-row">

                <span class="demo-header-1"><span><a href="tsr-components-icons.php" >Icons<span class="u-icon-arrow-right"></span></a></span></span>



<!-- - - - Icon demo- - - --> 

                 <div class="col-full icon-presentation">
                    <span class="demo-header-3"><span>Glyphs</span></span>
                    
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-teliasonera"></span><span class="mls">teliasonera</span>
                        </div>

                    </div>

                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-mobile"></span><span class="mls">mobile</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>


                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-buy"></span><span class="mls">buy</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>

                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-travelabroad"></span><span class="mls">travelabroad</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>

                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-sms"></span><span class="mls">sms</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>

                     <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-xls"></span><span class="mls">xls</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-writeemail"></span><span class="mls">writeemail</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-wireless"></span><span class="mls">wireless</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-weather"></span><span class="mls">weather</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-voiceswitch"></span><span class="mls">voiceswitch</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>
                    <div class="glyph fs1">
                        <div class="clearfix bshadow0 pbs">
                            <span class="ts-icon-videocontent"></span><span class="mls">videocontent</span>
                        </div>
                        
                        <div class="fs0 bshadow0 clearfix noLiga-true">
                            
                            
                        </div>
                    </div>

                </div> <!-- // .icon-presentation END -->






        </div><!-- // .row END -->




            </div><!-- // container -->
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- **************** TACTICAL ELEMENTS ************* -->
<!-- ************************************************ -->

        <section class="tsr-row pb44">
            <div class="tsr-container tsr-forms">


        <div class="tsr-row">

                <div class="column col-full"><span class="demo-header-1"><span><a href="tsr-components-tacticalElements.php" >Tactical elements<span class="u-icon-arrow-right"></span></a></span></span></div>




                    <div class="col-5 pull-1">
                        <span class="demo-header-2"><span>SPEACH BUBBLE</span></span>
                    </div>


                    <div class="col-6">
                        <span class="demo-header-2"><span>PRODUCT WRAP</span></span>
                    </div>

 

<!-- - - - HTML Code - - - --> 


                    <div class="col-5 pull-1">
                       
                        <figure class="tsr-tactical-speach-bubble">
                            <header class="tsr-header">From the right</header>Jumps over the lazy dog, jump the lazy dog lorem ipsum.
                        </figure>

                    </div>


                    <div class="col-6">

                        <figure class="tsr-tactical-product-wrap arrow">
                                <header class="tsr-header">The quick brown</header><span class="tsr-text">Jumps over the lazy dog, jump<br>the lazy dog lorem ipsum</span>
                        </figure>

                    </div>


                    <div class="col-full">
                        <span class="demo-header-2"><span>FLASHES &amp; RIBBONS</span></span>
                    </div>

   


<!-- - - - HTML Code - - - --> 

                    <div class="col-1">
                       <figure class="tsr-tactical-flash tsr-flash-usp-1"><span>4G</span></figure>
                    </div>

                    <div class="col-1">
                       <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-color-blue"><span>HD<small>Voice</small></span></figure>
                    </div>  

                    <div class="col-1 pull-1">
                       <figure class="tsr-tactical-flash tsr-flash-price-3 tsr-color-purple"><span><small>From</small>30€<small>/month</small></span></figure>
                    </div>

                    <div class="col-1">
                       <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-1"><span>4G</span></figure>
                    </div>

                    <div class="col-1">
                       <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-usp-2 tsr-color-blue"><span>HD<small>Voice</small></span></figure>
                    </div>  

                    <div class="col-1 pull-1">
                       <figure class="tsr-tactical-flash tsr-tactical-round tsr-flash-price-3 tsr-color-purple"><span><small>From</small>30€<small>/month</small></span></figure>
                    </div>

                    <div class="col-1">
                      <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                    </div>

                    <div class="col-1">
                      <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>
                    </div>

                </div>
       



            </div><!-- // container -->
        </section><!-- // row  -->




<!-- ************************************************ -->
<!-- ******************** Grid ******************* -->
<!-- ************************************************ -->

        <section class="tsr-row dark pb44">
            <div class="tsr-container">



                <div class="col-full">
                    <span class="demo-header-1"><span><a href="tsr-components-grid.php" >Grid<span class="u-icon-arrow-right"></span></a></span></span>
                </div>

  

<!-- - - - HTML Code - - - --> 

               

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>TSR-UI</span>
                                        grid, col-3
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>TSR-UI</span>
                                        grid, col-3
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>TSR-UI</span>
                                        grid, col-3
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>TSR-UI</span>
                                        grid, col-3
                                </header>   
                            </div>
                        </article>
                    </div>
                    
    



            </div><!-- // container -->
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ******************** Forms ******************* -->
<!-- ************************************************ -->

        <section class="tsr-row tsr-forms pb44">
            <div class="tsr-container">



                <div class="col-full">
                    <span class="demo-header-1"><span><a href="tsr-components-forms.php" >Forms<span class="u-icon-arrow-right"></span></a></span></span>
                </div>

  

<!-- - - - HTML Code - - - --> 

               
     
<!-- *** Inputs states *** -->
                                        <div class="tsr-row">

                                          <div class="col-3">
                                                <label>Default</label>
                                                <input type="text" value="Default" />

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Focus</label>
                                                <input type="text" value="Fake focus class" class="focus" />

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Disabled</label>
                                                <input type="text" disabled value="Disabled" />
                                            
                                          </div><!-- // col-3 -->



                                          <div class="col-3 invalid">
                                                <label>Invalid</label>
                                                <input type="text" value="Invalid" />
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                          </div><!-- // col-3 -->

                                        </div><!-- // row END -->
                                        
                                        
<!-- *** Select box states *** -->
                                        <div class="tsr-row">

                                            <div class="col-3">
                                                <label>Selectbox</label>
                                                <div class="select-container"><select><option selected>Phone</option><option>iPhone</option><option>Samsung</option></select></div>
                                         
                                            </div><!-- // col-3 -->

                                            <div class="col-3">
                                                <label>Selectbox</label>
                                                <div class="select-container"><select disabled><option selected>Disabled</option><option>Black</option><option>White</option></select></div>
                                               
                                            </div><!-- // col-3 -->



                                            <div class="col-3 invalid push-3">
                                            <label>Selectbox</label>
                                                <div class="select-container"><select><option selected>Invalid</option><option>Option 1</option><option>Option 2</option></select></div>
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                            </div><!-- // col-3 -->

                                        </div><!-- // row END -->                                   
 

                                      <div class="tsr-row">

<!-- *** Radio buttons states ***-->

                                            <div class="col-3">
                                                <header class="label">Radio default</deader>

                                                <label for="radio-1"><input type="radio" checked id="radio-1" name="defaultRadio" /> Alt-1</label>
                                                <label for="radio-2"><input type="radio" id="radio-2" name="defaultRadio" /> Alt-2</label>
                                                <label for="radio-3"><input type="radio" id="radio-3" name="defaultRadio" /> Alt-3</label>

                                                
                                            </div><!-- // col-3 -->

               
                                            <div class="col-3">
                                                <header class="label">Radio options</deader>

                                                <label for="radio-4"><input type="radio" disabled id="radio-4" name="optionsRadioDisabled" /> Disabled</label>
                                                <label for="radio-5"><input type="radio" checked  disabled id="radio-5" name="optionsRadio RadioDisabled" /> Disabled</label>
                                                <label for="radio-6 " class="invalid"><input type="radio" checked  id="radio-6" name="optionsRadio" /> Invalid</label>
                                                <label for="radio-7 " class="invalid"><input type="radio" id="radio-7" name="optionsRadio" /> Invalid</label>
                                               

                                            </div><!-- // col-3 -->

<!-- *** Checkbox states ***-->

                                            <div class="col-3">
                                                <header class="label">Checkbox default</deader>

                                                <label for="check-1"><input type="checkbox" checked id="check-1" /> Checked</label>
                                                <label for="check-2"><input type="checkbox" id="check-2" /> Unchecked</label>
                                               
                                            </div><!-- // col-3 -->

               
                                            <div class="col-3">

                                               <header class="label">Checkbox options</deader>
                                               <label for="check-3"><input type="checkbox" id="check-3" disabled /> Disabled</label>
                                               <label for="check-4"><input type="checkbox" checked id="check-4" disabled /> Disabled</label>
                                               <label for="check-5" class="invalid"><input type="checkbox" checked id="check-5" /> Invalid</label>
                                               <label for="check-6" class="invalid"><input type="checkbox"  id="check-6" /> Invalid</label>
                                               
                                            </div><!-- // col-3 -->

                                            
                                        </div><!-- // row END --> 
              
<!-- *** Textarea *** -->
                                        <div class="tsr-row">

                                          <div class="col-3">
                                                <label>Default</label>
                                                <textarea>Textarea</textarea>

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Focus</label>
                                                <textarea class=" focus">Fake focus class</textarea>

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Disabled</label>
                                                <textarea disabled>Disabled</textarea>
                                            
                                          </div><!-- // col-3 -->



                                          <div class="col-3 invalid">
                                                <label>Invalid</label>
                                                <textarea>Invalid</textarea>
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                          </div><!-- // col-3 -->

                                        </div><!-- // row END -->
                                        
                    
    



            </div><!-- // container -->
        </section><!-- // row  -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  
  <!-- TSR-FORMS -->
  <script src="tsr-COMPONENTS/tsr-forms/tsr-forms.js"></script>
  
</body>
</html>