<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Promotion | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

<!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-promotion/_tsr-promotion-ie8.css">
<![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
            <span>
                <span>Promotion</span>
            </span>
               
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="tsr-row">
            
                





<!-- - - - HTML Code - - - -->

    <div class="tsr-row" style="margin:50px auto;">

        <section class="tsr-section-promotion">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-1.png" />
                        </figure>
                        <header>The All New iPhone 5s - Changes everything again</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-2.png" />
                        </figure>
                        <header>Mixed campaign, offers, news   and product pushes</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-2.png" />
                        </figure>
                        <header>Short</header>
                        <p>Little text...</p>
                    </a>

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-4.png" />
                        </figure>
                        <header>Short</header>
                        <p>Little text...</p>
                    </a>                    

               </div><!-- // container -->
         </section><!-- tsr-section-promotion" END -->  

    </div><!-- // .row END -->         
  
<!-- - - - HTML Code - - - -->

    <div class="tsr-row" style="margin:50px auto;">

        <section class="tsr-section-promotion tsr-color-white">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-1.png" />
                        </figure>
                        <header>The All New iPhone 5s - Changes everything again</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-2.png" />
                        </figure>
                        <header>Mixed campaign, offers, news   and product pushes</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-3.png" />
                        </figure>
                        <header>Short</header>
                        <p>Little text...</p>
                    </a>                   

               </div><!-- // container -->
         </section><!-- tsr-section-promotion" END -->  

    </div><!-- // .row END -->




<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Promotion</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

                        Full width section. Height is dynamic, jQuery is handling the height of "header" and "p" for proper design at all breakpoints.
                        Can be used in white and grey. The css handles 2-6 promotions.

                        <ul>
                          <li>2-6 promotions</li>
                          <li>Grey is default</li>
                          <li>.tsr-color-white</li>
                        </ul>

                        <span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">


 <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
 <a href="tsr----STANDALONE-ZIP/tsr-section-promotion.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html">
// Default

<a href="#" class="tsr-module-promotion">
    
    <figure>
        <img src="..." />
    </figure>
    
    <header>...</header>
    
    <p>...</p>
    
</a>


// Colour

<a href="#" class="... tsr-color-white">
    ...
</a>

</code></pre>



                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



        </section>  




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->



          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  

  <script src="tsr-SECTIONS/tsr-promotion/tsr-promotion.js"></script>

  
</body>
</html>