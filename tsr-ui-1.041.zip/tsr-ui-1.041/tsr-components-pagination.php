<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Pagination | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


                <?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span >
                        <span>Pagination</span>
                    </span>
               
        </section>

<!-- ************************************************ -->
<!-- ***************** PAGINATION ******************* -->
<!-- ************************************************ -->


        <section class="tsr-row show-docs">
            <div class="tsr-container">


                <div class="col-full">
                    <span class="demo-header-1"><span>Pagination</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

<p>This is just an embryo of a pagination, we encountered too many variations both technical and usage. </ br>
Get inspiered, use and adjust according to your needs. No specific mobile adjustment has been added.</p>

                <div class="col-full mb44">
                    <a href="tsr----STANDALONE-ZIP/tsr-component-pagination.zip" class="tsr-btn">Download ZIP</a>
                </div> 

                </article>    

<!-- - - - HTML Code - - - --> 

                <div class="col-full">
                  
                        <span class="demo-header-3"><span>.tsr-pagination</span></span>

                        <div class="tsr-pagination">
                          <div class="tsr-center">
                            <a href="#" class="tsr-dir-first" >First</a>
                            <a href="#" class="tsr-dir-previous" >Previus</a>
                            <a href="#" >1</a>
                            <a href="#" >2</a>
                            <a href="#" >3</a>
                            <a href="#" class="tsr-active" >4</a>
                            <a href="#" >5</a>
                            <a href="#" >6</a>
                            <a href="#" >7</a>
                            <a href="#" class="tsr-elipsis">...</a>
                            <a href="#" >19</a>
                            <a href="#" class="tsr-dir-next" >Next</a>
                            <a href="#" class="tsr-dir-last" >Last</a>
                          </div>
                        </div>

                </div>

     
<!-- - - - Snippet - - - --> 

                <article class="col-full snippet mt20">

<pre><code data-language="html"><div class="tsr-pagination">
    <div class="tsr-center">
        <a href="#" class="tsr-dir-first" >First</a>
        <a href="#" class="tsr-dir-previous" >Previus</a>
        <a href="#" >1</a>
        <a href="#" >2</a>
        <a href="#" >3</a>
        <a href="#" class="tsr-active" >4</a>
        <a href="#" >5</a>
        <a href="#" >6</a>
        <a href="#" >7</a>
        <a href="#" class="tsr-elipsis">...</a>
        <a href="#" >19</a>
        <a href="#" class="tsr-dir-next" >Next</a>
        <a href="#" class="tsr-dir-last" >Last</a>
    </div>
</div></code></pre>

                </article>


            </div><!-- // tsr-container -->
        </section><!-- // tsr-row  -->

  
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
  
</body>
</html>