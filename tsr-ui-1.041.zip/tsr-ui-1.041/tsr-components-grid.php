<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Grid | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>


        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->


</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->

  
    <section class="utilitie-styles">


<!-- - - - Navigation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

        <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
                <span>Grid</span>
        </section><!-- // row  -->



<!-- ************************************************ -->
<!-- ******************* COLUMNS ******************** -->
<!-- ************************************************ -->

        <section class=" show-docs pb44">
            <div class="tsr-container">

                <div class="col-full">
                    <span class="demo-header-1"><span>Grid</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

<p>A grid have been defined to keep things together. More details about the grid you can find in brandzone.<br/><br/>
The grid is done for those who want to use a grid semantic approach. We recommend content based breakpoint adjustments, modules and section SASS files are adjusted to suit both needs.
The most important tag of the grid is <strong>.tsr-container</strong> which handles the width of the content/wrapper at each breakpoint.</p>

                <div class="col-full mb44">
                    <a href="tsr----STANDALONE-ZIP/tsr-component-grid.zip" class="tsr-btn" style="z-index:10; position:relative;">Download ZIP</a>
                </div> 

                    <span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>"tsr-grid", This class need to be added to parent or body</li>  

                        </ul>

                </article>     


<!-- - - - HTML Code - - - -->

  <div class="tsr-row maximized">
                      <div class="col-full">
                          <span class="demo-header-3"><span>Maximized</span></span>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>
                    
  </div> <!-- //tsr-row -->

  <div class="tsr-row ">
                    <div class="col-full">
                          <span class="demo-header-3"><span>Normal</span></span>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder">
                            <div>
                                <header>
                                    <span>Product</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>
                    
        </div> <!-- //tsr-row -->



<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-half snippet">

<pre><code data-language="html">// Wrap grid:
<section class="tsr-grid">...</section>

// Conatiner (For the breakpoint content width)
<div class="tsr-container">...</div>  

// Row
<div class="tsr-row">...</div>  

// Column 1-12 + half and full
<div class="col-full">...</div>
<div class="col-half">...</div>
<div class="col-1">   ...</div>
<div class="col-12">  ...</div>

// Maximized columns inside, no gutters
<div class="tsr-row maximized">...</div>  

</code></pre>

                    </article> 

                    <article class="col-half snippet">

<pre><code data-language="html"><section class="tsr-grid">

  <div class="tsr-container">
    
    <div class="tsr-row">

      <div class="col-3">...</div>
      <div class="col-3">...</div>
      <div class="col-3">...</div>
      <div class="col-3">...</div>

    </div>

  </div>
                
</div></code></pre>

                    </article> 

                </div><!-- // .tsr-row END -->

            </div><!-- // container -->
        </section><!-- // tsr-row - SECTION END -->



<!-- ************************************************ -->
<!-- ******************* COLUMNS ******************** -->
<!-- ************************************************ -->

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>COLUMS</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

Grid columns demo. No tsr-rows.

                    </article>    

<!-- - - - HTML Code - - - -->

                    <div class="col-full">
                          <span class="demo-header-3"><span>None semantic</span></span>
                    </div>

                    <div class="col-12">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-12 / col-full</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-8">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-8</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-4">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-4</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-6">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-6 / col-half</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>

                    <div class="col-3">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-3</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>
                    
                    <div class="col-2">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-2</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>  
                    <div class="col-1">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>col-1</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>  

                    <div class="col-6 pull-3 push-3">
                        <article class="tsr-module tsr-module-placeholder size-small">
                            <div>
                                <header>
                                    <span>push-3 &amp; pull-3</span>
                                        grid
                                </header>   
                            </div>
                        </article>
                    </div>    



                   


                </div><!-- // .tsr-row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html"><div class="col-1">        ...</div>
<div class="col-12">       ...</div>
<div class="col-x push-1"> ...</div>
<div class="col-x push-12">...</div>
<div class="col-x pull-1"> ...</div>
<div class="col-x pull-12">...</div>               
</code></pre>


                    </article> 

                </div><!-- // .tsr-row END -->

            </div><!-- // container -->
        </section><!-- // tsr-row - SECTION END -->


<!-- ************************************************ -->
<!-- ********************* tsr-ROWS ********************* -->
<!-- ************************************************ -->

        <section class="show-docs pb44">
            <div class="tsr-container">
                

<!-- - - - Header - - - --> 
                
                    <div class="col-full">
                        <span class="demo-header-1"><span>tsr-Rows</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">
Rows and column can be nested as needed to achieve wanted layout.
                    </article>    

<!-- - - - HTML Code - - - --> 

                    <div class="col-full">
                          <span class="demo-header-3"><span>None semantic</span></span>
                    </div>
                  
                      <div class="col-12">
                          <article class="tsr-module tsr-module-placeholder size-small color-clay-t">
                              <div>
                                  <header>
                                      <span>No tsr-Row</span>
                                          grid
                                  </header>   
                              </div>
                          </article>
                      </div>
                  

                  <div class="tsr-row">
                      <div class="col-12">
                          <article class="tsr-module tsr-module-placeholder size-small color-clay-c">
                              <div>
                                  <header>
                                      <span>tsr-Row</span>
                                          grid
                                  </header>   
                              </div>
                          </article>
                      </div>
                  </div>


                  <div class="tsr-row">
                    <div class="tsr-row">
                      <div class="col-12">
                          <article class="tsr-module tsr-module-placeholder size-small color-clay-t">
                              <div>
                                  <header>
                                      <span>tsr-Row direct in tsr-ROW</span>
                                          grid
                                  </header>   
                              </div>
                          </article>
                      </div>
                    </div>
                  </div>

                  <div class="tsr-row">
                      <div class="col-12">
                          <article class="tsr-module tsr-module-placeholder size-small color-clay-h">
                              <div>

                              <!-- Nested ** START ** -->

                                  <div class="tsr-row">
                                      <div class="col-6">
                                          <article class="tsr-module tsr-module-placeholder size-small color-clay-c">
                                              <div>
                                                  <header>
                                                      <span>Nested</span>
                                                          grid
                                                  </header>   
                                              </div>
                                          </article>
                                      </div>

                                      <div class="col-6">
                                          <article class="tsr-module tsr-module-placeholder size-small color-clay-c">
                                              <div>
                                                  
                                                  <!-- Nested ** START ** -->

                                                      <div class="tsr-row">
                                                          <div class="col-6">
                                                              <article class="tsr-module tsr-module-placeholder size-small color-clay-h">
                                                                  <div>
                                                                      <header>
                                                                          <span>Nested Nested</span>
                                                                              grid
                                                                      </header>   
                                                                  </div>
                                                              </article>
                                                          </div>

                                                          <div class="col-6">
                                                              <article class="tsr-module tsr-module-placeholder size-small color-clay-h">
                                                                  <div>
                                                                      <header>
                                                                          <span>Nested Nested</span>
                                                                              grid
                                                                      </header>   
                                                                  </div>
                                                              </article>
                                                          </div>
                                                      </div>

                                                  <!-- Nested ** END ** -->  

                                              </div>
                                          </article>
                                      </div>
                                  </div>

                              <!-- Nested ** END ** -->   

                              </div>
                          </article>
                      </div>
                  </div>

                

<!-- - - - Snippet - - - --> 

                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html">  <div class="col-12">
      ...
  </div>
                  

  <div class="tsr-row">
      <div class="col-12">
          ...
      </div>
  </div>


  <div class="tsr-row">
      <div class="tsr-row">
        <div class="col-12">
            ...
        </div>
      </div>
  </div>

  <div class="tsr-row">
      <div class="col-12">
          
          <!-- Nested 1 ** START ** -->

            <div class="tsr-row">
                <div class="col-6">
                   ...
                </div>

                <div class="col-6">

                  <!-- Nested 2 ** START ** -->

                      <div class="tsr-row">
                          <div class="col-6">
                              ...
                          </div>

                          <div class="col-6">
                              ...
                          </div>
                      </div>

                  <!-- Nested 2 ** END ** -->  

                </div>
            </div>

          <!-- Nested 1 ** END ** -->  

      </div>
  </div></code></pre>

                    </article> 

                </div><!-- // .tsr-row END -->

            </div><!-- // container -->
        </section><!-- // tsr-row - SECTION END -->


<!-- ************************************************ -->
<!-- ******************* MAXIMIZED ****************** -->
<!-- ************************************************ -->

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
                <div class="tsr-row">
                    <div class="col-full">
                        <span class="demo-header-1"><span>Maximized</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-full desc">

Is you want to do layouts without gutters, use .tsr-maximize on a parent.

                    </article>    

<!-- - - - HTML Code - - - -->

                    <div class="col-full">
                          <span class="demo-header-3"><span>None semantic</span></span>
                    </div>

                    <div class="tsr-row maximized">

                        <div class="col-6">
                            <article class="tsr-module tsr-module-placeholder size-small color-black">
                                <div>
                                    <header>
                                        <span>Maximized</span>
                                            grid
                                    </header>   
                                </div>
                            </article>
                        </div>

                        <div class="col-6">
                            <article class="tsr-module tsr-module-placeholder size-small color-black">
                                <div>
                                    <header>
                                        <span>Maximized</span>
                                            grid
                                    </header>   
                                </div>
                            </article>
                        </div>

                  </div><!-- //maximized --> 

                    <div class="tsr-row maximized">

                        <div class="col-12">
                            <article class="tsr-module tsr-module-placeholder size-small color-black">
                                <div>

                              <!-- Nested ** START ** -->

                                  <div class="tsr-row">
                                      <div class="col-6">
                                          <article class="tsr-module tsr-module-placeholder size-small color-black">
                                              <div>
                                                  <header>
                                                      <span>Nested</span>
                                                          grid
                                                  </header>   
                                              </div>
                                          </article>
                                      </div>

                                      <div class="col-6">
                                          <article class="tsr-module tsr-module-placeholder size-small color-black">
                                              <div>
                                                  
                                                  <!-- Nested ** START ** -->

                                                      <div class="tsr-row">
                                                          <div class="col-6">
                                                              <article class="tsr-module tsr-module-placeholder size-small color-black">
                                                                  <div>
                                                                      <header>
                                                                          <span>Nested Nested</span>
                                                                              grid
                                                                      </header>   
                                                                  </div>
                                                              </article>
                                                          </div>

                                                          <div class="col-6">
                                                              <article class="tsr-module tsr-module-placeholder size-small color-black">
                                                                  <div>
                                                                      <header>
                                                                          <span>Nested Nested</span>
                                                                              grid
                                                                      </header>   
                                                                  </div>
                                                              </article>
                                                          </div>
                                                      </div>

                                                  <!-- Nested ** END ** -->  

                                              </div>
                                          </article>
                                      </div>
                                  </div>

                              <!-- Nested ** END ** -->  

                                </div>
                            </article>
                        </div>

                        <div class="col-8">
                            <article class="tsr-module tsr-module-placeholder size-small color-black">
                                <div>
                                    <header>
                                        <span>Maximized</span>
                                            grid
                                    </header>   
                                </div>
                            </article>
                        </div>

                        <div class="col-4">
                            <article class="tsr-module tsr-module-placeholder size-small color-black">
                                <div>
                                    <header>
                                        <span>Maximized</span>
                                            grid
                                    </header>   
                                </div>
                            </article>
                        </div>

                  </div><!-- //maximized --> 

                </div><!-- // .tsr-row END -->

<!-- - - - Snippet - - - --> 


                <div class="tsr-row">

                    <article class="col-full snippet">

<pre><code data-language="html">// Maximizes columns inside, no gutters
<div class="tsr-row maximized">...</div> </code></pre>

                    </article> 

                </div><!-- // .tsr-row END -->

            </div><!-- // container -->
        </section><!-- // tsr-row - SECTION END -->


    </section><!-- // utility-styles -->


          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>
  

  
</body>
</html>