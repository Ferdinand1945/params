<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Forms | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>


<body class="tsr-grid tsr-typo">


<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  

    <section class="utilitie-styles">


<!-- - - - Navigation - - - -->   

        <section class="utility-navigation">
            <div class="container">                


                <?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>


<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Forms</span>
                    </span>
               
        </section>


<!-- ************************************************ -->
<!-- ********************* FORMS ******************** -->
<!-- ************************************************ -->

   <section class="tsr-row show-docs">
            <div class="tsr-container">


                <div class="col-full">
                    <span class="demo-header-1"><span>Forms</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

<p>Only default html form elements have been styled. Font icons and jQuery based styling. A plugin is used for the styling and select boxes.</p>
<span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>"tsr-form", This class need to be added to parent or body</li>
                          <li>selectBoxIt.js and it's dependencies are included in "tsr-forms.js"</li>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>  
                        </ul>

                        <a href="tsr----STANDALONE-ZIP/tsr-component-forms.zip" class="tsr-btn mt20 " style="z-index:10; position:relative;">Download ZIP</a> 

                </article>    

<!-- - - - HTML Code - - - --> 
<div class="tsr-container tsr-forms" style="margin:50px auto;">


<!-- *** Inputs states *** -->
                                        <div class="tsr-row">

                                          <div class="col-3">
                                                <label>Default</label>
                                                <input type="text" value="Default" />

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Focus</label>
                                                <input type="text" value="Fake focus class" class="focus" />

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Disabled</label>
                                                <input type="text" disabled value="Disabled" />
                                            
                                          </div><!-- // col-3 -->



                                          <div class="col-3 invalid">
                                                <label>Invalid</label>
                                                <input type="text" value="Invalid" />
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                          </div><!-- // col-3 -->

                                        </div><!-- // row END -->
                                        
                                        
<!-- *** Select box states *** -->
                                        <div class="tsr-row">

                                            <div class="col-3">
                                                <label>Selectbox</label>
                                                <div class="select-container"><select><option selected>Phone</option><option>iPhone</option><option>Samsung</option></select></div>
                                         
                                            </div><!-- // col-3 -->

                                            <div class="col-3">
                                                <label>Selectbox</label>
                                                <div class="select-container"><select disabled><option selected>Disabled</option><option>Black</option><option>White</option></select></div>
                                               
                                            </div><!-- // col-3 -->



                                            <div class="col-3 invalid push-3">
                                            <label>Selectbox</label>
                                                <div class="select-container"><select><option selected>Invalid</option><option>Option 1</option><option>Option 2</option></select></div>
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                            </div><!-- // col-3 -->

                                        </div><!-- // row END -->                                   
 

                                      <div class="tsr-row">

<!-- *** Radio buttons states ***-->

                                            <div class="col-3">
                                                <header class="label">Radio default</deader>

                                                <label for="radio-1"><input type="radio" checked id="radio-1" name="defaultRadio" /> Alt-1</label>
                                                <label for="radio-2"><input type="radio" id="radio-2" name="defaultRadio" /> Alt-2</label>
                                                <label for="radio-3"><input type="radio" id="radio-3" name="defaultRadio" /> Alt-3</label>

                                                
                                            </div><!-- // col-3 -->

               
                                            <div class="col-3">
                                                <header class="label">Radio options</deader>

                                                <label for="radio-4"><input type="radio" disabled id="radio-4" name="optionsRadioDisabled" /> Disabled</label>
                                                <label for="radio-5"><input type="radio" checked  disabled id="radio-5" name="optionsRadio RadioDisabled" /> Disabled</label>
                                                <label for="radio-6 " class="invalid"><input type="radio" checked  id="radio-6" name="optionsRadio" /> Invalid</label>
                                                <label for="radio-7 " class="invalid"><input type="radio" id="radio-7" name="optionsRadio" /> Invalid</label>
                                               

                                            </div><!-- // col-3 -->

<!-- *** Checkbox states ***-->

                                            <div class="col-3">
                                                <header class="label">Checkbox default</deader>

                                                <label for="check-1"><input type="checkbox" checked id="check-1" /> Checked</label>
                                                <label for="check-2"><input type="checkbox" id="check-2" /> Unchecked</label>
                                               
                                            </div><!-- // col-3 -->

               
                                            <div class="col-3">

                                               <header class="label">Checkbox options</deader>
                                               <label for="check-3"><input type="checkbox" id="check-3" disabled /> Disabled</label>
                                               <label for="check-4"><input type="checkbox" checked id="check-4" disabled /> Disabled</label>
                                               <label for="check-5" class="invalid"><input type="checkbox" checked id="check-5" /> Invalid</label>
                                               <label for="check-6" class="invalid"><input type="checkbox"  id="check-6" /> Invalid</label>
                                               
                                            </div><!-- // col-3 -->

                                            
                                        </div><!-- // row END --> 
              
<!-- *** Textarea *** -->
                                        <div class="tsr-row">

                                          <div class="col-3">
                                                <label>Default</label>
                                                <textarea>Textarea</textarea>

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Focus</label>
                                                <textarea class=" focus">Fake focus class</textarea>

                                          </div><!-- // col-3 -->

                                          <div class="col-3">
                                                <label>Disabled</label>
                                                <textarea disabled>Disabled</textarea>
                                            
                                          </div><!-- // col-3 -->



                                          <div class="col-3 invalid">
                                                <label>Invalid</label>
                                                <textarea>Invalid</textarea>
                                               <!-- <i class="form-error-msg">* Error msg...</i> -->
                                          </div><!-- // col-3 -->

                                        </div><!-- // row END -->
                                        
     </div><!-- // container END -->                                    
                                

     
<!-- - - - Snippet - - - --> 

                <article class="col-full snippet mt20">

<pre><code data-language="html">
// Wrap forms:

<div class="... tsr-forms"> 
... 
</div>


/////////////////////////////////


// Input
<input type="text" value="..." />


// Select
<div class="select-container">
  <select>
      <option selected>...</option>
      <option>...</option>
      <option>...</option>
  </select>
</div>
                                         

// Radio
<label for="..."><input type="radio" name="..." />...</label>


// Checkbox
<label for="..."><input type="checkbox" />...</label>


// Textarea
<textarea>Textarea</textarea>


</code></pre>

                </article>



            </div><!-- // container -->
        </section><!-- // row  --> 



<!-- ************************************************ -->
<!-- ************ FORMS WITH VALIDAITION ************ -->
<!-- ************************************************ -->

   <section class="tsr-row show-docs">
            <div class="tsr-container">


                <div class="col-full">
                    <span class="demo-header-1"><span>Form validation</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

<p>Validation recommendation is to use <a href="http://jqueryvalidation.org/" taget="_blank">jqueryvalidation.org</a> validation plugin. (MIT Licensed) <br />
For full plugin documention visit <a href="http://jqueryvalidation.org/documentation/" taget="_blank">jqueryvalidation.org/documentation</a>.</p>
<p>We have one functional addition to the validation part and that is a description "data-desc" wich only works on "inputs" and "textareas". See code exampel below.</p>
<p>The guidelines regarding forms validation you find in brandzone<a href="branzone link comming" taget="_blank"></a> .</p>
<p>Below you have form validation example working with tsr-form styling.</p>

        <div class="tsr-row">
          <div class="col-full">
          <span class="demo-header-2"><span>Dependencies</span></span>
              <ul>
                            <li>Same as tsr-forms above</li>
                            <li>jquery.validate.js</li>
                            <li>tsr-form-validate.js</li>
                        </ul>
          </div>
          <div class="col-6">
        
          <span class="demo-header-2"><span>Built-in validation methods</span></span>    
              <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/required-method">required– Makes the element required.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/remote-method">remote– Requests a resource to check the element for validity.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/minlength-method">minlength– Makes the element require a given minimum length.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/maxlength-method">maxlength– Makes the element require a given maxmimum length.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/rangelength-method">rangelength– Makes the element require a given value range.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/min-method">min– Makes the element require a given minimum.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/max-method">max– Makes the element require a given maximum.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/range-method">range– Makes the element require a given value range.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/email-method">email– Makes the element require a valid email</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/url-method">url– Makes the element require a valid url</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/date-method">date– Makes the element require a date.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/dateISO-method">dateISO– Makes the element require an ISO date.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/number-method">number– Makes the element require a decimal number.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/digits-method">digits– Makes the element require digits only.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/creditcard-method">creditcard– Makes the element require a credit card number.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/equalTo-method">equalTo– Requires the element to be the same as another one</a></li>
              </ul>
                 <span class="demo-header-2"><span>Add-ons -> additional-methods.js</span></span>
               <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/accept-method">accept– Makes a file upload accept only specified mime-types.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/extension-method">extension– Makes the element require a certain file extension.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/phoneUS-method">phoneUS– Validate for valid US phone number.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/require_from_group-method">require_from_group– Ensures a given number of fields in a group are complete.</a></li>
                </ul>
          </div>
          <div class="col-6">
              <span class="demo-header-2"><span>Plugin methods</span></span>
              <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/validate">validate()– Validates the selected form.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/valid">valid()– Checks whether the selected form or selected elements are valid.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/rules">rules()– Read, add and remove rules for an element.</a></li>
              </ul> 
              <span class="demo-header-2"><span>Custom selectors</span></span>
              <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/blank-selector">:blank– Selects all elements with a blank value.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/filled-selector">:filled– Selects all elements with a filled value.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/unchecked-selector">:unchecked– Selects all elements that are unchecked.</a></li>
              </ul> 
              <span class="demo-header-2"><span>Validator</span></span> 
              <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/Validator.form">Validator.form()– Validates the form.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/Validator.element">Validator.element()– Validates a single element.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/Validator.resetForm">Validator.resetForm()– Resets the controlled form.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/Validator.showErrors">Validator.showErrors()– Show the specified messages.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/Validator.numberOfInvalids">Validator.numberOfInvalids()– Returns the number of invalid fields.</a></li>
              </ul>
              <ul>
                <li><a target="_blank" href="http://jqueryvalidation.org/jQuery.validator.addMethod">jQuery.validator.addMethod()– Add a custom validation method.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/jQuery.validator.format">jQuery.validator.format()– Replaces {n} placeholders with arguments.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/jQuery.validator.setDefaults">jQuery.validator.setDefaults()– Modify default settings for validation.</a></li>
                <li><a target="_blank" href="http://jqueryvalidation.org/jQuery.validator.addClassRules">jQuery.validator.addClassRules()– Add a compound class method.</a></li>
              </ul>
          </div>
        </div>

                      

                </article>    

<!-- - - - HTML Code - - - --> 

  
                  <div class="col-8">
                                             
                      <span class="demo-header-1"><span>Validation demo</span></span>

<!-- *** *** *** *********************** * *** *** ***  -->
<!-- *** *** *** Validation demo * START * *** *** ***  -->
<!-- *** *** *** *********************** * *** *** ***  -->

                          <form method="post" name="tsr-demo-validate-form-poc" id="tsr-demo-validate-form-poc"  action="">
                              <div class=" tsr-forms">


                                  <!-- First name & Last name-->
                                  <div class="tsr-row">
                                        <div class="col-half">
                                            <label for='firstname'>First name *</label>
                                            <input type="text" name="firstname" title="This field is required" data-desc="Minimum 3 characters" required aria-required="true">
                                        </div>
                                        <div class="col-half">
                                            <label for='lastname'>Last name * </label>
                                            <input type="text" name="lastname" title="This field is required"  data-desc="Minimum 6 characters, sed ut perspiciatis unde omnis iste natus." required aria-required="true">
                                        </div>
                                  </div>

                                  <!-- Choose phone & Mobile number -->
                                  <div class="tsr-row">
                                    <div class="col-6">
                                        <label for="phones">Choose phone *</label>
                                          <div class="select-container">              
                                              <select id="phones" name="phones" title="Please select a phone!" required aria-required="true">
                                                <option value="">&nbsp;</option>
                                                <option value="Blackberry">Blackberry</option>
                                                <option value="Android">Android</option>
                                                <option value="IPhone">iPhone</option>
                                                <option value="Windows">Windows</option>
                                              </select>
                                          </div>
                                    </div>
                                    <div class="col-6">
                                          <label for='mobilenumber'>Mobile number *</label>
                                          <input type="text" name="mobilenumber" title="Not a valid number" data-desc="Minimum of 10 numbers" required aria-required="true">
                                    </div>
                                  </div>

                                  <!-- E-mail  -->
                                  <div class="tsr-row">
                                        <div class="col-half">
                                            <label for='username'>User name *</label>
                                            <input type="text" name="username" title="This field is required" data-desc="Maximum of 6 characters" required aria-required="true">
                                        </div>
                                        <div class="col-half">
                                            <label for='email'>E-mail * </label>
                                            <input type="text" name="email" title="This field is required" data-desc="Type a valid e-mail adress xxx@xx.xx" required aria-required="true">
                                        </div>
                                  </div>

                                  <!-- Password & Confirm password -->
                                  <div class="tsr-row">
                                        <div class="col-half">
                                            <label for="password">Password *</label>
                                            <input id="password" name="password" type="password" title="This field is required" data-desc="Minimum 8 characters" required aria-required="true">
                                        </div>
                                        <div class="col-half">
                                            <label for="confirm_password">Confirm password * </label>
                                            <input id="confirm_password" name="confirm_password" type="password" title="Must match password" required aria-required="true">
                                        </div>
                                  </div>
               
                                  <!-- Gender & Policy -->
                                  <div class="tsr-row">
                                       <div class="col-half">                                            
                                       
                                          <header class="label">Family *</header>
                                          <label for="family_single">
                                            <input type="radio" id="family_single" value="s" name="family" required aria-required="true">Single
                                          </label>
                                          <label for="family_married">
                                            <input type="radio" id="family_married" value="m" name="family">Married
                                          </label>
                                          <label for="family_other">
                                            <input type="radio" id="family_other" value="o" name="family">Other
                                          </label>
        
                                       </div>
                                       <div class="col-half">
                                            <header class="label">Policy *</header>
                                            <label for="agree"><input type="checkbox" name="agree" id="agree" title="Required" required aria-required="true"/>Confirm agreement</label>                                           
                                        </div>
                         
                                  </div>

                                  <!-- Meassage -->
                                  <div class="tsr-row">
                                    <div class="col-full">
                                       <label for="message">Meassage *</label>
                                       <textarea id="message" name="message" title="This field is required" data-desc="Minimum 10 charatcters, maximum 20 characters" required aria-required="true"></textarea>
                                    </div>  
                                  </div>

                                  <!-- Submit -->
                                  <div class="tsr-row" style="margin-top:20px;">
                                      <div class="col-3">
                                            <input type="submit" class="tsr-btn" name='submit' value="Submit">
                                      </div>
                                      <div class="col-3">
                                           <br /><i>* Required</i> 
                                      </div>
                                  </div>
          
                             </div> <!-- // tsr-forms END -->   
                     
                        </form>

<!-- *** *** *** *********************** *** *** ***  -->
<!-- *** *** *** Validation demo * END * *** *** ***  -->
<!-- *** *** *** *********************** *** *** ***  -->


 </div><!-- // col-8 -->

                                       




<!-- - - - Snippet - - - --> 

                <article class="col-full snippet mt20">

<pre><code data-language="html">
// Wrap forms:

<div class="... tsr-forms"> 
... 
</div>


/////////////////////////////////


// Input

<input type="text" name="firstname" title="This field is required" data-desc="Minimum 3 characters" required aria-required="true">


// Select

<div class="select-container">              
    <select id="phones" name="phones" title="Please select a phone!" required aria-required="true">
      <option value="">&nbsp;</option>
      <option value="Blackberry">Blackberry</option>
      <option value="Android">Android</option>
      <option value="IPhone">iPhone</option>
      <option value="Windows">Windows</option>
    </select>
</div>
                                         

// Radio

<label for="family_single">
    <input type="radio" id="family_single" value="s" name="family" required aria-required="true">Single
</label>
<label for="family_married">
    <input type="radio" id="family_married" value="m" name="family">Married
</label>
<label for="family_other">
    <input type="radio" id="family_other" value="o" name="family">Other
</label>


// Checkbox

<label for="agree">
    <input type="checkbox" name="agree" id="agree" title="Required" required aria-required="true"/>Confirm agreement
</label>


// Textarea

<textarea id="message" name="message" title="This field is required" data-desc="Minimum 10 charatcters, maximum 20 characters" required aria-required="true"></textarea>


</code></pre>

                </article>



            </div><!-- // container -->
        </section><!-- // row  --> 




               

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
  <?php include '__php-includes/footer-js.php'; ?>

  <script src="tsr-COMPONENTS/tsr-forms/jquery.validate.js"></script>

  <!-- TSR-FORMS -->
  <script src="tsr-COMPONENTS/tsr-forms/tsr-forms.js"></script>
  <script src="tsr-COMPONENTS/tsr-forms/tsr-forms-validate.js"></script>


  
  
</body>
</html>