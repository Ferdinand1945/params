<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

    <meta name="msapplication-TileColor" content="#FFFFFF">
    <meta name="msapplication-TileImage" content="tsr-COMPONENTS/tsr-favicon/favicon-144.png">     

    <title>Startpage | TeliaSonera</title>

    <link rel="icon"                                            href="tsr-COMPONENTS/tsr-favicon/favicon.png">
    <link rel="apple-touch-icon"                                href="tsr-COMPONENTS/tsr-favicon/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76"      href="tsr-COMPONENTS/tsr-favicon/favicon-76.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120"    href="tsr-COMPONENTS/tsr-favicon/favicon-120.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152"    href="tsr-COMPONENTS/tsr-favicon/favicon-152.png">

    <!--[if IE]><link rel="shortcut icon" href="favicon.ico"><![endif]-->

    <!-- TSR - All CSS bundeld -->
    <link rel="stylesheet" href="tsr--CORE/tsr-core.css">    
    
    <!-- Modernizer - Make a custom download "http://modernizr.com/download/" -->
    <script src="tsr--CORE/tsr-js/libs/modernizr.custom.min.js"></script>
        
    <!--[if IE]>
      <script src="tsr--CORE/tsr-js/polyfills/matchMedia.js"></script>
      <script src="tsr--CORE/tsr-js/polyfills/matchMedia.addListener.js"></script>
    <![endif]-->


    <script src="tsr--CORE/tsr-js/libs/enquire.min.js"></script>

<!--[if lte IE 8]>
            
    <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
    <link rel="stylesheet" href="tsr-COMPONENTS/tsr-tacticalElements/_tsr-tacticalElements-ie8.css">
    <link rel="stylesheet" href="tsr-MODULES/tsr-product/_tsr-product-ie8.css">            
    <link rel="stylesheet" href="tsr-MODULES/tsr-service/_tsr-service-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-attention/_tsr-attention-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-carousel-listing/_tsr-carousel-listing-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-communication-primary/_tsr-communication-primary-ie8.css">                      
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-communication-secondary/_tsr-communication-secondary-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-footer/_tsr-footer-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-header/_tsr-header-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-promotion/_tsr-promotion-ie8.css">
    <link rel="stylesheet" href="tsr-SECTIONS/tsr-support/_tsr-support-ie8.css">
       
<![endif]-->

<!--[if lt IE 6]>

        <link rel="stylesheet" type="text/css" href="tsr-COMPONENTS/tsr-ieSplash/tsr-ieSplash.css" />
        <script type="text/javascript">
            document.write("<div class='msie-7-splash'><div class='content'><h6>Your browser is to old!</h6><p>(This copy will be changed) We recommend you to upgrade or use the tablet/phablet or mobile phone next to you.</p><a href='https://www.google.com/intl/en/chrome/browser/' class='ch browser' target='_blank'>Chrome</a><a href='http://www.mozilla.org/sv-SE/firefox/fx/' class='ff  browser' target='_blank'>Firefox</a><a href='http://www.apple.com/safari/' class='sa browser' target='_blank'>Safari</a><a href='http://windows.microsoft.com/sv-SE/internet-explorer/download-ie' class='ex browser' target='_blank'>Explorer</a></div></div>");      
        </script>

<![endif]-->




</head>

<body class="tsr-grid tsr-typo">


        <section class="tsr-section-header">
            
<!-- - - GLOBAL - - -->
        
            <div class="tsr-header-global">
               <div class="tsr-container"> 
                        
                        <nav class="tsr-global-left">
                            <menu>
                                <li><a href="#">Private</a></li>
                                <li><a href="#">Business</a></li>
                                <li class="is-choosen"><a href="#">TSbrand B2B</a></li>
                                <li class="tsr-btn-arrow-mobile"></li>
                            </menu>
                        </nav>
                        
                        <a href="#" class="tsr-btn-close"></a>

                        <nav class="tsr-global-right">
                            <menu>
                                <li class="tsr-extra"><a href="#">Active demo</a></li>
                                <li class="tsr-extra"><a href="#">Refill prepaid card</a></li>
                                <li class="tsr-extra"><a href="#">Contact us</a></li>
                            </menu>
                        </nav>

                    </div>        
                </div>
            </div><!-- tsr-header-global END -->   

        

<!-- - - MAIN - - -->  

            <section class="tsr-header-main">
                <div class="tsr-container"> 
                
                <!-- LOGO -->  
                    <figure class="tsr-header-logo">
                        <img src="tsr-SECTIONS/tsr-header/logo-brand.png" />
                    </figure>


                        <!-- - - Top mobile + Search - - -->
                        <div class="tsr-header-mobileAndExtras">
                           <div class="tsr-container"> 
                                
                                    <nav>
                                        <menu>
                                            <li class="tsr-tab-cart" ><a href="#" data-header-tab="cart"><i class="tsr-tactical">3</i></a></li>
                                            <li class="tsr-tab-login"><a href="#" data-header-tab="login"></a></li>
                                            <li class="tsr-tab-search"><a href="#" data-header-tab="search"></a></li>
                                            <li class="tsr-tab-menu" ><a href="#" data-header-tab="menu"></a></li>
                                        </menu>
                                    </nav>
                  
                            </div>
                        </div><!-- tsr-header-mobileAndExtras END -->   

                
<!-- NAVIGATION -->  
                
                    <nav class="tsr-main-nav">
                        <menu class="tsr-nav-top-level">
                            <li><a href="#">Mobile phones</a>
                                <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Mobile phones landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-iphone.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Mobile phones</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Product &amp; Accessories</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Services</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                        </menu>
                                    </li>
                                     
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Tablets</a>
                                <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Tablets landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Tablets</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                        </menu>
                                    </li>
                                    <li><a href="#">Product &amp; Accessories</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Services</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     
                                    <li><a href="#">Header</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     
                                    <li><a href="#">Header</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            
                                        </menu>
                                    </li>
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Broadband</a>
                                 <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>Broadband landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>The All New iPhone 5s - Now Available</header>
                                                <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais</p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Broadband</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>
                                            <li><a href="#">Lorum 7</a></li>
                                            <li><a href="#">Lorum 8</a></li>
                                            
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>
                                            <li><a href="#">Lorum 7</a></li>
                                        </menu>
                                    </li>
                                    
                                     
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">TV</a>
                                 <menu class="tsr-nav-second-level">
                                    <li>
                                        <a href="#"><span>TV landing page</span>
                                            <article class="tsr-landing">
                                                <figure>
                                                    <img src="tsr-SECTIONS/tsr-header/landing-temp.png" />
                                                </figure>
                                                <header>TV</header>
                                                <p>Consecuteur baden scrillum </p>
                                            </article> 
                                        </a>
                                    </li>
                                    <li><a href="#">Lorum</a>
                                        <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                            <li><a href="#">Lorum 6</a></li>

                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                          
                                        </menu>
                                    </li>
                                    <li><a href="#">Subscriptions</a>
                                       <menu class="tsr-nav-third-level">
                                            <li><a href="#">Lorum 1</a></li>
                                            <li><a href="#">Lorum 2</a></li>
                                            <li><a href="#">Lorum 3</a></li>
                                            <li><a href="#">Lorum 4</a></li>
                                            <li><a href="#">Lorum 5</a></li>
                                          
                                        </menu>
                                    </li> 
                                     <li class="tsr-btn-close">
                                        <a href="#"></a>
                                    </li>
                                </menu>
                            </li>
                            <li><a href="#">Support</a>
                                                         
                            </li>
                           
                        </menu>
        
                    </nav>

<!-- Search -->  

                    <article class="tsr-header-search tsr-forms">

                        <input type="text" value="Search">
                        <input type="button" name="form-button" value="Search" class="tsr-btn">

                        <a href="#" class="tsr-btn-close" data-parent="search"></a>

                    </article><!-- tsr-header-search END -->    


<!-- Login -->  

                    <article class="tsr-header-login tsr-forms">

                        <input type="text" value="User">
                        <input type="password" value="Password">
                        <input type="button" name="form-button" value="Login" class="tsr-btn">

                        <a href="#" class="tsr-btn-close" data-parent="login"></a>

                    </article><!-- tsr-header-login END -->   

<!-- Cart-->  

                    <article class="tsr-header-cart tsr-forms">

                        <p class="tsr-text">
                            Content of Shopping Cart is Displayed Here
                        </p>
                            
                        <a href="#" class="tsr-btn-close" data-parent="cart"></a>

                    </article><!-- tsr-header-cart END -->  


                </div><!-- tsr-container END -->
            </section><!-- tsr-header-main END -->   


        </section><!-- // tsr-section-header END -->  


<!-- *** *** Primary communication area *** ***  -->


        <section class="tsr-section-communictaion-primary">
          
                <div class="tsr-slides">


                     <a href="#" class="tsr-slide-1">
                        
                        <div class="tsr-tactical-container">
                            <figure class="tsr-tactical-speach-bubble tsr-color-pink">
                                <header class="tsr-header">
                                    Channel package?
                                </header>
                                    Jumps over the lazy dog, jump<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>

                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>A Channel for Everyone</header>
                                <span>The quick brown fox jumps over the lazy dog</span>
                            </div>

                        </div>

                    </a>
                    

                    <a href="#" class="tsr-slide-2">

                        <div class="tsr-tactical-container">
                            <figure class="tsr-tactical-product-wrap tsr-color-orange">
                                <header class="tsr-header">
                                    Super Deal, iPhone 5s!
                                </header>
                                    Jumps over the lazy dog<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>

                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>Lorum</header>
                                <span>The quick brown fox jumps over the </span>
                            </div>

                        </div>
                    </a>


                    <a href="#" class="tsr-slide-3">
                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>The quick brown</header>
                                <span>The quick brown fox jumps over the lazy </span>
                            </div>

                        </div>
                    </a>


                     <a href="#" class="tsr-slide-4">
                        <div class="tsr-tactical-container">
                            <figure class="tsr-tactical-speach-bubble direction-right">
                                <header class="tsr-header">
                                    Free Colored Cover!
                                </header>
                                    Jumps over the lazy dog, jump<br>
                                    the lazy dog lorem ipsum
                            </figure>
                        </div>
                        <div class="tsr-container">

                            <div class="tsr-tactical-textPanel">
                                <header>The new iPad Air!</header>
                                <span>Lorum ipsum</span>
                            </div>

                        </div>
                    </a>    


                 </div>
           
        </section>

<!-- *** **** Secondary communication area *** **** --> 

        <section class="tsr-section-communication-secondary">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-1.jpg" />
                        </figure>
                        <header>The All New iPhone 5s - Changes everything again</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-2.jpg" />
                        </figure>
                        <header>Mixed campaign, offers, news   and product pushes</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-communication-secondary">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-communication-secondary/temp-3.jpg" />
                        </figure>
                        <header>Lorum ipsum</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>                   

               </div><!-- // container -->
         </section><!-- tsr-section-communication-secondary" END -->  



<!-- *** **** Support *** *** -->

        <section class="tsr-section-support">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-support ts-icon-calendar">
                        <header>TSbrand News</header>
                        <p>Lorem ipsum dolor amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il magna</p>
                    </a>  

                    <a href="#" class="tsr-module-support ts-icon-broadband">
                        <header>Network status</header>
                        <p>Ipsum dolor amet set basteur baden scrillum. Consecuteur baden scrillum dolor amet set il </p>
                    </a>  

                    <a href="#" class="tsr-module-support ts-icon-settings">
                        <header>Troubleshooting &amp; FAQ</header>
                        <p>Dolor amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il magna</p>
                    </a>  

                    <a href="#" class="tsr-module-support ts-icon-support">
                        <header>Contact us</header>
                        <p>Amet set basteur baden scrillum il. Consecuteur baden scrillum dolor amet set il</p>
                    </a>  
                
            </div><!-- // container -->
        </section><!-- tsr-section-support" END -->  

<!-- *** *** Attention *** *** -->

  <article class="tsr-section-attention tsr-secondaryAlert" >
    <div class="tsr-container">
        <figure class="ts-icon-broadband"></figure>
        <a href="#" class="tsr-attention-text"><strong>Secondary alert long header</strong> <span>Lorem ipsum dolor il magna amet set imnes consecuteur</span><span class="tsr-attention-readMore">Read much more</span></a>
    </div>
  </article>

<!-- *** **** Carousel listing *** *** -->

<section class="tsr-section-divider tsr-color-white">
    <header class="tsr-container">
        <span>
            Popular mobile phones
        </span>    
    </header>
</section>
    
        <section class="tsr-section-carousel-listing" >
            <div class="tsr-container">
                    <div class="tsr-slides">

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>
                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>
            

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-3.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor met sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>  


                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-4.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>
                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum</p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>
     

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone 5s</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>  
  
                              <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone 5s</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>                   
  
                              <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone 5s</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>   
                </div>
            </div>

       <a href="" class="tsr-btn-view-all"><span>View all phones<i>(28)</i></span></a>

        </section>

<!-- *** **** Promotion*** *** -->

<section class="tsr-section-divider tsr-color-white">
    <header class="tsr-container">
        <span>
            Promotion area
        </span>    
    </header>
</section>


        <section class="tsr-section-promotion">
            <div class="tsr-container">

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-1.png" />
                        </figure>
                        <header>The All New iPhone 5s - Changes everything again</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-2.png" />
                        </figure>
                        <header>Mixed campaign, offers, news   and product pushes</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>  

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-3.png" />
                        </figure>
                        <header>Lorum ipsum</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>

                    <a href="#" class="tsr-module-promotion">
                        <figure>
                            <img src="tsr-SECTIONS/tsr-promotion/temp-4.png" />
                        </figure>
                        <header>Lorum ipsum</header>
                        <p>Consecuteur baden scrillum imnes magna carta il set of the dover calais.</p>
                    </a>


               </div><!-- // container -->
         </section><!-- tsr-section-promotion" END -->  


<!-- *** **** Footer *** **** --> 

 <section class="tsr-section-footer">
            


                <!-- Links -->

                <div class="tsr-footer-links">
                    <div class="tsr-container">
                    
                        <menu class="tsr-nav-top-level tsr-extra-links">
                               <li>
                                    <header>Useful Services & Links</header>
                                        <menu class="tsr-nav-second-level">
                                            <li><a href="#">Extra 1</a></li>
                                            <li><a href="#">Extra 2</a></li>
                                            <li><a href="#">Extra 3</a></li>
                                            <li><a href="#">Extra 4</a></li>
                                            <li><a href="#">Extra 5</a></li>
                                        </menu>
                                </li>          
                        </menu><!-- // tsr-extra-links -->


                        <menu class="tsr-nav-top-level">

                            <li>
                                <a href="#">Mobile phones</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Mobile phones landing page</a></li>
                                        <li><a href="#">Mobile phones</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                        <li><a href="#">Product &amp; Accessories</a></li>
                                        <li><a href="#">Services</a></li> 
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Tablets</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Tablets phones landing page</a></li>
                                        <li><a href="#">Tablets</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                        <li><a href="#">Product &amp; Accessories</a></li>
                                        <li><a href="#">Services</a></li> 
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Broadband</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Broadband landing page</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                    </menu>
                            </li>

                            <li>
                                <a href="#">TV</a>
                                    <menu class="tsr-nav-second-level">
                                        <li><a href="#">Channels</a></li>
                                        <li><a href="#">Packages</a></li>
                                        <li><a href="#">Subscriptions</a></li>
                                    </menu>
                            </li>

                            <li>
                                <a href="#">Support</a>
                            </li>

                        </menu><!-- // tsr-nav-top-level  -->

                             
                    </div>       
                </div><!-- //tsr-footer-links -->


                <!-- SM -->

                <div class="tsr-footer-sm">
                    <div class="tsr-container">

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-facebook"></figure>
                            
                            <p>
                            <strong>TSbrand on Facebook</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-youtube"></figure>
                            
                            <p>
                            <strong>TSbrand on YouTube</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-twitter"></figure>
                            
                            <p>
                            <strong>TSbrand on Twitter</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                        <a href="#" class="tsr-footer-sm-link">
                            <figure class="tsr-footer-icon-google"></figure>
                            
                            <p>
                            <strong>TSbrand on Google +</strong>
                            <small>Short USP about why to visit this channel.</small>
                            </p>

                        </a>

                    </div>  
                </div><!-- //tsr-footer-sm -->

                <!-- Copyright -->

                <div class="tsr-footer-copyright">
                    <div class="tsr-container">
                        &copy; TSbrand 
                    </div>
                </div>

                <a href="#to-top" class="tsr-btn-toTop">Back to top</a>

  

                
        </section><!-- // tsr-section END -->  




          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr-header/tsr-header.js"></script>

    <script src="tsr-SECTIONS/tsr-communication-primary/tsr-communication-primary.js"></script>
    
    
    <script src="tsr-SECTIONS/tsr-communication-secondary/tsr-communication-secondary.js"></script>
    <script src="tsr-SECTIONS/tsr-support/tsr-support.js"></script>
    <script src="tsr-SECTIONS/tsr-attention/tsr-attention.js"></script>
    
    <script src="tsr-SECTIONS/tsr-productAndService-listing/tsr-productAndService-listing.js"></script>
    <script src="tsr-SECTIONS/tsr-carousel-listing/tsr-carousel-listing.js"></script>
    <script src="tsr-SECTIONS/tsr-promotion/tsr-promotion.js"></script>
  
    <script src="tsr-SECTIONS/tsr-footer/tsr-footer.js"></script>

  
    <script src="tsr-SECTIONS/tsr-communication-primary/jquery.flexslider.js"></script>


</body>
</html>