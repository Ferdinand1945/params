<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

        <title>Dividers| TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?>

        <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->

</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Dividers</span>
                    </span>
               
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ****************** DIVIDERS ******************** -->
<!-- ************************************************ -->

<section class="tsr-section-divider tsr-color-purple" style="margin-top:40px;">
    <header class="tsr-container">
        <span>
            Divider header
        </span>    
    </header><!-- // tsr-container END -->
</section><!-- // tsr-section END -->

<section class="tsr-section-divider">
    <header class="tsr-container">
        <span>
            Divider header
        </span>    
    </header><!-- // tsr-container END -->
</section><!-- // tsr-section END -->  

<section class="tsr-section-divider tsr-color-white">
    <header class="tsr-container">
        <span>
            Divider header
        </span>    
    </header><!-- // tsr-container END -->
</section><!-- // tsr-section END -->        

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Dividers</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section. <br/>
The divider has three options light or dark.

<ul>
  <li>Divider background grey by default</li>
  <li>.tsr-color-purple</li>
  <li>.tsr-color-white</li>
</ul>

<span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">

 <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-secondary tsr-btn-blue">View in context</a>
 <a href="tsr----STANDALONE-ZIP/tsr-section-dividers.zip" class="tsr-btn tsr-btn-100 mt20 ">Download ZIP</a> 

                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html"><section class="tsr-section-divider">
    <header class="tsr-container">
        <span>
            Divider header
        </span>    
    </header>
</section>

<section class="... tsr-color-purple">
    ...
</section>

<section class="... tsr-color-white">
    ...
</section>

</code></pre>



                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->



<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->



          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  
    <!-- TSR-Attention -->
  <script src="tsr-SECTIONS/tsr-support/tsr-support.js"></script>

  
</body>
</html>