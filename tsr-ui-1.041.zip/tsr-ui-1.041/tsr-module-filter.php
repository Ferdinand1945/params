<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Filter| TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


    <!--[if lte IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
            <link rel="stylesheet" href="tsr-SECTIONS/tsr-filter/_tsr-filter-ie8.css">
    <![endif]-->



</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Filter</span>
                    </span>
               
        </section><!-- // row  END -->


<!-- ************************************************ -->
<!-- ******************** BASE ********************** -->
<!-- ************************************************ -->

        <section class="tsr-row" style="margin-top:50px;">
            
                

<!-- - - - HTML - - - --> 


        <section class="tsr-section-filter">
            <div class="tsr-container">           
                
                    <!-- FILTER LIST -->

                            <menu class="tsr-filterList">

                                
                                <li class="tsr-top-level">
                                    <a href="#">Filter list</a>
                                   
                                    <div class="tsr-filter-wrapper">
                                        <div class="tsr-container">

                                            <menu class="tsr-second-level">
                                                <li><header>Filter by Brand</header></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple is-choosen">Apple</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Samsung</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Nokia</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Sony</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">LG</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">HTC</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Others</a></li>
                                            </menu>

                                            <menu class="tsr-second-level">
                                                <li><header>Filter by Operating System</header></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple">iOs</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Android</a></li>
                                                
                                            </menu>

                                            <menu class="tsr-second-level">
                                                <li><header>Filter by Functionality</header></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple">Camera</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple">HD Voice</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple">Voice Command</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple">Consecuteur</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Inactive</a></li>
                                            </menu>

                                            <menu class="tsr-second-level">
                                                <li><header>Filter by Lorem</header></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Loremsu</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Lorem ipsum</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Concecuteur</a></li>
                                                <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">Ipsum</a></li>
                                            </menu>

                                        </div>
                                    </div>

                                </li>

                            </menu>

              

                            <menu class="tsr-sortList">

                                <li class="tsr-top-level">
                                    <a href="#">Sort list</a>

                                    <menu class="tsr-second-level">
                                        <li><a href="#">Sort by: Lowest price</a></li>
                                        <li><a href="#">Sort by: Highest price</a></li>
                                        <li><a href="#">Sort by: Name A-z</a></li>
                                        <li><a href="#">Sort by: Name Z-a</a></li>
                                    </menu>

                                </li>
                                
                            </menu> 


            </div>
        </section><!-- // tsr-section END -->  


</section><!-- // row END --> 


<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Filter</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

<p>Filter list is just a shell for the graphical part. All functionality must be built according to your cms.</p>
                        <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                        </ul>
                        <span class="demo-header-3" style="padding:0; margin-bottom:-6px;"><span  style="padding:0;">Enquire.js</span></span>
                        <ul>

                          <li>tsr--CORE/tsr-js/libs/enquire.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.js</li>
                          <li>IE -> tsr--CORE/tsr-js/polyfills/matchMedia.addListener.js</li>
                        </ul>

                    </article>    

                    <article class="col-5 desc">
                        <a href="tsr----STANDALONE-ZIP/tsr-module-filter.zip" class="tsr-btn tsr-btn-100">Download ZIP</a>
                    </article>  

<!-- - - - Snippets- - - --> 


                    <article class="col-12 snippet">

<pre><code data-language="html"><!-- FILTER LIST -->

<menu class="tsr-filterList">

    
    <li class="tsr-top-level">
        <a href="#">Filter list</a>
       
        <div class="tsr-filter-wrapper">
            <div class="tsr-container">

                <menu class="tsr-second-level">
                    <li><header>...</header></li>
                    <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple is-choosen">...</a></li>
                    <li><a href="#" class="tsr-btn tsr-btn-small tsr-btn-purple tsr-btn-disabled">...</a></li>
                </menu>

                ...

            </div>
        </div>

    </li>

</menu>

<!-- SORT LIST -->

<menu class="tsr-sortList">

    <li class="tsr-top-level">
        <a href="#">Sort list</a>

        <menu class="tsr-second-level">
            <li><a href="#">...</a></li>
        </menu>

    </li>
    
</menu> 
</code></pre>

                      </article> <!-- // snippet -->



            </div><!-- // container -->
        </section><!-- // row - SECTION END -->




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->


          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
    <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-MODULES/tsr-filter/tsr-filter.js"></script>

  
</body>
</html>