<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Carousel listing | TeliaSonera</title>

    
        <?php include '__php-includes/head-css-js.php'; ?>


    <!--[if lte IE 9]>
        <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <link rel="stylesheet" href="tsr-MODULES/tsr-product/_tsr-product-ie8.css">
        <link rel="stylesheet" href="tsr-MODULES/tsr-service/_tsr-service-ie8.css">    
        <link rel="stylesheet" href="tsr-SECTIONS/tsr-carousel-listing/_tsr-carousel-listing-ie8.css">
    <![endif]-->


</head>

<body class="tsr-grid tsr-typo">

<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                


<?php include '__php-includes/header-navigation.php'; ?>


            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Carousel listing</span>
                    </span>
               
        </section><!-- // row  -->

<!-- ************************************************ -->
<!-- ********************* BASE ********************* -->
<!-- ************************************************ -->

        <section class="" style="margin:50px auto;">
            

<!-- - - - HTML Code - - - -->

<section class="tsr-section-divider tsr-color-purple"  style="margin-top:50px">
    <header class="tsr-container">
        <span>
            Popular mobile phones
        </span>    
    </header>
</section>
    
        <section class="tsr-section-carousel-listing" >
            <div class="tsr-container">
                    <div class="tsr-slides">

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>
                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>
            

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-3.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor met sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>  


                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-4.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <figure class="tsr-tactical-flash tsr-flash-usp-2 tsr-second"><span>HD<small>Voice</small></span></figure>
                                    <header class="tsr-product-header">Apple iPhone 5s 32GB</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum</p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>
     

                            <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone 5s</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>  
  
                              <a href="#" class="tsr-module-product">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-2.png" />
                                 </figure>
                                <div class="tsr-product-content">
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>4G</span></figure>  
                                    <header class="tsr-product-header">Apple iPhone 5s</header>
                                    <ul class="tsr-product-colors">
                                        <li style="background:#e2e2e2"></li>
                                        <li style="background:#d77b72"></li>
                                        <li style="background:#f8f07b"></li>
                                        <li style="background:#73b5e7"></li>
                                        <li style="background:#a5c76c"></li>
                                    </ul>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 12 $/month </p>
                                    <p class="tsr-product-small-print"> Total cost 299 $</p>
                                </div>
                            </a>                   

                </div>
            </div>

       <a href="" class="tsr-btn-view-all"><span>View all phones<i>(28)</i></span></a>

        </section>




<!-- SERVICES -->

<section class="tsr-section-divider tsr-color-purple" >
    <header class="tsr-container">
        <span>
            Popular services
        </span>    
    </header>
</section>


        <section class="tsr-section-carousel-listing tsr-color-white" >

            <div class="tsr-container">
                    <div class="tsr-slides">



                            <a href="#" class="tsr-module-service">
                                <figure class="tsr-service-icon ts-icon-teliasonera">
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>
                                </figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">TSbrand header</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor amet sit dolor dolor ipsum sit. </p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>


                            <a href="#" class="tsr-module-service ">
                                <figure class="tsr-service-icon ts-icon-play"></figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">Play +</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor amet sit dolor ipsum sit. </p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>  


                            <a href="#" class="tsr-module-service ">
                                <figure class="tsr-service-icon ts-icon-chat"></figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">Group call</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor.</p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>


                            <a href="#" class="tsr-module-service ">
                                <figure class="tsr-service-icon ts-icon-broadband"></figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">Homerun wireless</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor amet sit dolor ipsum sit</p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>


                            <a href="#" class="tsr-module-service ">
                                <figure class="tsr-service-icon ts-icon-travelabroad"></figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">Roaming</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor amet sit dolor</p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>

                            <a href="#" class="tsr-module-service">
                                <figure class="tsr-service-icon ts-icon-teliasonera">
                                    <figure class="tsr-tactical-ribbon"><span>New</span></figure>
                                    <figure class="tsr-tactical-ribbon-usp">4G<span></span></figure>
                                </figure>
                                <div class="tsr-service-content">
                                    <header class="tsr-service-header">TSbrand header</header>
                                    <p class="tsr-service-desc"> Lorem ipsum dolor amet sit dolor dolor ipsum sit. </p>
                                    <p class="tsr-service-price">Price fr. 12 $/month </p>
                                </div>
                            </a>



                </div>
            </div>

       <a href="" class="tsr-btn-view-all"><span>View all services<i>(7)</i></span></a>

        </section>


<!-- PRODUCTS -->


<section class="tsr-section-divider tsr-color-purple">
    <header class="tsr-container">
        <span>
            Popular products
        </span>    
    </header>
</section>


        <section class="tsr-section-carousel-listing" >

            <div class="tsr-container">
                    <div class="tsr-slides">


                         <a href="#" class="tsr-module-product tsr-product-other">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-other-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-ribbon tsr-text-small"><span>Popular</span></figure>
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>HD</span></figure>  
                                    
                                    <header class="tsr-product-header">HBO GO</header>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 37 $/month </p>

                                </div>
                            </a>
     
                            <a href="#" class="tsr-module-product tsr-product-other">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-other-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-ribbon tsr-text-small"><span>Popular</span></figure>
                                    <figure class="tsr-tactical-flash tsr-tactical-round  tsr-flash-usp-1 tsr-first"><span>HD</span></figure>  
                                   
                                    <header class="tsr-product-header">HBO GO</header>
                                    <p class="tsr-product-desc"></p>
                                    <p class="tsr-product-price">Price fr. 37 $/month </p>

                                </div>
                            </a>

                            <a href="#" class="tsr-module-product tsr-product-other">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-other-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-flash tsr-flash-usp-1 tsr-first"><span>HD</span></figure>
                                    <header class="tsr-product-header">HBO GO</header>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 37 $/month </p>

                                </div>
                            </a>

                            <a href="#" class="tsr-module-product tsr-product-other">
                                 <figure class="tsr-product-image">
                                    <img src="tsr-MODULES/tsr-product/product-other-1.png" />
                                 </figure>
                                <div class="tsr-product-content">                                   
                                    <figure class="tsr-tactical-flash tsr-tactical-round  tsr-flash-usp-1 tsr-first"><span>HD</span></figure>
                                    <header class="tsr-product-header">HBO GO</header>
                                    <p class="tsr-product-desc"> Lorem ipsum dolor amet sit dolor ipsum sit </p>
                                    <p class="tsr-product-price">Price fr. 37 $/month </p>

                                </div>
                            </a>



                </div>
            </div>

       <a href="" class="tsr-btn-view-all"><span>View all products<i>(12)</i></span></a>

        </section> 



      
        </section><!-- // row - DARK SECTION END -->

<!-- ************************************************ -->
<!-- ********************* DOCS ********************* -->
<!-- ************************************************ -->

<!-- - - - TEXT  description - - - --> 

        <section class=" dark show-docs pb44">
            <div class="tsr-container">
                


<!-- - - - Header - - - --> 
             
                    <div class="col-full">
                        <span class="demo-header-1"><span>Carousel listing</span></span>
                    </div>

<!-- - - - TEXT  description - - - --> 

                    <article class="col-7 desc">

Full width section that centre the products or services. If the width exceeds the screen width it will automatically become a slider. Blow 768px it will "destroy" the silder and it will be normal listing. The view all button should be a link to listing page.

                        <span class="demo-header-2"><span>Dependencies</span></span>
                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>
                          <li><a href="tsr-components-buttonsAndLinks.php">tsr-buttonsAndLinks</a></li>
                          <li><a href="tsr-components-grid.php">tsr-grid</a></li>
                          <li><a href="tsr-components-icons.php">tsr-icons</a></li>
                          <li><a href="tsr-components-tacticalElements.php">tsr-tacticalElements</a></li>
                          <li><a href="tsr-modules-product.php">tsr-product</a></li>
                          <li><a href="tsr-modules-service.php">tsr-service</a></li>
                        </ul>


                    </article>    

                    <article class="col-5 desc">

                        <a href="tsr-layout-startpage.php" target="_blank" class="tsr-btn tsr-btn-100 tsr-btn-blue">View in context</a>
                        <a href="tsr----STANDALONE-ZIP/tsr-section-carousel-listing.zip" class="tsr-btn tsr-btn-100 tsr-btn-large mt8">Download ZIP</a>

                    </article>  

<!-- - - - Snippets- - - --> 

                    <article class="col-12 snippet">



<pre style="margin-top:5px;"><code data-language="html"> <section class="tsr-section-carousel-listing" >

    <div class="tsr-container">
        <div class="tsr-slides">

             <a href="#" class="tsr-module-product">
                     ...
            </a>

        </div>
    </div>

    <a href="" class="tsr-btn-view-all"><span>View all products<i>(...)</i></span></a>

</section></code></pre>


                </article> <!-- // snippet -->


            </div><!-- // container -->
        </section><!-- // row - SECTION END -->




<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
 <?php include '__php-includes/footer-js.php'; ?>
  
    <script src="tsr-SECTIONS/tsr-productAndService-listing/tsr-productAndService-listing.js"></script>
    <script src="tsr-SECTIONS/tsr-carousel-listing/tsr-carousel-listing.js"></script>
    <script src="tsr-SECTIONS/tsr-carousel-listing/jquery.flexslider.js"></script>
  
</body>
</html>