<!doctype html>

        <?php include '__php-includes/html-conditional.php'; ?>

<head>

        <?php include '__php-includes/head-meta.php'; ?>

  <title>Buttons &amp; Links | TeliaSonera</title>

        <?php include '__php-includes/head-css-js.php'; ?> 

         <!--[if lt IE 9]>
            <link rel="stylesheet" href="tsr-COMPONENTS/tsr-grid/_tsr-grid-ie8.css">
        <![endif]-->              

</head>


<body class="tsr-grid tsr-typo">


<!-- ************************************************ -->
<!-- *********** HEADER - UTILITI - GLOBAL ********** -->
<!-- ************************************************ -->
  
    <section class="utilitie-styles">

<!-- - - - Navgation - - - -->   

        <section class="utility-navigation">
            <div class="tsr-container">                

                <?php include '__php-includes/header-navigation.php'; ?>

            </div>
        </section>

<!-- - - - Headline - Text - - - --> 

        <section class="header-1-hero">
            
                    <span>
                        <span>Buttons &amp; Links</span>
                    </span>
               
        </section><!-- // row  -->


<!-- ************************************************ -->
<!-- ******************** BUTTONS ******************* -->
<!-- ************************************************ -->

        <section class="tsr-row show-docs">
            <div class="tsr-container">

                <div class="col-full">
                    <span class="demo-header-1"><span>Buttons</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

<p>There are three types of buttons; normal, small and large. Normal is used generally on the website when a button is needed, except in forms where the small version is used. Large is used when there is a more prominent need of calls-to-action.</p>
<p><a href="tsr----STANDALONE-ZIP/tsr-component-buttonsAndLinks.zip" class="tsr-btn mt20 ">Download ZIP</a></p>   
                 <span class="demo-header-2"><span>Dependencies</span></span>

                        <ul>
                          <li>tsr--CORE/_normalize.css</li>  
                          <li><a href="tsr-components-typography.php">tsr-typography</a></li>  
                        </ul>
                </article>    

<!-- - - - HTML Code - - - --> 

                <div class="col-full">
                    <span class="demo-header-2"><span>Normal and alternatives</span></span>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>.tsr-btn</span></span>
                        <a href="#" class="tsr-btn">Normal</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-disabled</span></span>
                        <a href="#" class="tsr-btn tsr-btn-disabled">Disabled</a>
                </div>

                <div class="col-6">
                        <span class="demo-header-3"><span>... .tsr-btn-100</span></span>
                        <a href="#" class="tsr-btn tsr-btn-100">Width 100%</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#" class="tsr-btn"> ... </a>
<a href="#" class="... tsr-btn-disabled"> ... </a>
<a href="#" class="... tsr-btn-100"> ... </a></code></pre>

                </article>

                <div class="col-full">
                    <span class="demo-header-2"><span>Colors</span></span>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-purple</span></span>
                        <a href="#" class="tsr-btn tsr-btn-purple tsr-btn-100">Purple</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-pink</span></span>
                        <a href="#" class="tsr-btn tsr-btn-pink tsr-btn-100">Pink</a>
                </div>


                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-blue</span></span>
                        <a href="#" class="tsr-btn tsr-btn-blue tsr-btn-100">Blue</a>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>... .tsr-btn-orange</span></span>
                        <a href="#" class="tsr-btn tsr-btn-orange tsr-btn-100">Orange</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#" class="... tsr-btn-purple"> ... </a>
<a href="#" class="... tsr-btn-pink"> ... </a>
<a href="#" class="... tsr-btn-blue"> ... </a>
<a href="#" class="... tsr-btn-orange"> ... </a></code></pre>

                </article>

                <div class="col-full">
                    <span class="demo-header-2"><span>Sizes</span></span>
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>... .tsr-btn-large</span></span>
                        <a href="#" class="tsr-btn tsr-btn-large">Large</a>
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>.tsr-btn</span></span>
                        <a href="#" class="tsr-btn tsr-btn-secondary">Normal</a>
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>... .tsr-btn-small</span></span>
                        <a href="#" class="tsr-btn tsr-btn-small">Small</a>
                </div>

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#" class="... tsr-btn-large"> ... </a>
<a href="#" class="... tsr-btn-small"> ... </a></code></pre>

                </article>

                <div class="col-full">
                    <span class="demo-header-2"><span>Type</span></span>
                </div>

                <div class="col-3">
                        <span class="demo-header-3"><span>&lt;A&gt;</span></span>
                        <a href="#" class="tsr-btn">A</a>
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>&lt;Input&gt;</span></span>
                        <input type="button" name="form-button" value="input" class="tsr-btn" />
                </div>

               <div class="col-2">
                        <span class="demo-header-3"><span>(disabled)</span></span>
                        <input type="button" name="form-button" value="Input" class="tsr-btn" disabled />
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>&lt;Button&gt;</span></span>
                        <button class="tsr-btn">button</button>
                </div>

                <div class="col-2">
                        <span class="demo-header-3"><span>(disabled)</span></span>
                        <button class="tsr-btn" disabled>button</button>
                </div>
 

<!-- - - - Snippet - - - --> 

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#" class="tsr-btn"> ... </a>
<input type="button" name="" value="" class="tsr-btn" />
<button class="tsr-btn"> ... </button></code></pre>

                </article> 


                <div class="col-full" style="margin-top:50px;">
                    <span class="demo-header-2"><span>View all or more etc.</span></span>
                </div>   


<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">

This is a full section button used for for "view more" / "view all" etc. 
This button has two colours, white wich is the dafult colour and light grey. In some sections the button colour is handled automatic depending on the colour of section itself. Can be overwritten by adding colour class direct on button.<br />
Resize your browser, the button chnages apperance when screen size is below 768px. 

                </article>   

            </div><!-- // container -->

            <div class="tsr-container">
                <div class="col-full">
                    <span class="demo-header-3"><span>.tsr-btn-view-all</span></span>
                </div>
            </div>

            <a href="#" class="tsr-btn-view-all"><span>View all<i>(23)</i></span></a>

            <div class="tsr-container">
                <div class="col-full">
                    <span class="demo-header-3 mt8"><span>... .tsr-color-white</span></span>
                </div>
            </div>

            <a href="#" class="tsr-btn-view-all tsr-color-white "><span>View all<i>(23)</i></span></a>

<!-- - - - Snippet - - - --> 

            <div class="tsr-container">

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#" class="tsr-btn-view-all"><span> ... <i> . </i></span></a>
<a href="#" class="... tsr-color-white"><span> ... <i> . </i></span></a></code></pre>

                </article> 

            </div>

<!-- ************************************************ -->
<!-- ********************* LINKS ******************** -->
<!-- ************************************************ -->

            <div class="tsr-container">
                <div class="col-full">
                    <span class="demo-header-1"><span>Links</span></span>
                </div>

<!-- - - - TEXT  description - - - --> 

                <article class="col-full desc">
                    Normal text link, default styling. And bold version.
                </article>  

                <div class="col-3">
                        <span class="demo-header-3"><span>&lt;a&gt;</span></span>
                        <a href="#">Default link</a>
                </div> 

                <div class="col-3">
                        <span class="demo-header-3"><span>&lt;a&gt;</span></span>
                        <a href="#" class="tsr-link-bold">Bold link</a>
                </div> 

<!-- - - - Snippet - - - --> 

            

                <article class="col-full snippet">

<pre><code data-language="html"><a href="#">Default link</a>
<a href="#" class="tsr-link-bold">Bold link</a></code></pre>

                </article> 

            </div>


                <div class="col-full">
                    <span class="demo-header-1"><span>&nbsp;</span></span>
                </div>

        </section><!-- // row  -->

        

<!-- ************************************************ -->
<!-- ********************** END ********************* -->
<!-- ************************************************ -->
       
    </section><!-- // utility-styles -->

          
<!-- ******************************************* -->
<!-- *************** JAVASCRIPT **************** -->
<!-- ******************************************* -->
 
     <?php include '__php-includes/footer-js.php'; ?>
  
  
</body>
</html>