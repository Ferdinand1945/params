

// ============================================================
// JAVASCRIPT - (u-main.js)
// ============================================================

(function(document) {


            $('body').on('click', function(){


               clickBody();
                
                
                
            });


/* - - - Navigation - - - */   


 $('.navigation .mobile').on('click', function(){
                    
                    var el = $(this);

                    var el = $(this);
                    var elParent = el.parent();
            
                    if (elParent.hasClass("show-menu")) {
                        elParent.removeClass('show-menu');
                    }
                    else {
                        liSub.removeClass('show-menu');
                        elParent.addClass('show-menu');
                    }
             
                    return false;
                    
                });
                
      

   

    /* - - - Add sub class */

            $('.utility-navigation menu menu').parent().addClass('sub');

    
    /* - - - Click */

            var liSub = $('.utility-navigation li.sub');
            var liSubA = $('.utility-navigation li.sub > a');

            liSubA.on('click', function(){
                
                var el = $(this);
                var elParent = el.parent();
        
                if (elParent.hasClass("sub-click")) {
                    elParent.removeClass('sub-click');
                }
                else {
                    liSub.removeClass('sub-click');
                    elParent.addClass('sub-click');
                }
         
                return false;
                
            });
        
       
/* - - - Section - - - */           


            var doc = $('li.docs');

        	doc.on('click', function(){

    			var el = $(this);
    			var section = $(this).parent().parent().parent();
    	
                if (section.hasClass("show-docs")) {
                    section.removeClass('show-docs');
                    el.removeClass('active');
                }
                else {
                    section.addClass('show-docs');
                    el.addClass('active');
                }
                return false;
    			
    		});


            var accEl = $('.nav-section li.acc');

            accEl.on('click', function(){

                var el = $(this);
                var color = el.attr('data-color-theme');
                var section = $(this).closest(".tsr-container");
        
           

                if (section.hasClass(color)) {
                   section.removeClass(color);
                    $('.nav-section li.acc').removeClass('active');
                }
                else {
                    section.removeClass('acc-1').removeClass('acc-2').removeClass('acc-3').removeClass('acc-4').removeClass('acc-5').removeClass('acc-6').removeClass('acc-7').removeClass('acc-8');
                    $('.nav-section li.acc').removeClass('active');
                    section.addClass(color);
                    el.addClass('active');
                }
                return false;
                
            });
          

            var rwdEl = $('.nav-section li.rwd');

            rwdEl.on('click', function(){

                var el = $(this);
                var breakpoint = el.attr('data-rwd');
                var section = $(this).closest(".rwd-iframe");
        
             

                if (section.hasClass(breakpoint)) {
                   section.removeClass(breakpoint);
                    $('.nav-section li.rwd').removeClass('active');

                        $('#ifr').removeAttr('height');
                         setIframeHeight(document.getElementById('ifr'));

                }
                else {
                    section.removeClass('rwd-iframe-xsmall').removeClass('rwd-iframe-small').removeClass('rwd-iframe-medium').removeClass('rwd-iframe-large').removeClass('rwd-iframe-xlarge');
                    $('.nav-section li.rwd').removeClass('active');
                    section.addClass(breakpoint);
                    el.addClass('active');

                        $('#ifr').removeAttr('height');
                         setIframeHeight(document.getElementById('ifr'));

                }
                
                return false;
                
            }); 

          

})(document);


$(window).load(function () {
    setIframeHeight(document.getElementById('ifr'));
});


    $(document).on('scroll', function(){

        clickBody(); 
            
    });



function setIframeHeight(iframe) {
    if (iframe) {
        var iframeWin = iframe.contentWindow || iframe.contentDocument.parentWindow;
        if (iframeWin.document.body) {
            iframe.height = iframeWin.document.documentElement.scrollHeight || iframeWin.document.body.scrollHeight;
        }
    }
};


function clickBody() {
    $('.utility-navigation li.sub').removeClass('sub-click');
}

